﻿using ASD;
using ASD.Graphs;
using System;
using System.Collections.Generic;
using System.Drawing;

namespace Lab06
{
    public class HeroesSolver : MarshalByRefObject
    {
        /// <summary>
        /// Etap 1 - stwierdzenie, czy rozwiązanie istnieje
        /// </summary>
        /// <param name="g">graf przedstawiający mapę</param>
        /// <param name="keymasterTents">tablica krotek zawierająca pozycje namiotów klucznika - pierwsza liczba to kolor klucznika, druga to numer skrzyżowania</param>
        /// <param name="borderGates">tablica krotek zawierająca pozycje bram granicznych - pierwsza liczba to kolor bramy, dwie pozostałe to numery skrzyżowań na drodze między którymi znajduje się brama</param>
        /// <param name="p">ilość występujących kolorów (występujące kolory to 1,2,...,p)</param>
        /// <returns>bool - wartość true jeśli rozwiązanie istnieje i false wpp.</returns>
        public bool Lab06Stage1(Graph<int> g, (int color, int city)[] keymasterTents, (int color, int cityA, int cityB)[] borderGates, int p)
        {
            int n = g.VertexCount - 1; // wierzchołek 0 nie występuje w zadaniu

            if (n == 1)
            {
                return true;
            }

            Graph<int> heroGraph = CreateHeroGraph(g, keymasterTents, borderGates, p);

            foreach (Edge<int> edge in heroGraph.BFS<int>().SearchFrom(1))
            {
                if (edge.To % n == 0)
                {
                    return true;
                }
            }

            return false;
        }

        // tworzenie grafu
        private Graph<int> CreateHeroGraph(Graph<int> g, (int color, int city)[] keymasterTents, (int color, int cityA, int cityB)[] borderGates, int p)
        {
            int n = g.VertexCount;
            Graph<int> heroGraph = new Graph<int>(n * (int)Math.Pow(2, p));

            for (int i = 1; i < n; i++)
            {
                foreach (Edge<int> edge in g.OutEdges(i))
                {
                    for (int level = 0; level < (int)Math.Pow(2, p); level++)
                    {
                        heroGraph.AddEdge(edge.From + n * level, edge.To + n * level, edge.Weight); // płaszczyzny grafu
                    }
                }
            }

            foreach ((int color, int cityA, int cityB) borderGate in borderGates)
            {
                for (int level = 0; level < (int)Math.Pow(2, p); level++)
                {
                    if ((level & (1 << borderGate.color - 1)) == 0)
                    {
                        heroGraph.RemoveEdge(borderGate.cityA + n * level, borderGate.cityB + n * level); // usuwanie krawędzi w przypadku bram granicznych
                    }
                }
            }

            foreach ((int color, int city) keymasterTent in keymasterTents)
            {
                for (int level = 0; level < (int)Math.Pow(2, p); level++)
                {
                    for (int upperLevel = level + 1; upperLevel < (int)Math.Pow(2, p); upperLevel++)
                    {
                        if ((level ^ upperLevel) == (1 << keymasterTent.color - 1))
                        {
                            heroGraph.AddEdge(keymasterTent.city + n * level, keymasterTent.city + n * upperLevel); // dodawanie krawędzi w przypadku namiotów klucznika
                        }
                    }
                }
            }

            return heroGraph;
        }

        /// <summary>
        /// Etap 2 - stwierdzenie, czy rozwiązanie istnieje
        /// </summary>
        /// <param name="g">graf przedstawiający mapę</param>
        /// <param name="keymasterTents">tablica krotek zawierająca pozycje namiotów klucznika - pierwsza liczba to kolor klucznika, druga to numer skrzyżowania</param>
        /// <param name="borderGates">tablica krotek zawierająca pozycje bram granicznych - pierwsza liczba to kolor bramy, dwie pozostałe to numery skrzyżowań na drodze między którymi znajduje się brama</param>
        /// <param name="p">ilość występujących kolorów (występujące kolory to 1,2,...,p)</param>
        /// <returns>krotka (bool solutionExists, int solutionLength) - solutionExists ma wartość true jeśli rozwiązanie istnieje i false wpp. SolutionLenth zawiera długość optymalnej trasy ze skrzyżowania 1 do n</returns>
        public (bool solutionExists, int solutionLength) Lab06Stage2(Graph<int> g, (int color, int city)[] keymasterTents, (int color, int cityA, int cityB)[] borderGates, int p)
        {
            int n = g.VertexCount - 1; // wierzchołek 0 nie występuje w zadaniu

            if (n == 1)
            {
                return (true, 0);
            }

            Graph<int> heroGraph = CreateHeroGraph(g, keymasterTents, borderGates, p);
            Graph<int> hero1Graph = CreateHeroGraph(g, keymasterTents, borderGates, p);
            Graph<int> hero2Graph = CreateHeroGraph(g, keymasterTents, borderGates, p);
            Graph<int> hero3Graph = CreateHeroGraph(g, keymasterTents, borderGates, p);
            Graph<int> hero4Graph = CreateHeroGraph(g, keymasterTents, borderGates, p);

            PathsInfo<int> paths = Paths.Dijkstra<int>(heroGraph, 1);

            int lowestCost = int.MaxValue;
            int debugIndex = 0;

            for (int i = 0; i < (int)Math.Pow(2, p); i++)
            {
                if (paths.Reachable(1, n + (n + 1) * i))
                {
                    if (paths.GetDistance(1, n + (n + 1) * i) < lowestCost)
                    {
                        lowestCost = paths.GetDistance(1, n + (n + 1) * i);
                        debugIndex = i;
                    }
                }
            }

            var debug = paths.GetPath(1, n + (n + 1) * debugIndex);

            if (lowestCost == int.MaxValue)
            {
                return (false, 0);
            }

            return (true, lowestCost);
        }
    }
}
