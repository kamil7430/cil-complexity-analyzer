﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab02
{
    public class PatternMatching : MarshalByRefObject
    {
        /// <summary>
        /// Etap 1 - wyznaczenie trasy, zgodnie z którą robot przemieści się z pozycji poczatkowej (0,0) na pozycję docelową (-n-1, m-1)
        /// </summary>
        /// <param name="n">wysokość prostokąta</param>
        /// <param name="m">szerokość prostokąta</param>
        /// <param name="obstacles">tablica ze współrzędnymi przeszkód</param>
        /// <returns>krotka (bool result, string path) - result ma wartość true jeżeli trasa istnieje, false wpp., path to wynikowa trasa</returns>
        public (bool result, string path) Lab02Stage1(int n, int m, (int, int)[] obstacles)
        {
            if (n == 1 && m == 1)
            {
                return (true, "");
            }

            string[,] path = new string[n, m];  // path[i, j] - path from (0, 0) to (i, j)
            path[0, 0] = "";

            foreach (var obstacle in obstacles)
            {
                path[obstacle.Item1, obstacle.Item2] = "Unavailable";
            }

            // fill first row
            bool obstacleFound = false;
            for (int j = 1; j < m; j++)
            {
                if (path[0, j] == "Unavailable")
                {
                    obstacleFound = true;
                    continue;
                }
                path[0, j] = obstacleFound ? "Unavailable" : path[0, j - 1] + "R";
            }

            // fill first column
            obstacleFound = false;
            for (int i = 1; i < n; i++)
            {
                if (path[i, 0] == "Unavailable")
                {
                    obstacleFound = true;
                    continue;
                }
                path[i, 0] = obstacleFound ? "Unavailable" : path[i - 1, 0] + "D";
            }

            // fill the rest of the path
            for (int i = 1; i < n; i++)
            {
                for (int j = 1; j < m; j++)
                {
                    if (path[i, j] == "Unavailable")
                    {
                        continue;
                    }

                    if (path[i - 1, j] == "Unavailable" && path[i, j - 1] == "Unavailable")
                    {
                        path[i, j] = "Unavailable";
                    }
                    else if (path[i - 1, j] == "Unavailable")
                    {
                        path[i, j] = path[i, j - 1] + "R";
                    }
                    else
                    {
                        path[i, j] = path[i - 1, j] + "D";
                    }
                }
            }

            return (path[n - 1, m - 1] != "Unavailable", path[n - 1, m - 1]);
        }

        /// <summary>
        /// Etap 2 - wyznaczenie trasy realizującej zadany wzorzec, zgodnie z którą robot przemieści się z pozycji poczatkowej (0,0) na pozycję docelową (-n-1, m-1)
        /// </summary>
        /// <param name="n">wysokość prostokąta</param>
        /// <param name="m">szerokość prostokąta</param>
        /// <param name="pattern">zadany wzorzec</param>
        /// <param name="obstacles">tablica ze współrzędnymi przeszkód</param>
        /// <returns>krotka (bool result, string path) - result ma wartość true jeżeli trasa istnieje, false wpp., path to wynikowa trasa</returns>
        public (bool result, string path) Lab02Stage2(int n, int m, string pattern, (int, int)[] obstacles)
        {
            if (string.IsNullOrEmpty(pattern) || pattern.All(c => c == '*'))
            {
                return Lab02Stage1(n, m, obstacles);
            }
            string[,,] path = new string[n, m, pattern.Length + 1];  // path[i, j, k] - path from (0, 0) to (i, j) with pattern[0..k-1]

            foreach (var obstacle in obstacles)
            {
                for (int k = 0; k <= pattern.Length; k++)
                {
                    path[obstacle.Item1, obstacle.Item2, k] = "Unavailable";
                }
            }



            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    path[i, j, 0] = i == 0 && j == 0 ? "" : "Unavailable";
                    for (int k = 1; k <= pattern.Length; k++)
                    {
                        // fill unavailable paths in start position
                        if (i == 0 && j == 0)
                        {
                            path[0, 0, k] = "Unavailable";
                            continue;
                        }

                        if (path[i, j, k] == "Unavailable")
                        {
                            continue;
                        }

                        // fill unavailable paths in first row
                        if (i == 0)
                        {
                            // if there is a (k-1)-path to left and pattern[k] is 'R' or '?'
                            if (path[0, j - 1, k - 1] != "Unavailable" && (pattern[k - 1] == 'R' || pattern[k - 1] == '?' || pattern[k - 1] == '*'))
                            {
                                path[0, j, k] = path[0, j - 1, k - 1] + "R";
                            }
                            // if there is a k-path to left and pattern[k] is '*'
                            else if (path[0, j - 1, k] != "Unavailable" && pattern[k - 1] == '*')
                            {
                                path[0, j, k] = path[0, j - 1, k] + "R";
                            }
                            else
                            {
                                path[0, j, k] = "Unavailable";
                            }
                        }
                        // fill unavailable paths in first column
                        if (j == 0)
                        {
                            // if there is a (k-1)-path to up and pattern[k] is 'D' or '?'
                            if (path[i - 1, 0, k - 1] != "Unavailable" && (pattern[k - 1] == 'D' || pattern[k - 1] == '?' || pattern[k - 1] == '*'))
                            {
                                path[i, 0, k] = path[i - 1, 0, k - 1] + "D";
                            }
                            // if there is a k-path to up and pattern[k] is '*'
                            else if (path[i - 1, 0, k] != "Unavailable" && pattern[k - 1] == '*')
                            {
                                path[i, 0, k] = path[i - 1, 0, k] + "D";
                            }
                            else
                            {
                                path[i, 0, k] = "Unavailable";
                            }
                        }

                        // fill the rest of the path
                        if (i > 0 && j > 0)
                        {
                            // if there is a (k-1)-path to left and pattern[k] is 'R' or '?'
                            if (path[i, j - 1, k - 1] != "Unavailable" && (pattern[k - 1] == 'R' || pattern[k - 1] == '?' || pattern[k - 1] == '*'))
                            {
                                path[i, j, k] = path[i, j - 1, k - 1] + "R";
                            }
                            // if there is a (k-1)-path to up and pattern[k] is 'D' or '?'
                            else if (path[i - 1, j, k - 1] != "Unavailable" && (pattern[k - 1] == 'D' || pattern[k - 1] == '?' || pattern[k - 1] == '*'))
                            {
                                path[i, j, k] = path[i - 1, j, k - 1] + "D";
                            }
                            // if there is a k-path to left and pattern[k] is '*'
                            else if (path[i, j - 1, k] != "Unavailable" && pattern[k - 1] == '*')
                            {
                                path[i, j, k] = path[i, j - 1, k] + "R";
                            }
                            // if there is a k-path to up and pattern[k] is '*'
                            else if (path[i - 1, j, k] != "Unavailable" && pattern[k - 1] == '*')
                            {
                                path[i, j, k] = path[i - 1, j, k] + "D";
                            }
                            else
                            {
                                path[i, j, k] = "Unavailable";
                            }
                        }
                    }
                }
            }

            return (path[n - 1, m - 1, pattern.Length] != "Unavailable", path[n - 1, m - 1, pattern.Length]);
        }
    }
}