﻿using System;


namespace KMP;

public class Program
{
    public static void Main(string[] args)
    {
        string text = "ababcababcabc";
        string pattern = "abc";
        List<int> occurrences = KMP(text, pattern);
        Console.WriteLine("Pattern found at indices: " + string.Join(", ", occurrences));
    }

    public static List<int> KMP(string text, string pattern)
    {
        int n = text.Length;
        int m = pattern.Length;
        List<int> result = new List<int>();
        int[] P = ComputeP(pattern);

        for (int i = 0, j = 0; i <= n - m; i += Math.Max(j - P[j], 1))
        {
            j = P[j];
            while (j < m && text[i + j] == pattern[j])
            {
                j++;
            }
            if (j == m)
            {
                result.Add(i);
            }
        }
        return result;
    }

    public static int[] ComputeP(string pattern)
    {
        int m = pattern.Length;
        int[] P = new int[m + 1];
        P[0] = P[1] = 0;
        int t = 0;

        for (int j = 2; j <= m; j++)
        {
            while (t > 0 && pattern[t] != pattern[j - 1])
            {
                t = P[t];
            }
            if (pattern[t] == pattern[j - 1])
            {
                t++;
            }
            P[j] = t;
        }
        return P;
    }
}