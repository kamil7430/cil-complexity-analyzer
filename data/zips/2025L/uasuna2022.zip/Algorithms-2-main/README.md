# Algorytmy i Struktury Danych 2 (AiSD2) - Algorithms and Data Structures 2

## Overview

This repository contains C# implementations and solutions for laboratory assignments completed during the **Algorithms and Data Structures 2** (*Algorytmy i Struktury Danych 2 – AiSD2*) course as part of the Bachelor's degree curriculum at the Faculty of Mathematics and Information Science (MiNI), Warsaw University of Technology (*Politechnika Warszawska*).

The course focuses on advanced algorithmic topics, emphasizing complex graph theory problems, network flows, multi-dimensional dynamic programming, computational geometry, NP-hard problem solving techniques (backtracking, branch-and-bound), and specialized data structures.

---

## Technical Stack & Environment

- **Language**: C# (.NET Framework / .NET Core)
- **Primary Libraries**: Custom `ASD.Graphs` framework (`Graphs.dll`), `TestSet.dll`
- **IDE**: Microsoft Visual Studio

---

## Laboratory Topics & Implementations

### Lab 01: Dynamic Programming – Change Making Problem
- Implementation of the classic Change-Making problem using dynamic programming.
- Optimal coin count calculation and full reconstruction of coin combinations for arbitrary denominations.

### Lab 02: Dynamic Programming – Seam Carving & Path Optimization
- **Stage 1**: Finding a minimum-cost vertical seam (path) across an image grid.
- **Stage 2**: 3D Dynamic Programming state matrix (`dp[h, w, 3]`) tracking path direction penalties to resolve ambiguous path choices and prevent sub-optimal seam mergers.

### Lab 03: Graph Foundations – Reverse Graphs, Bipartiteness, MST & Acyclicity
- Construction of graph transpose (reversed directed graphs).
- Bipartite graph verification via 2-coloring BFS/DFS traversal.
- Minimum Spanning Tree (MST) and Spanning Forest construction using Kruskal's algorithm with disjoint-set data structures (`UnionFind`).
- Undirected acyclicity testing using component counts and edge-to-vertex relations.

### Lab 04: Graph Traversals & Dynamic Infection Propagation
- Breadth-First Search (BFS) simulation of malware propagation across IT service networks.
- Multi-queue time-step simulation handling scheduled service shutdowns and dynamic service re-enabling over a $K$-day period.

### Lab 06: Weighted Shortest Paths & Multi-Criteria Optimization
- Dijkstra-based pathfinding incorporating vertex waiting times for hiking route optimization.
- Multi-criteria optimization: extracting paths that minimize financial cost, using travel time as a tie-breaker via tuple-prioritized queues.

### Lab 08: Network Flows & Min-Cost Max-Flow Optimization
- **Stage 1 (Evacuation)**: Ford-Fulkerson maximum flow algorithm applied to grid networks. Node-splitting technique (separating each cell into `in` and `out` sub-vertices) to enforce capacity constraints per grid cell.
- **Stage 2 (Profit Maximization)**: Min-Cost Max-Flow algorithm (`NetworkWithCosts`) balancing machine rescue rewards against step-by-step movement costs.

### Lab 09: Backtracking, Graph Isomorphism & NP-Hard Search
- **Maximum Clique**: Backtracking algorithm searching for maximum complete subgraphs with state-space pruning.
- **Graph Isomorphism**: Exact graph isomorphism testing supporting edge weights and vertex degree pruning.
- **Traveling Salesperson Problem (TSP)**: Branch-and-bound lower estimate matrix reductions for asymmetric TSP.

### Lab 10: State-Space Pruning & Repeated Sequences on Graphs
- Backtracking algorithm searching for the longest repeated color sequence along graph paths.
- Parallel path expansion across pairs of same-colored vertices using strict backtracking pruning.

### Lab 12: Computational Geometry – Closest Pair of Points
- $O(N^2)$ baseline brute-force closest pair implementation.
- $O(N \log N)$ sweep-line algorithm using $X$-coordinate sorting combined with a dynamic `SortedSet` window maintained by $Y$-coordinates.

### Lab 14: Trie Data Structures & Levenshtein Edit Distance
- Custom Trie (prefix tree) implementation supporting constant-time word counts, prefix lookup, and deletion.
- Approximate string matching searching for all words within a target Levenshtein edit distance using single-row dynamic programming state propagation during DFS traversal.

### Lab 15: Advanced Graph Theory – Biconnected Components & Cut Vertices
- Tarjan's DFS algorithm for finding 2-vertex-connected components (biconnected subgraphs) utilizing `DFSNumber` and `lowestBacktrack` state tracking.
- Identification of articulation points (cut vertices) belonging to the highest number of biconnected components.

---

## Project Structure

Each laboratory solution is organized into its own Visual Studio solution directory (`Lab01`, `Lab02`, ..., `Lab15`), containing source files, problem specifications, and test suites.
