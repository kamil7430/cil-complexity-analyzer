using System;
using ASD.Graphs;
using System.Collections.Generic;

namespace ASD
{
    public class Lab04 : MarshalByRefObject
    {
        /// <summary>
        /// Etap 1 - wyznaczanie numerów grup, które jest w stanie odwiedzić Karol, zapisując się na początku do podanej grupy
        /// </summary>
        /// <param name="graph">Ważony graf skierowany przedstawiający zasady dołączania do grup</param>
        /// <param name="start">Numer grupy, do której początkowo zapisuje się Karol</param>
        /// <returns>Tablica numerów grup, które może odwiedzić Karol, uporządkowana rosnąco</returns>
        public int[] Lab04Stage1(DiGraph<int> graph, int start)
        {
            var g = new Graph(graph.VertexCount, graph.Representation);

            for (var i = 0; i < graph.VertexCount; i++)
            {
                foreach (var u in graph.OutNeighbors(i))
                {
                    if (graph.GetEdgeWeight(i, u) == -1 && i == start)
                    {
                        g.AddEdge(i, u);
                        continue;
                    }

                    foreach (var v in graph.OutNeighbors(u))
                    {
                        if (graph.GetEdgeWeight(u, v) == i)
                            g.AddEdge(u, v);
                    }
                }
            }

            var visited = new bool[g.VertexCount];
            var s = new Stack<int>();
            s.Push(start);

            while (s.Count > 0)
            {
                var v = s.Pop();
                if (visited[v]) continue;
                visited[v] = true;

                foreach (var u in g.OutNeighbors(v))
                {
                    if (visited[u]) continue;
                    s.Push(u);
                }
            }

            var result = new List<int>();
            for (var i = 0; i < g.VertexCount; i++)
            {
                if (visited[i]) result.Add(i);
            }

            return result.ToArray();
        }

        /// <summary>
        /// Etap 2 - szukanie możliwości przejścia z jednej z grup z `starts` do jednej z grup z `goals`
        /// </summary>
        /// <param name="graph">Ważony graf skierowany przedstawiający zasady dołączania do grup</param>
        /// <param name="starts">Tablica z numerami grup startowych (trasę należy zacząć w jednej z nich)</param>
        /// <param name="goals">Tablica z numerami grup docelowych (trasę należy zakończyć w jednej z nich)</param>
        /// <returns>(possible, route) - `possible` ma wartość true gdy istnieje możliwość przejścia, wpp. false, 
        /// route to tablica z numerami kolejno odwiedzanych grup (pierwszy numer to numer grupy startowej, ostatni to numer grupy docelowej),
        /// jeżeli possible == false to route ustawiamy na null</returns>
        public (bool possible, int[] route) Lab04Stage2(DiGraph<int> graph, int[] starts, int[] goals)
        {
            // TODO
            return (false, null);
        }
    }
}