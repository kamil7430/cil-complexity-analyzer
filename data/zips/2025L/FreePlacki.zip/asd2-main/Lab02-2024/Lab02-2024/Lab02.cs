﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASD
{
    public class Lab02 : MarshalByRefObject
    {
        private void Fill<T>(T[,,] array, T elem)
        {
            for (int i = 0; i < array.GetLength(0); i++)
            {
                for (int j = 0; j < array.GetLength(1); j++)
                {
                    for (int k = 0; k < array.GetLength(2); k++)
                    {
                        array[i, j, k] = elem;
                    }
                }
            }
        }
        
        /// <summary>
        /// Etap 1 - wyznaczenie najtańszej trasy, zgodnie z którą pionek przemieści się z pozycji poczatkowej (0,0) na pozycję docelową
        /// </summary>
        /// <param name="n">wysokość prostokąta</param>
        /// <param name="m">szerokość prostokąta</param>
        /// <param name="moves">tablica z dostępnymi ruchami i ich kosztami (di - o ile zwiększamy numer wiersza, dj - o ile zwiększamy numer kolumnj, cost - koszt ruchu)</param>
        /// <returns>(bool result, int cost, (int, int)[] path) - result ma wartość true jeżeli trasa istnieje, false wpp., cost to minimalny koszt, path to wynikowa trasa</returns>
        public (bool result, int cost, (int i, int j)[] path) Lab02Stage1(int n, int m,
            ((int di, int dj) step, int cost)[] moves)
        {
            const int inf = Int32.MaxValue;
            // T[i, j] = koszt dostania się od (0, 0) do (i, j)
            var T = new int[n, m];
            T[0, 0] = 0;
            // P[i, j] = ruch (w górę) w optymalnym kierunku dla (i, j)
            var P = new (int di, int dj)[n, m];

            for (var i = 1; i < n; i++)
            {
                for (var j = 0; j < m; j++)
                {
                    var bestMove = moves[0];
                    var bestCost = inf;
                    foreach (var move in moves)
                    {
                        if (i - move.step.di < 0 || j - move.step.dj < 0) continue;
                        var prev = T[i - move.step.di, j - move.step.dj];
                        if (prev != inf && prev + move.cost < bestCost)
                        {
                            bestCost = prev + move.cost;
                            bestMove = move;
                        }
                    }

                    T[i, j] = bestCost;
                    P[i, j] = bestMove.step;
                }
            }

            var bCost = inf;
            var bJ = 0;
            for (int j = 0; j < m; j++)
            {
                if (T[n - 1, j] < bCost)
                {
                    bCost = T[n - 1, j];
                    bJ = j;
                }
            }

            if (bCost == inf)
                return (false, inf, null!);

            var bMoves = new List<(int i, int j)>();
            var coords = (n - 1, bJ);
            while (coords != (0, 0))
            {
                var move = P[coords.Item1, coords.Item2];
                bMoves.Insert(0, coords);
                coords.Item1 -= move.di;
                coords.Item2 -= move.dj;
            }

            bMoves.Insert(0, (0, 0));

            return (true, bCost, bMoves.ToArray());
        }


        /// <summary>
        /// Etap 2 - wyznaczenie najtańszej trasy, zgodnie z którą pionek przemieści się z pozycji poczatkowej (0,0) na pozycję docelową - dodatkowe założenie, każdy ruch może być wykonany co najwyżej raz
        /// </summary>
        /// <param name="n">wysokość prostokąta</param>
        /// <param name="m">szerokość prostokąta</param>
        /// <param name="moves">tablica z dostępnymi ruchami i ich kosztami (di - o ile zwiększamy numer wiersza, dj - o ile zwiększamy numer kolumnj, cost - koszt ruchu)</param>
        /// <returns>(bool result, int cost, (int, int)[] path) - result ma wartość true jeżeli trasa istnieje, false wpp., cost to minimalny koszt, path to wynikowa trasa</returns>
        public (bool result, int cost, (int i, int j)[] pat) Lab02Stage2(int n, int m,
            ((int di, int dj) step, int cost)[] moves)
        {
            const int inf = int.MaxValue - 1000;
            var K = moves.Length;
            // T[i, j, k] = koszt ścieżki od (0, 0) do (i, j) używając tylko moves[0,..=k]
            var T = new int[n, m, K];
            Fill(T, inf);
            T[0, 0, 0] = 0;

            for (var i = 1; i < n; i++)
            {
                for (var j = 0; j < m; j++)
                {
                    for (var k = 0; k < K; k++)
                    {
                        // nie używamy ruchu move[k]
                        if (k != 0)
                        {
                            var unused = T[i, j, k - 1];
                            T[i, j, k] = int.Min(T[i, j, k], unused);
                        }

                        // używamy ruch move[k]
                        if (k == 0 && i == moves[k].step.di && j == moves[k].step.dj)
                        {
                            T[i, j, k] = int.Min(T[i, j, k], moves[0].cost);
                            continue;
                        }
                        if (k == 0) continue;
                        if (i - moves[k].step.di < 0 || j - moves[k].step.dj < 0 ||
                            T[i - moves[k].step.di, j - moves[k].step.dj, k] == inf) continue;
                        var used = T[i - moves[k].step.di, j - moves[k].step.dj, k - 1] + moves[k].cost;
                        T[i, j, k] = int.Min(T[i, j, k], used);
                    }
                }
            }

            var bCost = inf;
            for (var j = 0; j < m; j++)
            {
                if (T[n - 1, j, K - 1] < bCost)
                {
                    bCost = T[n - 1, j, K - 1];
                }
            }

            if (bCost == inf)
                return (false, int.MaxValue, null!);

            return (true, bCost, null!);
        }
    }
}