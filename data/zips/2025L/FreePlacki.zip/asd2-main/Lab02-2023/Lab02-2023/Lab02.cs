﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab02
{
    public class PatternMatching : MarshalByRefObject
    {
        /// <summary>
        /// Etap 1 - wyznaczenie trasy, zgodnie z którą robot przemieści się z pozycji poczatkowej (0,0) na pozycję docelową (n-1, m-1)
        /// </summary>
        /// <param name="n">wysokość prostokąta</param>
        /// <param name="m">szerokość prostokąta</param>
        /// <param name="obstacles">tablica ze współrzędnymi przeszkód</param>
        /// <returns>krotka (bool result, string path) - result ma wartość true jeżeli trasa istnieje, false wpp., path to wynikowa trasa</returns>
        public (bool result, string path) Lab02Stage1(int n, int m, (int, int)[] obstacles)
        {
            if (n <= 1 && m <= 1) return (true, "");
            
            var T = new bool?[n, m];
            T[0, 0] = true;
            foreach (var o in obstacles)
            {
                T[o.Item1, o.Item2] = false;
            }

            bool FindPathR(int i, int j)
            {
                if (i == 0 && j == 0) return true;
                if (i < 0 || j < 0) return false;
                
                if (T[i, j] != null)
                {
                    return T[i, j] == true;
                }
                
                var hor = FindPathR(i, j - 1);
                if (hor)
                {
                    T[i, j] = true;
                    return true;
                }

                var ver = FindPathR(i - 1, j);
                if (ver)
                {
                    T[i, j] = true;
                    return true;
                }

                T[i, j] = false;
                return false;
            }
            
            var result = FindPathR(n - 1, m - 1);
            if (!result)
                return (false, "");

            var path = new StringBuilder();
            var i = n - 1;
            var j = m - 1;
            while (i != 0 || j != 0)
            {
                if (i - 1 >= 0 && T[i - 1, j] == true)
                {
                    // path.Append('D');
                    path.Insert(0, 'D');
                    i--;
                }
                else if (j - 1 >= 0 && T[i, j - 1] == true)
                {
                    // path.Append('R');
                    path.Insert(0, 'R');
                    j--;
                }
            }
            
            return (true, path.ToString());
        }

        /// <summary>
        /// Etap 2 - wyznaczenie trasy realizującej zadany wzorzec, zgodnie z którą robot przemieści się z pozycji poczatkowej (0,0) na pozycję docelową (-n-1, m-1)
        /// </summary>
        /// <param name="n">wysokość prostokąta</param>
        /// <param name="m">szerokość prostokąta</param>
        /// <param name="pattern">zadany wzorzec</param>
        /// <param name="obstacles">tablica ze współrzędnymi przeszkód</param>
        /// <returns>krotka (bool result, string path) - result ma wartość true jeżeli trasa istnieje, false wpp., path to wynikowa trasa</returns>
        public (bool result, string path) Lab02Stage2(int n, int m, string pattern, (int, int)[] obstacles)
        {
            var K = pattern.Length;
            // T[i, j, k] = dla k pierwszych ścieżka od (0, 0) do (i, j) lub "" jeśli się nie da
            var T = new string?[n, m, K];
            for (var kk = 0; kk < K; kk++)
                T[0, 0, kk] = "";
            foreach (var o in obstacles)
            {
                for (var kk = 0; kk < K; kk++)
                    T[o.Item1, o.Item2, kk] = "";
            }

            (bool r, string p) FindPathR(int i, int j, int k)
            {
                // TODO: there might be an edge case
                if (i == 0 && j == 0)
                {
                    if (k < 0) return (true, "");
                    if (k == 0 && pattern[0] == '*') return (true, "");
                    return (false, "");
                }
                if (i < 0 || j < 0 || k < 0) return (false, "");

                if (T[i, j, k] != null)
                {
                    return T[i, j, k] != "" ? (true, T[i, j, k]!) : (false, "");
                }

                if (pattern[k] == '*')
                {
                    var h = FindPathR(i, j - 1, k);
                    if (h.r)
                    {
                        T[i, j, k] = h.p + "R";
                        return (true, T[i, j, k]!);
                    }
                    var v = FindPathR(i - 1, j, k);
                    if (v.r)
                    {
                        T[i, j, k] = v.p + "D";
                        return (true, T[i, j, k]!);
                    }
                }
                var hor = FindPathR(i, j - 1, k - 1);
                if (hor.r && (pattern[k] == 'R' || pattern[k] == '?' || pattern[k] == '*'))
                {
                    T[i, j, k] = hor.p + "R";
                    return (true, T[i, j, k]!);
                }

                var ver = FindPathR(i - 1, j, k - 1);
                if (ver.r && (pattern[k] == 'D' || pattern[k] == '?' || pattern[k] == '*'))
                {
                    T[i, j, k] = ver.p + "D";
                    return (true, T[i, j, k]!);
                }

                T[i, j, k] = "";
                return (false, "");
            }
            
            return FindPathR(n - 1, m - 1, K - 1);
        }
    }
}