﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Lab14
{
    public class Lab14 : MarshalByRefObject
    {

        /// <summary>
        /// Etap 1 - znaleźć najkrótszy palindrom, który można uzyskać poprzez rozszerzanie słowa
        /// </summary>
        /// <param name="text">ciąg znaków do rozszerzenia w palindrom  </param>
        /// <returns>string - najkrótszy palindrom uzyskany z wejścia</returns>
        public string Lab14Stage1(string text)
        {
            return "";
        }

        /// <summary>
        /// Etap 2 - znaleźć najdłuższy podciąg bez powtórzeń
        /// </summary>
        /// <param name="numbers"> ciąg liczb, w których należy znaleźć najkrótszy podciag bez powtórzeń </param>
        /// <returns>(int[], int) najdłuższy podciąg bez powtarzających się znaków i jego długość
        public (int[], int) Lab14Stage2(int[] numbers)
        {
            return (new int[0], 0);
        }
    }
}
