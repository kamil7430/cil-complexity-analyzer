﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

using ASD.Graphs;

namespace ASD2
{
    public class GraphColorer : MarshalByRefObject
    {
        /// <summary>
        /// Metoda znajduje kolorowanie zadanego grafu g używające najmniejsze możliwej liczby kolorów.
        /// </summary>
        /// <param name="g">Graf (nieskierowany)</param>
        /// <returns>Liczba użytych kolorów i kolorowanie (coloring[i] to kolor wierzchołka i). Kolory mogą być dowolnymi
        /// liczbami całkowitymi.</returns>
        public (int numberOfColors, int[] coloring) FindBestColoring(Graph g)
        {
            // Stopwatch stopwatch = Stopwatch.StartNew();

            int n = g.VertexCount;

            int[][] adjacjencyTable = new int[n][];
            for (int i = 0; i < n; i++)
            {
                adjacjencyTable[i] = g.OutNeighbors(i).ToArray();
            }

            // int maxDegree = adjacjencyTable.Max(neighbors => neighbors.Length);

            int[] order = Enumerable.Range(0, n).OrderByDescending(v => adjacjencyTable[v].Length).ToArray();

            int[] greedyColoring = new int[n];
            for (int i = 0; i < n; i++)
            {
                greedyColoring[i] = -1;
            }

            foreach (int u in order)
            {
                bool[] used = new bool[n];
                foreach (int v in adjacjencyTable[u])
                {
                    if (greedyColoring[v] != -1)
                    {
                        used[greedyColoring[v]] = true;
                    }
                }

                int i = 0;
                while (used[i])
                {
                    i++;
                }
                greedyColoring[u] = i;
            }

            int[] currentBestColloring = greedyColoring;
            int bestK = greedyColoring.Max() + 1;

            for (int currentK = bestK - 1; currentK >= 1; currentK--)
            {
                int[] colors = new int[n];
                for (int i = 0; i < n; i++)
                {
                    colors[i] = -1;
                }

                bool[] deferred = new bool[n];
                List<int> deferredList = new List<int>();
                int[] tempResult = new int[n];

                if (Backtrack())
                {
                    currentBestColloring = tempResult;
                    bestK = currentK;
                }
                else
                {
                    break;
                }

                (int numOfActiveNeighbours, int numOfFreeColors) getStatsOfVertex(int u)
                {
                    int numOfActiveNeighbours = 0;
                    bool[] used = new bool[currentK];
                    int numOfColors = 0;
                    
                    foreach (int neigh in adjacjencyTable[u])
                    {
                        if (colors[neigh] == -1 && !deferred[neigh])
                        {
                            numOfActiveNeighbours++;
                        }
                        else if (colors[neigh] >= 0)
                        {
                            int c = colors[neigh];
                            if (c < currentK && !used[c]) 
                            { 
                                used[c] = true; 
                                numOfColors++; 
                            }
                        }
                    }
                    
                    return (numOfActiveNeighbours, currentK - numOfColors);
                }

                bool Backtrack()
                {
                    int initiallyDefferedCount = deferredList.Count;

                    bool changed = true;
                    while (changed)
                    {
                        changed = false;
                        for (int i = 0; i < n; i++)
                        {
                            if (colors[i] == -1 && !deferred[i])
                            {
                                var (numOfActiveNeighbours, numOfFreeColors) = getStatsOfVertex(i);
                                if (numOfFreeColors > numOfActiveNeighbours)
                                {
                                    deferred[i] = true;
                                    deferredList.Add(i);
                                    changed = true;
                                }
                            }
                        }
                    }

                    int bestVertex = -1;
                    int minColors = int.MaxValue;
                    int maxActiveNei = -1;

                    for (int i = 0; i < n; i++)
                    {
                        if (colors[i] == -1 && !deferred[i])
                        {
                            var (numOfActiveNeighbours, numOfFreeColors) = getStatsOfVertex(i);
                            if (numOfFreeColors == 0)
                            {
                                // klops
                                UndoSimplification(initiallyDefferedCount);
                                return false;
                            }
                            if (numOfFreeColors < minColors || (numOfFreeColors == minColors && numOfActiveNeighbours > maxActiveNei))
                            {
                                minColors = numOfFreeColors;
                                maxActiveNei = numOfActiveNeighbours;
                                bestVertex = i;
                            }
                        }
                    }

                    if (bestVertex == -1)
                    {
                        for (int i = 0; i < n; i++)
                        {
                            tempResult[i] = colors[i];
                        }

                        for (int i = deferredList.Count - 1; i >= 0; i--)
                        {
                            int v = deferredList[i];
                            bool[] used = new bool[currentK];
                            foreach (int neigh in adjacjencyTable[v])
                            {
                                if (tempResult[neigh] >= 0)
                                {
                                    used[tempResult[neigh]] = true;
                                }
                            }

                            int j = 0;
                            while (used[j])
                            {
                                j++;
                            }
                            tempResult[v] = j;
                        }
                        
                        return true;
                    }

                   
                    int maxColor = colors.Max();
                    int limit = Math.Min(currentK - 1, maxColor + 1);
                    bool[] forbiddenColors = new bool[currentK];
                    
                    foreach (int neigh in adjacjencyTable[bestVertex])
                    {
                        if (colors[neigh] >= 0)
                        {
                            forbiddenColors[colors[neigh]] = true;
                        }
                    }

                    for (int c = 0; c <= limit; c++)
                    {
                        if (!forbiddenColors[c])
                        {
                            colors[bestVertex] = c;
                            if (Backtrack())
                            {
                                return true;
                            }
                            colors[bestVertex] = -1;
                        }
                    }

                    UndoSimplification(initiallyDefferedCount);
                    
                    return false;
                }

                void UndoSimplification(int targetCount)
                {
                    while (deferredList.Count > targetCount)
                    {
                        int v = deferredList[deferredList.Count - 1];
                        deferredList.RemoveAt(deferredList.Count - 1);
                        deferred[v] = false;
                    }
                }
            }
            
            // stopwatch.Stop();
            // Console.Write($"czas wykonania: {stopwatch.ElapsedMilliseconds} ms  \t");
            
            return (bestK, currentBestColloring);
        }
    }
}