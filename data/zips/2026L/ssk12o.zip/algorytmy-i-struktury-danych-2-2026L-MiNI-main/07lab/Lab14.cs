using System;
using System.Reflection.Metadata.Ecma335;

namespace ASD
{
    public class Lab14 : MarshalByRefObject
    {
        /// <summary>Etap I</summary>
        /// <param name="text">Wejściowy ciąg znaków</param>
        /// <param name="pattern">Wzorzec do wyszukania najdłuższego pokrytego podsłowa ciągu `text` przez niego.</param>
        /// <param name="result">Najdłuższe podsłowo `text` pokryte przez `pattern`.</param>
        /// <returns>Długość najdłuższego podsłowa `text` pokrytego przez `pattern`.</returns>
        public int Stage1(string text, string pattern, out string result)
        {
            result = string.Empty;
            if (text.Length < pattern.Length) return 0;

            bool[] resultFromKmp = kmp(pattern, text);

            int longestWordStart = -1;
            int longestWordLength = -1;

            int currentWordStart = -1;

            int indexer = 0;

            bool inWord = false;
            int counter = 0;

            while (indexer < text.Length)
            {
                if (resultFromKmp[indexer] == false && inWord == false)
                {
                    indexer++;
                    continue;
                }

                if (resultFromKmp[indexer] == true)
                {
                    if (inWord == false)
                    {
                        inWord = true;
                        currentWordStart = indexer;
                    }

                    counter = pattern.Length;
                }

                if (counter > 0)
                {
                    if (indexer - currentWordStart + 1 > longestWordLength)
                    {
                        longestWordStart = currentWordStart;
                        longestWordLength = indexer - currentWordStart + 1;
                    }
                    counter--;
                }
                if (!(indexer + 1 >= resultFromKmp.Length) && counter <= 0 && resultFromKmp[indexer + 1] == false)
                {
                    inWord = false;
                }
                indexer++;
            }

            if (longestWordStart >= 0)
            {
                result = text.Substring(longestWordStart, ( longestWordLength));
                // result = text[longestWordStart..(longestWordStart + longestWordLength)];
                return longestWordLength;
            }
            result = string.Empty;
            return 0;
        }

        int[] compute(string text)
        {
            int[] resut = new int[text.Length + 1];
            int t = 0;

            for (int i = 2; i <= text.Length; i++)
            {
                while (t > 0 && text[t] != text[i - 1])
                {
                    t = resut[t];
                }

                if (text[t] == text[i - 1])
                {
                    t++;
                }
                resut[i] = t;
            }
            return resut;
        }

        bool[] kmp(string x, string y)
        {
            bool[] valids = new bool[y.Length];
            int[] P = compute(x);
            int i = 0;
            int j = 0;
            for (; i <= y.Length - x.Length; i += Math.Max(j - P[j], 1))
            {
                j = P[j];
                while (j < x.Length && y[i + j] == x[j])
                {
                    j++;
                }

                if (j == x.Length)
                {
                    valids[i] = true;
                }
            }

            return valids;
        }

        /// <summary>Etap II</summary>
        /// <param name="word">Wejściowe słowo.</param>
        /// <param name="result">Najkrótsze podsłowo pokrywające `word`.</param>
        /// <returns>Długość najkrótszego podsłowa pokrywającego `word`.</returns>
        public int Stage2(string word, out string result)
        {
            if (word == "")
            {
                result = "";
                return 0;
            }

            int n = word.Length;
            int[] p_i = compute(word);
            int[] S_w = new int[n + 1];
            int[] maxCoveredWordTillI = new int[n + 1];

            for (int i = 1; i <= n; i++)
            {
                int longestPS = p_i[i];
                if (longestPS > 0)
                {
                    int wordoLengthooo = S_w[longestPS];
                    if (maxCoveredWordTillI[wordoLengthooo] >= i - longestPS)
                    {
                        S_w[i] = wordoLengthooo;
                    }
                    else
                    {
                        S_w[i] = i;
                    }
                }
                else
                {
                    S_w[i] = i;
                }
                maxCoveredWordTillI[S_w[i]] = i;
            }

            int shortestCoverLength = S_w[n];

            result = word.Substring(0, shortestCoverLength);

            return shortestCoverLength;
        }
    }
}