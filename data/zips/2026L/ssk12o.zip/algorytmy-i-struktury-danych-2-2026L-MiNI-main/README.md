# Algorytmy i Struktury Danych 2 (2026L) — MiNI

Repozytorium zawiera rozwiązania zadań laboratoryjnych z **Algorytmów i Struktur Danych 2** z semestru letniego roku 2026 które uzyskały maksymalną możliwa ilość punktów.

## Zawartość 


|  #  | Temat                    |      Katalog     |
| :-: | :----------------------- | :--------------: |
|  1  | Programowanie dynamiczne | [01lab](./01lab) |
|  2  | Grafy                    | [02lab](./02lab) |
|  3  | Najkrótsze ścieżki       | [03lab](./03lab) |
|  4  | Przepływy                | [04lab](./04lab) |
|  5  | Algorytmy z nawrotami    | [05lab](./05lab) |
|  6  | Geometria obliczeniowa   | [06lab](./06lab) |
|  7  | Algorytmy tekstowe       | [07lab](./07lab) |
|  8  | Zadanie dowolne          | [08lab](./08lab) |

 
## Legenda

Każda directory zawiera:

```text
XXlab/
├── LabXX.cs      # rozwiazanie
├── LabXX.pdf     # treść 
└── Program.cs    # program testowy / uruchomieniowy
```

## Biblioteki

Repozytorium zawiera również biblioteki potrzebne do odpalania i testowania rozwiązania.

```text
Graphs.dll -- biblioteka z algorytmami i strukturami danych udostepniana przez prowadzacych.
Graphs help.zip -- manpages do powyzszej libki.
TestSet.dll -- biblioteka słuzaca do odpalania testow
```
