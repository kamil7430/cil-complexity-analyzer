using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using ASD.Graphs;
using ASD;

namespace ASD
{
    public class Lab12 : MarshalByRefObject
    {
        double EPS = 1e-6;
        /// <summary>
        /// Etap 1:
        /// Obliczenie statystyki Kołmogorowa-Smirnowa dla dwóch uporządkowanych
        /// niemalejąco próbek.
        ///
        /// Rozwiązanie powinno działać w czasie O(n1 + n2),
        /// gdzie n1 i n2 są długościami odpowiednich próbek.
        /// </summary>
        /// <param name="sample1">Pierwsza próbka, uporządkowana niemalejąco.</param>
        /// <param name="sample2">Druga próbka, uporządkowana niemalejąco.</param>
        /// <returns>
        /// Wartość statystyki D = sup_x |F_1(x) - F_2(x)|.
        /// </returns>
        public double Stage1(double[] sample1, double[] sample2)
        {
            if (sample1[sample1.Length - 1] < sample2[0])
            {
                return 1.0;
            }


            int sample1Count = sample1.Length;
            int sample2Count = sample2.Length;

            int xIter = 0;
            int yIter = 0;

            double val = 0;

            int sumOfSamples1TillxIter = 0;
            int sumOfSamples2TillyIter = 0;

            double maxValOfD = double.MinValue;
            while (xIter < sample1Count && yIter < sample2Count)
            {
                val = Math.Min(sample1[xIter], sample2[yIter]) + EPS;
                while (xIter < sample1Count && sample1[xIter] <= val)
                {
                    xIter++;
                    sumOfSamples1TillxIter++;
                }

                while (yIter < sample2Count && sample2[yIter] <= val)
                {
                    yIter++;
                    sumOfSamples2TillyIter++;
                }

                if (maxValOfD < ECDF(sumOfSamples1TillxIter, sample1Count, sumOfSamples2TillyIter, sample2Count))
                {
                    maxValOfD = ECDF(sumOfSamples1TillxIter, sample1Count, sumOfSamples2TillyIter, sample2Count);
                }
            }

            if (xIter >= sample1Count)
            {
                while (yIter < sample2Count)
                {
                    val = sample2[yIter] + EPS;

                    while (yIter < sample2Count && sample2[yIter] <= val)
                    {
                        yIter++;
                        sumOfSamples2TillyIter++;
                    }

                    if (maxValOfD < ECDF(sumOfSamples1TillxIter, sample1Count, sumOfSamples2TillyIter, sample2Count))
                    {
                        maxValOfD = ECDF(sumOfSamples1TillxIter, sample1Count, sumOfSamples2TillyIter, sample2Count);
                    }
                }
            }
            else
            {
                while (xIter < sample1Count)
                {
                    val = sample1[xIter] + EPS;
                    while (xIter < sample1Count && sample1[xIter] <= val)
                    {
                        xIter++;
                        sumOfSamples1TillxIter++;
                    }

                    if (maxValOfD < ECDF(sumOfSamples1TillxIter, sample1Count, sumOfSamples2TillyIter, sample2Count))
                    {
                        maxValOfD = ECDF(sumOfSamples1TillxIter, sample1Count, sumOfSamples2TillyIter, sample2Count);
                    }
                }
            }

            return maxValOfD;
        }

        double ECDF(int x, int xcount, int y, int ycount)
        {
            double xi = 0, yi = 0;
            if (xcount != 0)
            {
                xi = (double)x / xcount;
            }

            if (ycount != 0)
            {
                yi = (double)y / ycount;
            }

            return Math.Abs(xi - yi);
        }


        /// <summary>
        /// Etap 2:
        /// Obliczenie największej odległości pomiędzy wartościami dowolnych dwóch
        /// empirycznych dystrybuant w tym samym punkcie x, dla K próbek.
        ///
        /// Rozwiązanie powinno działać w czasie O(nK), gdzie n jest łączną długością
        /// wszystkich próbek, a K jest liczbą próbek.
        /// </summary>
        /// <param name="samples">
        /// Tablica K próbek. Dla i = 0, 1, ..., K - 1 próbka samples[i]
        /// ma długość n_i i jest uporządkowana niemalejąco.
        /// </param>
        /// <returns>
        /// Wartość statystyki D = sup_x (max_i F_i(x) - min_j F_j(x)).
        /// </returns>
        public double Stage2(double[][] samples)
        {
            // the so called pro-gamer moveeeee
            return Stage3(samples);
        }

        /// <summary>
        /// Etap 3:
        /// Obliczenie tej samej statystyki co w Etapie 2, ale z lepszą złożonością.
        ///
        /// Rozwiązanie powinno działać w czasie O(n log K), gdzie n jest łączną długością
        /// wszystkich próbek, a K jest liczbą próbek.
        /// </summary>
        /// <param name="samples">
        /// Tablica K próbek. Dla i = 0, 1, ..., K - 1 próbka samples[i]
        /// ma długość n_i i jest uporządkowana niemalejąco.
        /// </param>
        /// <returns>
        /// Wartość statystyki D = sup_x (max_i F_i(x) - min_j F_j(x)).
        /// </returns>
        // public double Stage3(double[][] samples)
        public double Stage3(double[][] samples)
        {
            int K = samples.Length;
            double maxD = 0.0;

            PriorityQueue<double, int> priorityKlule = new PriorityQueue<double, int>(K);
            int[] currentIndiciesForNextFromSamples = new int[K];
            double[] currentValForK = new double[K];

            SortedSet<(double val, int id)> sortedSet = new SortedSet<(double val, int id)>();

            for (int k = 0; k < K; k++)
            {
                priorityKlule.Insert(k, samples[k][0]);

                currentValForK[k] = 0.0;
                sortedSet.Add((0.0, k));
            }
            
            while (priorityKlule.Count > 0)
            {
                int topElIndex = priorityKlule.Peek();

                double currentXforThisIdxAndK = samples[topElIndex][currentIndiciesForNextFromSamples[topElIndex]];

                while (priorityKlule.Count > 0)
                {
                    int peekedIndex = priorityKlule.Peek();
                    double valOfPeekedIndex = samples[peekedIndex][currentIndiciesForNextFromSamples[peekedIndex]];

                    if (valOfPeekedIndex < currentXforThisIdxAndK + EPS)
                    {
                        int nextIndex = priorityKlule.Extract();

                        sortedSet.Remove((currentValForK[nextIndex], nextIndex));

                        currentIndiciesForNextFromSamples[nextIndex]++;
                        currentValForK[nextIndex] = (double)currentIndiciesForNextFromSamples[nextIndex] / samples[nextIndex].Length;

                        sortedSet.Add((currentValForK[nextIndex], nextIndex));

                        if (currentIndiciesForNextFromSamples[nextIndex] < samples[nextIndex].Length)
                        {
                            priorityKlule.Insert(nextIndex, samples[nextIndex][currentIndiciesForNextFromSamples[nextIndex]]);
                        }
                    }
                    else
                    {
                        break;
                    }
                }

                double currentTmpMaxD = sortedSet.Max.val - sortedSet.Min.val;
                if (currentTmpMaxD > maxD)
                {
                    maxD = currentTmpMaxD;
                }
            }

            return maxD;
        }
    }
}
