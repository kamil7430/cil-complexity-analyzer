using System;
using System.Collections.Generic;
using ASD.Graphs;

namespace ASD
{
    public class Lab12 : MarshalByRefObject
    {
        /// <summary>
        /// Etap 1:
        /// Obliczenie statystyki Kołmogorowa-Smirnowa dla dwóch uporządkowanych
        /// niemalejąco próbek.
        ///
        /// Rozwiązanie powinno działać w czasie O(n1 + n2),
        /// gdzie n1 i n2 są długościami odpowiednich próbek.
        /// </summary>
        /// <param name="sample1">Pierwsza próbka, uporządkowana niemalejąco.</param>
        /// <param name="sample2">Druga próbka, uporządkowana niemalejąco.</param>
        /// <returns>
        /// Wartość statystyki D = sup_x |F_1(x) - F_2(x)|.
        /// </returns>
        public double Stage1(double[] sample1, double[] sample2)
        {
            int i = 0;
            int j = 0;
            double maxi = 0;

            while (i < sample1.Length || j < sample2.Length)
            {
                double value;

                if (j == sample2.Length || (i < sample1.Length && sample1[i] < sample2[j]))
                    value = sample1[i];
                else
                    value = sample2[j];

                while (i < sample1.Length && sample1[i] <= value)
                    i++;

                while (j < sample2.Length && sample2[j] <= value)
                    j++;

                double f1 = i / (double)sample1.Length;
                double f2 = j / (double)sample2.Length;

                double d = Math.Abs(f1 - f2);
                if (d > maxi)
                    maxi = d;
            }

            return maxi;
        }

        /// <summary>
        /// Etap 2:
        /// Obliczenie największej odległości pomiędzy wartościami dowolnych dwóch
        /// empirycznych dystrybuant w tym samym punkcie x, dla K próbek.
        ///
        /// Rozwiązanie powinno działać w czasie O(nK), gdzie n jest łączną długością
        /// wszystkich próbek, a K jest liczbą próbek.
        /// </summary>
        /// <param name="samples">
        /// Tablica K próbek. Dla i = 0, 1, ..., K - 1 próbka samples[i]
        /// ma długość n_i i jest uporządkowana niemalejąco.
        /// </param>
        /// <returns>
        /// Wartość statystyki D = sup_x (max_i F_i(x) - min_j F_j(x)).
        /// </returns>
        public double Stage2(double[][] samples)
        {
            List<double> l = new List<double>();
            for (int i = 0; i < samples.Length; i++)
            {
                foreach(double j in samples[i])
                    l.Add((double)j);
            }
            l.Sort();
            double maxi = 0;
            int[] x = new int[samples.Length];
            for (int a = 0; a < samples.Length; a++)
            {
                x[a] = 0;
            }
            for (int i = 0; i < l.Count; i++)
            {
                double mini = 1;
                double maxi2 = 0;
                
                
                for(int j =0; j<samples.Length; j++)
                {
                    
                    while (x[j]<samples[j].Length && l[i] >= samples[j][x[j]])
                    {
                        x[j]++;
                    }
                    if ((double)x[j] / (double)samples[j].Length<mini)
                    {
                        mini = (double)x[j] / (double)samples[j].Length;
                    }
                    if ((double)x[j] / (double)samples[j].Length > maxi2)
                    {
                        maxi2 = (double)x[j] / (double)samples[j].Length;
                    }
                }
                
                double d = maxi2-mini;
                if (maxi < d) maxi = d;



            }

            return maxi;
        }

        /// <summary>
        /// Etap 3:
        /// Obliczenie tej samej statystyki co w Etapie 2, ale z lepszą złożonością.
        ///
        /// Rozwiązanie powinno działać w czasie O(n log K), gdzie n jest łączną długością
        /// wszystkich próbek, a K jest liczbą próbek.
        /// </summary>
        /// <param name="samples">
        /// Tablica K próbek. Dla i = 0, 1, ..., K - 1 próbka samples[i]
        /// ma długość n_i i jest uporządkowana niemalejąco.
        /// </param>
        /// <returns>
        /// Wartość statystyki D = sup_x (max_i F_i(x) - min_j F_j(x)).
        /// </returns>
        private class Node : IComparable<Node>
        {
            public double Value;
            public int Id;

            public Node(double value, int id)
            {
                Value = value;
                Id = id;
            }

            public int CompareTo(Node other)
            {
                int cmp = Value.CompareTo(other.Value);
                if (cmp != 0) return cmp;
                return Id.CompareTo(other.Id);
            }
        }
        public double Stage3(double[][] samples)
        {
            const double EPS = 1e-6;

            int K = samples.Length;

            int[] pos = new int[K];
            double[] F = new double[K];

            
            SortedSet<Node> nextValues = new SortedSet<Node>();

            SortedSet<Node> currentF = new SortedSet<Node>();

            for (int i = 0; i < K; i++)
            {
                pos[i] = 0;
                F[i] = 0.0;

                nextValues.Add(new Node(samples[i][0], i));
                currentF.Add(new Node(0.0, i));
            }

            double result = 0.0;

            while (nextValues.Count > 0)
            {
                double value = nextValues.Min.Value;

                while (nextValues.Count > 0 && Math.Abs(nextValues.Min.Value - value) < EPS)
                {
                    Node node = nextValues.Min;
                    nextValues.Remove(node);

                    int id = node.Id;
                    currentF.Remove(new Node(F[id], id));

                    while (pos[id] < samples[id].Length && samples[id][pos[id]] <= value + EPS)
                    {
                        pos[id]++;
                    }

                    F[id] = pos[id] / (double)samples[id].Length;

                    currentF.Add(new Node(F[id], id));
                    if (pos[id] < samples[id].Length)
                    {
                        nextValues.Add(new Node(samples[id][pos[id]], id));
                    }
                }

                double minF = currentF.Min.Value;
                double maxF = currentF.Max.Value;

                double d = maxF - minF;

                if (d > result)
                    result = d;
            }

            return result;
        }
    }
}
