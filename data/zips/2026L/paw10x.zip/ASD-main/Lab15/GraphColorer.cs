﻿using System;
using System.Collections.Generic;
using ASD.Graphs;

namespace ASD2
{
    public class GraphColorer : MarshalByRefObject
    {
        /// <summary>
        /// Metoda znajduje kolorowanie zadanego grafu g używające najmniejsze możliwej liczby kolorów.
        /// </summary>
        /// <param name="g">Graf (nieskierowany)</param>
        /// <returns>Liczba użytych kolorów i kolorowanie (coloring[i] to kolor wierzchołka i). Kolory mogą być dowolnymi liczbami całkowitymi.</returns>
        public (int numberOfColors, int[] coloring) FindBestColoring(Graph graph)
        {
            int n = graph.VertexCount;
            int[] degree = new int[n];
            int edgesTwice = 0;

            for (int v = 0; v < n; v++)
            {
                foreach (int _ in graph.OutNeighbors(v)) degree[v]++;
                edgesTwice += degree[v];
            }

            if (n == 0) return (0, Array.Empty<int>());
            if (edgesTwice == 0) return (1, new int[n]);
            if (edgesTwice == n * (n - 1))
            {
                int[] clique = new int[n];
                for (int v = 0; v < n; v++) clique[v] = v;
                return (n, clique);
            }

            int[] bestColoring = GreedyDsatur();
            int best = CountColors(bestColoring);
            if (best <= 2) return (best, bestColoring);

            int[] color = new int[n];
            int[] saturation = new int[n];
            bool[,] forbidden = new bool[n, best];
            int painted = 0, usedColors = 0;
            for (int i = 0; i < n; i++)
            {
                color[i] = -1;
            }


            Search();
            return (best, bestColoring);


            int[] GreedyDsatur()
            {
                int[] result = new int[n], sat = new int[n];
                bool[,] blocked = new bool[n, n];

                for (int i = 0; i < n; i++)
                {
                    result[i] = -1;
                }

                for (int i = 0; i < n; i++)
                {
                    int v = ChooseVertex(result, sat), c = 0;
                    while (blocked[v, c]) c++;
                    result[v] = c;

                    foreach (int u in graph.OutNeighbors(v))
                        if (result[u] == -1 && !blocked[u, c])
                        {
                            blocked[u, c] = true;
                            sat[u]++;
                        }
                }
                return result;
            }

            void Search()
            {
                if (usedColors >= best) return;
                if (painted == n)
                {
                    best = usedColors;
                    bestColoring = (int[])color.Clone();
                    return;
                }

                int v = ChooseVertex(color, saturation);
                for (int c = 0; c <= Math.Min(best - 1, usedColors); c++)
                    if (!forbidden[v, c]) TryColor(v, c);
            }

            void TryColor(int v, int c)
            {
                int oldUsedColors = usedColors;
                List<int> changed = new List<int>();

                color[v] = c;
                painted++;
                usedColors = Math.Max(usedColors, c + 1);

                foreach (int u in graph.OutNeighbors(v))
                    if (color[u] == -1 && !forbidden[u, c])
                    {
                        forbidden[u, c] = true;
                        saturation[u]++;
                        changed.Add(u);
                    }

                Search();

                foreach (int u in changed)
                {
                    forbidden[u, c] = false;
                    saturation[u]--;
                }
                color[v] = -1;
                painted--;
                usedColors = oldUsedColors;
            }

            int ChooseVertex(int[] coloring, int[] sat)
            {
                int bestVertex = -1;
                for (int v = 0; v < n; v++)
                    if (coloring[v] == -1 && (bestVertex == -1 ||
                        sat[v] > sat[bestVertex] ||
                        sat[v] == sat[bestVertex] && degree[v] > degree[bestVertex]))
                        bestVertex = v;
                return bestVertex;
            }

            int CountColors(int[] coloring)
            {
                int result = 0;
                for (int v = 0; v < n; v++) result = Math.Max(result, coloring[v] + 1);
                return result;
            }
        }


    }
}