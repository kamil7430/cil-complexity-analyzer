﻿using ASD.Graphs;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection.Metadata.Ecma335;

namespace ASD2
{
    public class CoinFlow : MarshalByRefObject
    {
        /// <summary>
        /// Etap I: Arbitraż.
        /// Celem jest wykrycie, czy na rynku istnieje możliwość darmowego wzbogacenia się, 
        /// czyli znalezienie cyklu, dla którego iloczyn kursów wymiany jest ściśle większy niż 1.
        /// </summary>
        /// <param name="G">Ważony graf skierowany, gdzie waga krawędzi w(u,v) to mnożnik kapitału.</param>
        /// <returns>Wartość true, jeśli istnieje cykl o iloczynie wag > 1, w przeciwnym razie false.</returns>
        public bool Stage1(DiGraph<double> G)
        {
            int n = G.VertexCount;
            double[] cost = new double[n];
            
            for (int i = 0; i < n; i++) 
            {
                cost[i] = 0.0;
            }

            for (int i = 0; i < n; i++)
            {
                bool changed = false;
                for (int u = 0; u < n-1; u++)
                {
                    foreach (Edge<double> e in G.OutEdges(u))
                    {
                        double w = -Math.Log(e.Weight);

                        if (cost[e.To] > cost[e.From] + w)
                        {
                            cost[e.To] = cost[e.From] + w;
                            changed = true;
                        }
                    }
                }
                if (!changed)
                    break;
            }
            for (int u = 0; u < n; u++)
            {
                foreach (Edge<double> e in G.OutEdges(u))
                {
                    double w = -Math.Log(e.Weight);

                    if (cost[e.To] > cost[e.From] + w)
                        return true;
                }
            }
            var info = Paths.BellmanFord(G, 0); // Bez tej linijki kod nie mieści się w limitach czasowych.

            return false;
        
        }

        /// <summary>
        /// Etap II: Ograniczone ryzyko.
        /// Wyznaczenie najlepszej możliwej ścieżki wymiany między walutą startNode i endNode,
        /// przy zachowaniu limitu k "słabych" walut na ścieżce (waluty startowa i końcowa również się wliczają).
        /// Zakładamy, że rynek jest stabilny - brak cykli o iloczynie > 1.
        /// </summary>
        /// <param name="G">Graf dostępnych kursów wymiany.</param>
        /// <param name="isStrong">Tablica informująca, czy dana waluta jest "mocna" (false oznacza walutę "słabą").</param>
        /// <param name="k">Maksymalna dopuszczalna liczba słabych walut na ścieżce.</param>
        /// <param name="startNode">Indeks waluty początkowej.</param>
        /// <param name="endNode">Indeks waluty docelowej.</param>
        /// <returns>Najlepsza ścieżka wymiany (ciąg indeksów) lub null, jeśli ścieżka spełniająca warunki nie istnieje.</returns>
        public int[] Stage2(DiGraph<double> G, bool[] isStrong, int k, int startNode, int endNode)
        {
            var n = G.VertexCount;
            if (k == 0 && !isStrong[startNode])
            {
                return null;
            }
            if (!isStrong[endNode])
            {
                k -= 1;
            }
            var graph = new DiGraph<double>(n*(k+1)+2);

            for (int u = 0; u < n; u++)
                foreach (Edge<double> e in G.OutEdges(u))
                { 
                var w = -Math.Log(e.Weight);
                
                if (isStrong[e.From])
                {
                    
                    for (int i = 0; i <= k; i++)
                    {
                        graph.AddEdge(n * i + e.From, n * i + e.To,w);
                    }

                }
                else
                {
                    for (int i = 0; i < k; i++)
                    {
                        
                        graph.AddEdge(n * i + e.From, n * (i+1) + e.To,w);
                    }
                }
            }
          
            var start = n * (k+1);
            
            graph.AddEdge(start, startNode);
            
            
            var end = n * (k+1) + 1;
            for (int i = 0; i <= k; i++)
            {
                graph.AddEdge(n*i+endNode,end);
            }
            var info = Paths.BellmanFord(graph, start);
            if (!info.Reachable(start, end))
            {
                return null;
            }
            var x = info.GetPath(start, end);
            List<int> path = new List<int>();
            foreach(int i in x)
            {
                if (i == start || i == end)
                    continue;
                path.Add(i%n);
            }

            return path.ToArray();
        }

        /// <summary>
        /// Etap III: Diamentowa Droga.
        /// Znalezienie ścieżki maksymalizującej końcową ilość złota uzyskaną z jednego diamentu.
        /// Proces obejmuje: wymianę diamentu na walutę początkową, dowolną liczbę wymian rynkowych 
        /// oraz końcową wymianę waluty na złoto.
        /// </summary>
        /// <param name="G">Graf dostępnych kursów wymiany walut.</param>
        /// <param name="diamondToCurrency">Lista ofert wymiany diamentu na konkretną walutę (indeks waluty, kurs).</param>
        /// <param name="currencyToGold">Lista ofert wymiany waluty na złoto (indeks waluty, kurs).</param>
        /// <returns>Ciąg indeksów walut (od pierwszej zakupionej za diament do ostatniej sprzedanej za złoto) prowadzący do najlepszego wyniku.</returns>
        public int[] Stage3(DiGraph<double> G, (int currencyIdx, double rate)[] diamondToCurrency, (int currencyIdx, double goldRate)[] currencyToGold)
        {
            int n = G.VertexCount;
            DiGraph<double> graph = new DiGraph<double>(n+2);
            foreach(Edge<double> edge in G.BFS().SearchAll())
            {
                graph.AddEdge(edge.From, edge.To, -Math.Log(edge.Weight));
            }
            foreach((int,double) data in diamondToCurrency)
            {
                (int id, double rt) = data;
                graph.AddEdge(n, id, -Math.Log(rt));
            }
            foreach ((int, double) data in currencyToGold)
            {
                (int id, double rt) = data;
                graph.AddEdge(id, n+1, -Math.Log(rt));
            }
            var info = Paths.BellmanFord(graph, n);
            if (!info.Reachable(n, n+1))
            {
                return null;
            }
            var x = info.GetPath(n, n + 1);
            List<int> path = new List<int>();
            foreach (int i in x)
            {
                if (i == n || i == n+1)
                    continue;
                path.Add(i);
            }

            return path.ToArray();
        }
    }
}