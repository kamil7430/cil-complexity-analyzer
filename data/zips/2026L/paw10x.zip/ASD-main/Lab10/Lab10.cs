using ASD.Graphs;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ASD
{
    public class Lab10 : MarshalByRefObject
    {
        /// <summary>
        /// Etap 1: Szukanie najmniejszego zbioru wierzchołków S, takiego że G - S jest lasem.
        /// </summary>
        /// <param name="G">Graf nieskierowany; wierzchołki = skrzyżowania, krawędzie = rury</param>
        /// <param name="maxBudget">Górne ograniczenie na rozmiar szukanego rozwiązania</param>
        /// <param name="S">Najmniejsza tablica wierzchołków S taka, że G - S jest lasem</param>
        /// <returns>Rozmiar najmniejszego zbioru S</returns>
        public int Stage1(Graph G, int maxBudget, out int[] S)
        {
            int n = G.VertexCount;
            int[] cost = new int[n];

            for (int i = 0; i < n; i++)
                cost[i] = 1;

            return Solve(G, cost, maxBudget, false, out S);
        }

        /// <summary>
        /// Etap 2: Szukanie zbioru wierzchołków S, takiego że G - S jest lasem, o minimalnym łącznym koszcie.
        /// </summary>
        /// <param name="G">Graf nieskierowany; wierzchołki = skrzyżowania, krawędzie = rury</param>
        /// <param name="cost">Koszt montażu zaworu w każdym wierzchołku (cost[v] >= 0)</param>
        /// <param name="maxBudget">Górne ograniczenie kosztu szukanego rozwiązania</param>
        /// <param name="S">Tablica wierzchołków S o minimalnym łącznym koszcie, taka że G - S jest lasem</param>
        /// <returns>Suma kosztów montażu zaworów w wierzchołkach z S</returns>
        public int Stage2(Graph G, int[] cost, int maxBudget, out int[] S)
        {
            return Solve(G, cost, maxBudget, true, out S);
        }

        private class EdgeInfo
        {
            public int A;
            public int B;

            public int Middle;
        }

        private int Solve(Graph G, int[] cost, int maxBudget, bool weighted, out int[] S)
        {
            int n = G.VertexCount;

            int[][] adj = new int[n][];

            for (int v = 0; v < n; v++)
                adj[v] = G.OutNeighbors(v).ToArray();

            bool[] removed = new bool[n];
            List<int> chosen = new List<int>();

            if (weighted)
            {
                for (int v = 0; v < n; v++)
                {
                    if (cost[v] == 0)
                    {
                        removed[v] = true;
                        chosen.Add(v);
                    }
                }
            }

            int bestCost = maxBudget + 1;
            int[] bestSet = null;

            GreedyImprove(adj, cost, removed, chosen, maxBudget, ref bestCost, ref bestSet, 0);
            GreedyImprove(adj, cost, removed, chosen, maxBudget, ref bestCost, ref bestSet, 1);

            HashSet<string> seen = new HashSet<string>();

            void Search(int currentCost)
            {
                if (currentCost >= bestCost)
                    return;

                if (currentCost > maxBudget)
                    return;

                string state = BuildStateKey(removed);

                if (seen.Contains(state))
                    return;

                seen.Add(state);

                bool[] core;
                int[] degree;
                int coreSize;
                int edges;
                int components;

                BuildCore(adj, removed, out core, out degree, out coreSize, out edges, out components);

                if (coreSize == 0)
                {
                    bestCost = currentCost;
                    bestSet = chosen.ToArray();
                    return;
                }

                int lowerBound = LowerBound(cost, weighted, core, degree, coreSize, edges, components);

                if (currentCost + lowerBound >= bestCost)
                    return;

                if (currentCost + lowerBound > maxBudget)
                    return;

                int forced = ForcedSimpleCycle(adj, core, degree, cost);

                if (forced != -1)
                {
                    TryRemoveVertex(forced, currentCost);
                    return;
                }

                int[] cliqueDelete = ForcedClique(adj, core, degree, cost);

                if (cliqueDelete != null)
                {
                    int addCost = 0;

                    foreach (int v in cliqueDelete)
                        addCost += cost[v];

                    if (currentCost + addCost < bestCost && currentCost + addCost <= maxBudget)
                    {
                        foreach (int v in cliqueDelete)
                        {
                            removed[v] = true;
                            chosen.Add(v);
                        }

                        Search(currentCost + addCost);

                        for (int i = cliqueDelete.Length - 1; i >= 0; i--)
                        {
                            int v = cliqueDelete[i];
                            removed[v] = false;
                            chosen.RemoveAt(chosen.Count - 1);
                        }
                    }

                    return;
                }

                List<int> candidates = CompressedCycleCandidates(adj, core, degree, cost);

                if (candidates == null || candidates.Count == 0)
                {
                    bestCost = currentCost;
                    bestSet = chosen.ToArray();
                    return;
                }

                candidates.Sort((a, b) =>
                {
                    if (weighted)
                    {
                        int cmp = cost[a].CompareTo(cost[b]);

                        if (cmp != 0)
                            return cmp;
                    }

                    return degree[b].CompareTo(degree[a]);
                });

                foreach (int v in candidates)
                    TryRemoveVertex(v, currentCost);
            }

            void TryRemoveVertex(int v, int currentCost)
            {
                int nextCost = currentCost + cost[v];

                if (nextCost >= bestCost)
                    return;

                if (nextCost > maxBudget)
                    return;

                removed[v] = true;
                chosen.Add(v);

                Search(nextCost);

                chosen.RemoveAt(chosen.Count - 1);
                removed[v] = false;
            }

            Search(0);

            if (bestSet == null)
            {
                S = null;
                return -1;
            }

            S = bestSet;
            return bestCost;
        }

        private static string BuildStateKey(bool[] removed)
        {
            char[] key = new char[removed.Length];

            for (int i = 0; i < removed.Length; i++)
            {
                if (removed[i])
                    key[i] = '1';
                else
                    key[i] = '0';
            }

            return new string(key);
        }

        private static void GreedyImprove(
            int[][] adj,
            int[] cost,
            bool[] removed,
            List<int> chosen,
            int maxBudget,
            ref int bestCost,
            ref int[] bestSet,
            int mode)
        {
            int total;
            int[] set = Greedy(adj, cost, removed, mode, out total);

            if (total <= maxBudget && total < bestCost)
            {
                bestCost = total;

                List<int> result = new List<int>(chosen);
                result.AddRange(set);

                bestSet = result.ToArray();
            }
        }

        private static int[] Greedy(
            int[][] adj,
            int[] cost,
            bool[] initiallyRemoved,
            int mode,
            out int total)
        {
            int n = adj.Length;

            bool[] removed = new bool[n];
            Array.Copy(initiallyRemoved, removed, n);

            List<int> result = new List<int>();
            total = 0;

            while (true)
            {
                bool[] core;
                int[] degree;
                int coreSize;
                int edges;
                int components;

                BuildCore(adj, removed, out core, out degree, out coreSize, out edges, out components);

                if (coreSize == 0)
                    break;

                int forced = ForcedSimpleCycle(adj, core, degree, cost);

                if (forced != -1)
                {
                    removed[forced] = true;
                    result.Add(forced);
                    total += cost[forced];
                    continue;
                }

                List<int> candidates = CompressedCycleCandidates(adj, core, degree, cost);

                if (candidates == null || candidates.Count == 0)
                    break;

                int best = candidates[0];

                foreach (int v in candidates)
                {
                    if (mode == 0)
                    {
                        if (cost[v] < cost[best])
                        {
                            best = v;
                        }
                        else if (cost[v] == cost[best] && Degree(adj, v, removed) > Degree(adj, best, removed))
                        {
                            best = v;
                        }
                    }
                    else
                    {
                        int gainV = Math.Max(1, Degree(adj, v, removed) - 1);
                        int gainBest = Math.Max(1, Degree(adj, best, removed) - 1);

                        if ((long)cost[v] * gainBest < (long)cost[best] * gainV)
                            best = v;
                    }
                }

                removed[best] = true;
                result.Add(best);
                total += cost[best];
            }

            return result.ToArray();
        }

        private static void BuildCore(
            int[][] adj,
            bool[] removed,
            out bool[] core,
            out int[] degree,
            out int coreSize,
            out int edges,
            out int components)
        {
            int n = adj.Length;

            core = new bool[n];
            degree = new int[n];

            Queue<int> queue = new Queue<int>();

            for (int v = 0; v < n; v++)
                core[v] = !removed[v];

            for (int v = 0; v < n; v++)
            {
                if (!core[v])
                    continue;

                foreach (int u in adj[v])
                {
                    if (core[u])
                        degree[v]++;
                }

                if (degree[v] <= 1)
                    queue.Enqueue(v);
            }

            while (queue.Count > 0)
            {
                int v = queue.Dequeue();

                if (!core[v])
                    continue;

                if (degree[v] > 1)
                    continue;

                core[v] = false;

                foreach (int u in adj[v])
                {
                    if (!core[u])
                        continue;

                    degree[u]--;

                    if (degree[u] == 1)
                        queue.Enqueue(u);
                }
            }

            coreSize = 0;
            int degreeSum = 0;

            for (int v = 0; v < n; v++)
            {
                if (!core[v])
                    continue;

                coreSize++;
                degreeSum += degree[v];
            }

            edges = degreeSum / 2;

            components = CountComponents(adj, core);
        }

        private static int CountComponents(int[][] adj, bool[] core)
        {
            int n = adj.Length;

            bool[] visited = new bool[n];
            int components = 0;

            for (int start = 0; start < n; start++)
            {
                if (!core[start] || visited[start])
                    continue;

                components++;

                Queue<int> queue = new Queue<int>();
                queue.Enqueue(start);
                visited[start] = true;

                while (queue.Count > 0)
                {
                    int v = queue.Dequeue();

                    foreach (int u in adj[v])
                    {
                        if (core[u] && !visited[u])
                        {
                            visited[u] = true;
                            queue.Enqueue(u);
                        }
                    }
                }
            }

            return components;
        }

        private static int LowerBound(
            int[] cost,
            bool weighted,
            bool[] core,
            int[] degree,
            int coreSize,
            int edges,
            int components)
        {
            int cyclesRank = edges - coreSize + components;

            if (cyclesRank <= 0)
                return 0;

            List<int> gains = new List<int>();

            for (int v = 0; v < core.Length; v++)
            {
                if (core[v])
                    gains.Add(Math.Max(1, degree[v] - 1));
            }

            gains.Sort();
            gains.Reverse();

            if (!weighted)
            {
                int sum = 0;

                for (int i = 0; i < gains.Count; i++)
                {
                    sum += gains[i];

                    if (sum >= cyclesRank)
                        return i + 1;
                }

                return gains.Count;
            }

            int minCost = int.MaxValue;

            for (int v = 0; v < core.Length; v++)
            {
                if (core[v])
                    minCost = Math.Min(minCost, cost[v]);
            }

            int neededVertices = 0;
            int removedCycles = 0;

            while (removedCycles < cyclesRank && neededVertices < gains.Count)
            {
                removedCycles += gains[neededVertices];
                neededVertices++;
            }

            return neededVertices * minCost;
        }

        private static int ForcedSimpleCycle(int[][] adj, bool[] core, int[] degree, int[] cost)
        {
            int n = adj.Length;

            bool[] visited = new bool[n];

            for (int start = 0; start < n; start++)
            {
                if (!core[start] || visited[start])
                    continue;

                Queue<int> queue = new Queue<int>();
                List<int> component = new List<int>();

                visited[start] = true;
                queue.Enqueue(start);

                bool simpleCycle = true;

                while (queue.Count > 0)
                {
                    int v = queue.Dequeue();
                    component.Add(v);

                    if (degree[v] != 2)
                        simpleCycle = false;

                    foreach (int u in adj[v])
                    {
                        if (core[u] && !visited[u])
                        {
                            visited[u] = true;
                            queue.Enqueue(u);
                        }
                    }
                }

                if (simpleCycle)
                {
                    int cheapest = component[0];

                    foreach (int v in component)
                    {
                        if (cost[v] < cost[cheapest])
                            cheapest = v;
                    }

                    return cheapest;
                }
            }

            return -1;
        }

        private static int[] ForcedClique(int[][] adj, bool[] core, int[] degree, int[] cost)
        {
            int n = adj.Length;

            bool[] visited = new bool[n];

            for (int start = 0; start < n; start++)
            {
                if (!core[start] || visited[start])
                    continue;

                Queue<int> queue = new Queue<int>();
                List<int> component = new List<int>();

                visited[start] = true;
                queue.Enqueue(start);

                while (queue.Count > 0)
                {
                    int v = queue.Dequeue();
                    component.Add(v);

                    foreach (int u in adj[v])
                    {
                        if (core[u] && !visited[u])
                        {
                            visited[u] = true;
                            queue.Enqueue(u);
                        }
                    }
                }

                int count = component.Count;

                if (count < 4)
                    continue;

                bool isClique = true;

                foreach (int v in component)
                {
                    if (degree[v] != count - 1)
                    {
                        isClique = false;
                        break;
                    }
                }

                if (!isClique)
                    continue;

                component.Sort((a, b) => cost[b].CompareTo(cost[a]));

                List<int> toDelete = new List<int>();

                for (int i = 2; i < component.Count; i++)
                    toDelete.Add(component[i]);

                return toDelete.ToArray();
            }

            return null;
        }

        private static List<int> CompressedCycleCandidates(
            int[][] adj,
            bool[] core,
            int[] degree,
            int[] cost)
        {
            int n = adj.Length;

            bool[] isBranch = new bool[n];
            List<int>[] compressedAdj = new List<int>[n];
            List<EdgeInfo> compressedEdges = new List<EdgeInfo>();

            for (int v = 0; v < n; v++)
            {
                if (core[v] && degree[v] != 2)
                {
                    isBranch[v] = true;
                    compressedAdj[v] = new List<int>();
                }
            }

            HashSet<string> usedEdges = new HashSet<string>();

            for (int start = 0; start < n; start++)
            {
                if (!isBranch[start])
                    continue;

                foreach (int first in adj[start])
                {
                    if (!core[first])
                        continue;

                    string edgeKey = MakeEdgeKey(start, first);

                    if (usedEdges.Contains(edgeKey))
                        continue;

                    int previous = start;
                    int current = first;

                    int cheapestMiddle = -1;
                    int cheapestMiddleCost = int.MaxValue;

                    usedEdges.Add(edgeKey);

                    while (!isBranch[current])
                    {
                        if (cost[current] < cheapestMiddleCost)
                        {
                            cheapestMiddleCost = cost[current];
                            cheapestMiddle = current;
                        }

                        int next = -1;

                        foreach (int x in adj[current])
                        {
                            if (core[x] && x != previous)
                            {
                                next = x;
                                break;
                            }
                        }

                        if (next == -1)
                            break;

                        usedEdges.Add(MakeEdgeKey(current, next));

                        previous = current;
                        current = next;
                    }

                    EdgeInfo newEdge = new EdgeInfo();
                    newEdge.A = start;
                    newEdge.B = current;
                    newEdge.Middle = cheapestMiddle;

                    int id = compressedEdges.Count;
                    compressedEdges.Add(newEdge);

                    compressedAdj[start].Add(id);

                    if (current != start)
                        compressedAdj[current].Add(id);
                }
            }

            for (int i = 0; i < compressedEdges.Count; i++)
            {
                if (compressedEdges[i].A == compressedEdges[i].B)
                {
                    List<int> oneEdgeCycle = new List<int>();
                    oneEdgeCycle.Add(i);

                    return CandidatesFromCompressedCycle(oneEdgeCycle, compressedEdges, cost, n);
                }
            }

            bool[] visited = new bool[n];
            int[] parentVertex = new int[n];
            int[] parentEdge = new int[n];

            for (int i = 0; i < n; i++)
            {
                parentVertex[i] = -1;
                parentEdge[i] = -1;
            }

            List<int> cycleEdges = null;

            bool Dfs(int v, int previousEdge)
            {
                visited[v] = true;

                foreach (int edgeId in compressedAdj[v])
                {
                    if (edgeId == previousEdge)
                        continue;

                    EdgeInfo edge = compressedEdges[edgeId];

                    int u;

                    if (edge.A == v)
                        u = edge.B;
                    else
                        u = edge.A;

                    if (!visited[u])
                    {
                        parentVertex[u] = v;
                        parentEdge[u] = edgeId;

                        if (Dfs(u, edgeId))
                            return true;
                    }
                    else
                    {
                        cycleEdges = new List<int>();
                        cycleEdges.Add(edgeId);

                        int x = v;

                        while (x != u && x != -1)
                        {
                            cycleEdges.Add(parentEdge[x]);
                            x = parentVertex[x];
                        }

                        if (x == u)
                            return true;
                    }
                }

                return false;
            }

            for (int v = 0; v < n; v++)
            {
                if (!isBranch[v])
                    continue;

                if (visited[v])
                    continue;

                if (Dfs(v, -1))
                    return CandidatesFromCompressedCycle(cycleEdges, compressedEdges, cost, n);
            }

            return null;
        }

        private static List<int> CandidatesFromCompressedCycle(
            List<int> cycleEdges,
            List<EdgeInfo> compressedEdges,
            int[] cost,
            int n)
        {
            bool[] added = new bool[n];
            List<int> result = new List<int>();

            void AddVertex(int v)
            {
                if (v < 0)
                    return;

                if (added[v])
                    return;

                added[v] = true;
                result.Add(v);
            }

            foreach (int edgeId in cycleEdges)
            {
                EdgeInfo edge = compressedEdges[edgeId];

                AddVertex(edge.A);
                AddVertex(edge.B);

                if (edge.Middle != -1)
                {
                    int cheaperEndpointCost = Math.Min(cost[edge.A], cost[edge.B]);

                    if (cost[edge.Middle] < cheaperEndpointCost)
                        AddVertex(edge.Middle);
                }
            }

            return result;
        }

        private static string MakeEdgeKey(int a, int b)
        {
            if (a > b)
            {
                int temp = a;
                a = b;
                b = temp;
            }

            return a + "-" + b;
        }

        private static int Degree(int[][] adj, int v, bool[] removed)
        {
            int result = 0;

            foreach (int u in adj[v])
            {
                if (!removed[u])
                    result++;
            }

            return result;
        }
    }
}