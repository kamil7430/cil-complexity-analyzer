﻿using System;
using ASD.Graphs;
using ASD;
using System.Collections.Generic;

namespace ASD
{

    public class Lab04 : System.MarshalByRefObject
    {
        /// <summary>
        /// Etap 1 - szukanie trasy z miasta start_v do miasta end_v, startując w dniu day
        /// </summary>
        /// <param name="g">Ważony graf skierowany będący mapą</param>
        /// <param name="start_v">Indeks wierzchołka odpowiadającego miastu startowemu</param>
        /// <param name="end_v">Indeks wierzchołka odpowiadającego miastu docelowemu</param>
        /// <param name="day">Dzień startu (w tym dniu należy wyruszyć z miasta startowego)</param>
        /// <param name="days_number">Liczba dni uwzględnionych w rozkładzie (tzn. wagi krawędzi są z przedziału [0, days_number-1])</param>
        /// <returns>(result, route) - result ma wartość true gdy podróż jest możliwa, wpp. false, 
        /// route to tablica z indeksami kolejno odwiedzanych miast (pierwszy indeks to indeks miasta startowego, ostatni to indeks miasta docelowego),
        /// jeżeli result == false to route ustawiamy na null</returns>


        public (bool result, int[] route) Lab04_FindRoute(DiGraph<int> g, int start_v, int end_v, int day, int days_number)
        {
            DiGraph graph = new DiGraph(g.VertexCount * days_number);
            for (int i = 0; i < g.VertexCount; i++)
            {
                foreach(Edge<int> edge in g.OutEdges(i))
                {
                    graph.AddEdge(edge.From * days_number + edge.Weight, edge.To * days_number + ((edge.Weight+1)%days_number));
                }
            }
            int[] prev = new int[graph.VertexCount];
            List<int> pathlist = new List<int>();
            for (int i = 0;i < graph.VertexCount; i++)
            {
                prev[i] = -1;
            }
            foreach(Edge x in graph.BFS().SearchFrom(start_v*days_number+day))
            {
                prev[x.To] = x.From;
                if (x.To / days_number == end_v)
                {
                    int p = x.To;
                    pathlist.Add(p / days_number);
                    while (p != start_v*days_number+day)
                    {
                        p = prev[p];
                        pathlist.Add(p/days_number);
                    }
                    pathlist.Reverse();
                    return (true, pathlist.ToArray());
                }
            }
            return (false, null);
        }

        /// <summary>
        /// Etap 2 - szukanie trasy z jednego z miast z tablicy start_v do jednego z miast z tablicy end_v (startować można w dowolnym dniu)
        /// </summary>
        /// <param name="g">Ważony graf skierowany będący mapą</param>
        /// <param name="start_v">Tablica z indeksami wierzchołków startowych (trasę trzeba zacząć w jednym z nich)</param>
        /// <param name="end_v">Tablica z indeksami wierzchołków docelowych (trasę trzeba zakończyć w jednym z nich)</param>
        /// <param name="days_number">Liczba dni uwzględnionych w rozkładzie (tzn. wagi krawędzi są z przedziału [0, days_number-1])</param>
        /// <returns>(result, route) - result ma wartość true gdy podróż jest możliwa, wpp. false, 
        /// route to tablica z indeksami kolejno odwiedzanych miast (pierwszy indeks to indeks miasta startowego, ostatni to indeks miasta docelowego),
        /// jeżeli result == false to route ustawiamy na null</returns>
        
        public (bool result, int[] route) Lab04_FindRouteSets(DiGraph<int> g, int[] start_v, int[] end_v, int days_number)
        {
            DiGraph graph = new DiGraph(g.VertexCount * days_number);
            for (int i = 0; i < g.VertexCount; i++)
            {
                foreach (Edge<int> edge in g.OutEdges(i))
                {
                    graph.AddEdge(edge.From * days_number + edge.Weight, edge.To * days_number + ((edge.Weight + 1) % days_number));
                }
            }
            bool[] isEnd = new bool[g.VertexCount];
            foreach (int v in end_v)
                isEnd[v] = true;
            bool[] isStart = new bool[graph.VertexCount];
            foreach (int v in start_v)
            {
                for (int i = 0; i < days_number; i++)
                {
                    isStart[v * days_number + i] = true;
                }
            }
            int[] visited = new int[graph.VertexCount];
            int[] prev = new int[graph.VertexCount];
            Queue<int> queue = new Queue<int>();
            List<int> pathlist = new List<int>();
            foreach (int i in start_v) {
                for (int j = 0; j < days_number;j++)
                {
                    queue.Enqueue(i*days_number+j);
                } 
            }
            while (queue.Count>0)
            {
                int x = queue.Dequeue();
                if (visited[x] == 1)
                {
                    continue;
                }
                visited[x] = 1;
                if (isEnd[x/days_number])
                {
                    int p = x;
                    pathlist.Add(p/days_number);
                        while (!isStart[p])
                        {
                            p = prev[p];
                            pathlist.Add(p / days_number);
                        }
                        pathlist.Reverse();
                    return (true, pathlist.ToArray());
                }
                foreach (int edge in graph.OutNeighbors(x))
                {
                    queue.Enqueue(edge);
                    prev[edge] = x;
                }
                
            }
            return (false, null);
        }
    }
}















































