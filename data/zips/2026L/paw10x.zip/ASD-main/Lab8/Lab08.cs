﻿using ASD.Graphs;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;
using System.Linq;

namespace ASD2
{
    public class TreasureTrackers : MarshalByRefObject
    {
        /// <summary>
        /// Etap I: Wybór dnia ekspedycji.
        /// Wyznaczenie pierwszego dnia, w którym cała ekspedycja będzie w stanie
        /// przejść przez podziemia.
        /// </summary>
        /// <param name="map">Graf skierowany reprezentujący połączenia pomiędzy komnatami w podziemiach.</param>
        /// <param name="startChamber">Wierzchołek będący wejściem do podziemi.</param>
        /// <param name="endChamber">Wierzchołek będący wyjściem z podziemi.</param>
        /// <param name="durability">Tablica utrzymująca wytrzymałość każdej komnaty.</param>
        /// <param name="opensOn">Tablica informująca, którego dnia otwiera się dana komnata.</param>
        /// <param name="expeditionSize">Rozmiar ekspedycji, chcącej przejść przez podziemia.</param>
        int In(int x) { return x * 2; }
        int Out(int x) { return x * 2 + 1; }

        public DiGraph<int> createMapforDayX(DiGraph map, int s, int t, int x, int[] d,int[] o,int cap)
        {
            DiGraph<int> G = new DiGraph<int>(map.VertexCount * 2 + 2);
            G.AddEdge(map.VertexCount * 2, In(s), cap);
            G.AddEdge(Out(t), map.VertexCount * 2 + 1, cap);
            for (int i = 0; i < map.VertexCount; i++)
            {
                if (o[i] > x)
                    continue;
                G.AddEdge(In(i), Out(i), d[i]);
                foreach (var dest in map.OutNeighbors(i))
                {
                    if (o[dest] <= x)
                        G.AddEdge(Out(i), In(dest), cap);
                }

            }
            return G;
        }

        public int? Stage1(DiGraph map, int startChamber, int endChamber, int[] durability, int[] opensOn, int expeditionSize)
        {
            int start = Math.Max(opensOn[startChamber], opensOn[endChamber]);
            var dur = opensOn.Distinct().OrderBy(x => x).ToArray();
            Array.Sort(dur);
            int l = 0;
            int r = dur.Length-1;
            while (l <= r)
            {
                int s = (l + r) / 2;
                int x = dur[s];
                if (dur[s] < start)
                {
                    l = s+1;
                    continue;
                }
                DiGraph<int> graph = createMapforDayX(map, startChamber, endChamber, x, durability,opensOn,expeditionSize);
                var (flowValue, f) = Flows.FordFulkerson(graph, map.VertexCount * 2, map.VertexCount * 2 + 1);
                if (flowValue >= expeditionSize)
                {
                    r = s;
                    if (r <= l)
                    {
                        return x;
                    }
                }
                else
                {
                    l = s + 1;
                }
            }

            return null;
        }

        /// <summary>
        /// Etap II: 
        /// Wyznaczenie minimalnej liczby poszukiwaczy skarbów,
        /// która będzie w stanie zebrać wszystkie skarby.
        /// </summary>
        /// <param name="map">Acykliczny graf skierowany reprezentujący połączenia pomiędzy komnatami w podziemiach.</param>
        /// <param name="startChamber">Wierzchołek będący wejściem do podziemi.</param>
        /// <param name="endChamber">Wierzchołek będący wyjściem z podziemi.</param>
        /// <param name="durability">Tablica utrzymująca wytrzymałość każdej komnaty.</param>


        void AddEdgeWithLowerBound(NetworkWithCosts<int, int> G, int[] balance,int u, int v, int low, int high,int cost)
        {
            G.AddEdge(u, v, high - low, cost);
            balance[u] -= low;
            balance[v] += low;
        }
        NetworkWithCosts<int, int> BuildStage2Graph(DiGraph map, int start, int end, int[] durability, out int SS, out int TT, out int demand)
        {
            int n = map.VertexCount;
            SS = 2 * n;
            TT = 2 * n + 1;

            var G = new NetworkWithCosts<int, int>(2 * n + 2);
            var balance = new int[2 * n + 2];

            int mini = Math.Min(durability[start], durability[end]);

            
            for (int v = 0; v < n; v++)
                AddEdgeWithLowerBound(G, balance, In(v), Out(v), 1, durability[v], 0);

            
            for (int v = 0; v < n; v++)
                foreach (var u in map.OutNeighbors(v))
                    AddEdgeWithLowerBound(G, balance, Out(v), In(u), 0, mini, 0);

            
            AddEdgeWithLowerBound(G, balance, Out(end), In(start), 0, mini, 1);

            demand = 0;
            for (int i = 0; i < balance.Length; i++)
            {
                if (balance[i] > 0)
                {
                    G.AddEdge(SS, i, balance[i], 0);
                    demand += balance[i];
                }
                else if (balance[i] < 0)
                {
                    G.AddEdge(i, TT, -balance[i], 0);
                }
            }

            return G;
        }
        public int? Stage2(DiGraph map, int startChamber, int endChamber, int[] durability)
        {
            int n = map.VertexCount;


            int SS, TT, demand;
            var G = BuildStage2Graph(map, startChamber, endChamber, durability, out SS, out TT, out demand);

            var (flowValue, flowCost, flowGraph) = Flows.MinCostMaxFlow(G, SS, TT);

            if (flowValue != demand)
                return null;

            return flowCost;
        }
    }
}
