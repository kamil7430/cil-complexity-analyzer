using System;
using System.Collections.Generic;

namespace ASD
{
    public class Lab14 : MarshalByRefObject
    {
        /// <summary>Etap I</summary>
        /// <param name="text">Wejściowy ciąg znaków</param>
        /// <param name="pattern">Wzorzec do wyszukania najdłuższego pokrytego podsłowa ciągu `text` przez niego.</param>
        /// <param name="result">Najdłuższe podsłowo `text` pokryte przez `pattern`.</param>
        /// <returns>Długość najdłuższego podsłowa `text` pokrytego przez `pattern`.</returns>
        /// <summary>Etap I</summary>
        /// <param name="text">Wejściowy ciąg znaków</param>
        /// <param name="pattern">Wzorzec do wyszukania najdłuższego pokrytego podsłowa ciągu `text` przez niego.</param>
        /// <param name="result">Najdłuższe podsłowo `text` pokryte przez `pattern`.</param>
        /// <returns>Długość najdłuższego podsłowa `text` pokrytego przez `pattern`.</returns>
        public int Stage1(string text, string pattern, out string result)
        {
            result = "";

            int n = text.Length;
            int m = pattern.Length;

            if (n == 0 || m == 0 || m > n)
                return 0;



            int[] pi = ComputeP(pattern);

            int bestStartKmp = 0;
            int bestLenKmp = 0;

            int currentStartKmp = -1;
            int currentEndKmp = -1;

            int j = 0;

            for (int i = 0; i < n; i++)
            {
                char c = text[i];

                while (j > 0 && c != pattern[j])
                    j = pi[j - 1];

                if (c == pattern[j])
                    j++;

                if (j == m)
                {
                    int start = i - m + 1;
                    if (currentStartKmp == -1 || start > currentEndKmp + 1)
                    {
                        if (currentStartKmp != -1)
                        {
                            int currentLen = currentEndKmp - currentStartKmp + 1;

                            if (currentLen > bestLenKmp)
                            {
                                bestLenKmp = currentLen;
                                bestStartKmp = currentStartKmp;
                            }
                        }

                        currentStartKmp = start;
                    }
                    currentEndKmp = i;

                    j = pi[j - 1];
                }
            }

            if (currentStartKmp != -1)
            {
                int currentLen = currentEndKmp - currentStartKmp + 1;

                if (currentLen > bestLenKmp)
                {
                    bestLenKmp = currentLen;
                    bestStartKmp = currentStartKmp;
                }
            }

            if (bestLenKmp > 0)
                result = text.Substring(bestStartKmp, bestLenKmp);

            return bestLenKmp;
        }

        /// <summary>Etap II</summary>
        /// <param name="word">Wejściowe słowo.</param>
        /// <param name="result">Najkrótsze podsłowo pokrywające `word`.</param>
        /// <returns>Długość najkrótszego podsłowa pokrywającego `word`.</returns>
        public int Stage2(string word, out string result)
        {
            result = "";

            if (word == null)
                word = "";

            int n = word.Length;

            if (n == 0)
                return 0;

            int[] pi = ComputeP(word);

            int[] cover = new int[n + 1];

            int[] maxCovered = new int[n + 1];

            for (int i = 1; i <= n; i++)
            {

                int p = pi[i - 1];

                if (p == 0)
                {
                    cover[i] = i;
                }
                else
                {
                    int candidate = cover[p];

                    if (maxCovered[candidate] >= i - p)
                    {
                        cover[i] = candidate;
                    }
                    else
                    {
                        cover[i] = i;
                    }
                }

                maxCovered[cover[i]] = i;
            }

            int answer = cover[n];
            result = word.Substring(0, answer);

            return answer;
        }

        /// <summary>
        /// Algorytm KMP.
        /// Zwraca listę pozycji, na których pattern występuje w text.
        /// </summary>
        /// <param name="text">Tekst, w którym szukamy wzorca.</param>
        /// <param name="pattern">Wzorzec, którego szukamy.</param>
        /// <returns>Lista pozycji początkowych wystąpień pattern w text.</returns>
        private List<int> KMP(string text, string pattern)
        {
            List<int> positions = new List<int>();

            if (text == null)
                text = "";

            if (pattern == null)
                pattern = "";

            if (text.Length == 0 || pattern.Length == 0 || pattern.Length > text.Length)
                return positions;

            int[] pi = ComputeP(pattern);

            int j = 0;

            for (int i = 0; i < text.Length; i++)
            {
                while (j > 0 && text[i] != pattern[j])
                {
                    j = pi[j - 1];
                }

                if (text[i] == pattern[j])
                {
                    j++;
                }

                if (j == pattern.Length)
                {
                    positions.Add(i - pattern.Length + 1);
                    j = pi[j - 1];
                }
            }

            return positions;
        }


        private int[] ComputeP(string s)
        {
            int[] pi = new int[s.Length];

            for (int i = 1; i < s.Length; i++)
            {
                int j = pi[i - 1];

                while (j > 0 && s[i] != s[j])
                {
                    j = pi[j - 1];
                }

                if (s[i] == s[j])
                {
                    j++;
                }

                pi[i] = j;
            }

            return pi;
        }
    }
}