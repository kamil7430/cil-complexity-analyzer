﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

namespace ASD
{
    public class Lab02 : MarshalByRefObject
    {
        /// <summary>
        /// Optymalne rozmieszczenie parasolek w wariancie, w którym każda parasolka ma taki sam promień
        /// oraz mamy do dyspozycji tylko zadaną liczbę parasolek (rozmieszczenie parasolek nie wiąże się z żadnym kosztem)
        /// </summary>
        /// <param name="Z">Tablica zysków, Z[i] to zysk za pokrycie punktu o numerze i</param>
        /// <param name="umbrellaCount">Liczba dostępnych parasolek</param>
        /// <param name="umbrellaRadius">Promień parasolki (parasolka o promieniu r umieszczona w punkcie i pokrywa punkty i-r, i-r+1, ..., i+r)</param>
        /// <returns></returns>
        /// 

        public (int profit, int[] umbrellaPosition) Stage1(int[] Z, int umbrellaCount, int umbrellaRadius)
        {
            int len = Z.GetLength(0);
            if (len == 0 || umbrellaCount == 0)
                return (0, new int[0]);

            int[] prefixes = new int[len + 1];
            for (int i = 0; i < len; i++)
                prefixes[i + 1] = prefixes[i] + Z[i];
            int[,] dp = new int[len + 1,umbrellaCount+1];
            for (int i = 0; i < len+1; i++)
            {
                dp[i, 0] = 0;
            }
            for (int i = 0; i < umbrellaCount+1; i++)
            {
                dp[0, i] = 0;
            }
            int r = 1 + 2 * umbrellaRadius; 
            for (int i = 1; i <= len; i++)
            {
                for(int j = 1; j <= umbrellaCount; j++)
                {
                    dp[i, j] = dp[i-1, j];
                    int l = Math.Max(0,i-r);
                    int candidate = dp[l, j - 1] + prefixes[i] - prefixes[l];
                    if (candidate > dp[i, j])
                    {
                        dp[i, j] = candidate;
                    }
                }
            }
            var positions = new List<int>();
            
            int k = len;
            int m = umbrellaCount;
            while (k > 0&&m>0)
            {
                
                while (k>0&&dp[k - 1, m] == dp[k, m])
                {
                    k--;
                }
                k -= umbrellaRadius+1;
                positions.Add(Math.Max(k,0));

                k-= umbrellaRadius;
                m--;
            }



            return (dp[len, umbrellaCount], positions.ToArray());
        }


        /// <summary>
        /// Optymalne rozmieszczenie parasolek w wariancie, w którym mamy dostępne modele parasolek o różnych promieniach.
        /// Każdego modelu możemy użyć dowolną liczbę razy, jednak za każdym razem musimy ponieść jego koszt.
        /// </summary>
        /// <param name="Z">Tablica zysków, Z[i] to zysk za pokrycie punktu o numerze i</param>
        /// <param name="umbrellaType">Tablice dostępnych modeli parasolek, gdzie i-ty model ma promień umbrellaType[i].radius i koszt umbrellaType[i].cost</param>
        /// <returns></returns>
        /// 


            public (int profit, (int position, int model)[] umbrellas) Stage2(int[] Z, (int radius, int cost)[] umbrellaType)
            {

                int len = Z.Length;
                int m = umbrellaType.Length;

                if (len == 0 || m == 0)
                    return (0, new (int, int)[0]);

                int[] dp = new int[len + 1];
                int[] prefixes = new int[len + 1];
                int[] chosenmodel = new int[len + 1];
                int[] chosenpos = new int[len + 1];
                int[] prevstate = new int[len + 1]; 
                for (int i = 0; i < len; i++)
                    prefixes[i + 1] = prefixes[i] + Z[i];

                for (int j = 1; j <= len; j++)
                {
                
                    int maxi = dp[j-1];
                    chosenmodel[j] = -1;
                    chosenpos[j] = -1;
                    prevstate[j] = j - 1;
                    for (int model = 0; model < m; model++)
                    {
                        int radius = umbrellaType[model].radius;
                        int cost = umbrellaType[model].cost;

                        int zysk = dp[Math.Max(0, j - 1 - 2 * radius)] + prefixes[j] - prefixes[Math.Max(0, j - 1 - 2 * radius)] - cost;
                        if (zysk > maxi)
                        {
                            maxi = zysk;
                            chosenmodel[j] = model;
                            chosenpos[j] = Math.Max(j - radius-1,0);
                            prevstate[j] = Math.Max(0, j - 1 - 2 * radius);
                        }

                    }
                    dp[j] = maxi;
                }


            

                var result = new List<(int position, int model)>();
                int k = len;

                while (k > 0)
                {
                    if (chosenmodel[k] == -1)
                    {
                        k = k - 1;
                        if (k < 0)
                        {
                        break;
                        }
                    }
                    else
                    {

                        result.Add((chosenpos[k], chosenmodel[k]));
                        k = prevstate[k];
                    }
                }

                result.Reverse();

                return (dp[len], result.ToArray());
            }
    }
}
