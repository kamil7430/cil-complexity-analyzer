using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace ASD
{
    public class Lab02 : MarshalByRefObject
    {
        /// <summary>
        /// Etap 1 - Wyznaczenie ścieżki (seam) o minimalnym sumarycznym score.
        /// Ścieżka przebiega od górnego do dolnego wiersza obrazu.
        /// </summary>
        /// <param name="S">macierz score o wymiarach H x W, gdzie S[i, j] reprezentuje "ważność" piksela w wierszu i i kolumnie j</param>
        /// <returns>
        /// (int cost, (int, int)[] seam) - 
        /// cost: minimalny łączny koszt ścieżki (suma wartości pikseli);
        /// seam: tablica pozycji pikseli (włącznie z pikselem z pierwszego i ostatniego wiersza) tworzących ścieżkę.
        /// </returns>
        public (int cost, (int i, int j)[] seam) Stage1(int[,] S)
        {
            int H = S.GetLength(0);
            int W = S.GetLength(1);
            const int inf = int.MaxValue;

            // dp[i, j] = najmniejszy score by dojść do i, j
            int[,] dp = new int[H, W];
            (int i, int j)[] seam = new (int, int)[H];

            for (int i = 0; i < W; i++)
            {
                dp[0, i] = S[0, i];
            }

            for (int i = 1; i < H; i++)
            {
                for (int j = 0; j < W; j++)
                {
                    if (j == 0)
                    {
                        dp[i, j] = Math.Min(dp[i - 1, j], dp[i - 1, j + 1]) + S[i, j];
                        continue;
                    }

                    if (j == W - 1)
                    {
                        dp[i, j] = Math.Min(dp[i - 1, j], dp[i - 1, j - 1]) + S[i, j];
                        continue;
                    }

                    dp[i, j] = Math.Min(dp[i - 1, j - 1], Math.Min(dp[i - 1, j], dp[i - 1, j + 1])) + S[i, j];
                }
            }

            int cost = inf;
            for (int i = 0; i < W; i++)
            {
                if (dp[H - 1, i] < cost)
                {
                    cost = dp[H - 1, i];
                    seam[H - 1] = (H - 1, i);
                }
            }

            for (int i = H - 2; i >= 0; i--)
            {
                int prevj = seam[i + 1].j;
                if (prevj == 0)
                {
                    int m = Math.Min(dp[i, prevj], dp[i, prevj + 1]);
                    if (m == dp[i, prevj + 1])
                    {
                        seam[i] = (i, prevj + 1);
                    }
                    else
                    {
                        seam[i] = (i, prevj);
                    }

                    continue;
                }

                if (prevj == W - 1)
                {
                    int m = Math.Min(dp[i, prevj], dp[i, prevj - 1]);
                    if (m == dp[i, prevj - 1])
                    {
                        seam[i] = (i, prevj - 1);
                    }
                    else
                    {
                        seam[i] = (i, prevj);
                    }

                    continue;
                }

                int n = Math.Min(dp[i, prevj - 1], Math.Min(dp[i, prevj], dp[i, prevj + 1]));
                if (n == dp[i, prevj - 1])
                {
                    seam[i] = (i, prevj - 1);
                }
                else if (n == dp[i, prevj])
                {
                    seam[i] = (i, prevj);
                }
                else
                {
                    seam[i] = (i, prevj + 1);
                }
            }

            return (cost, seam);
        }

        /// <summary>
        /// Etap 2 - Wyznaczenie ścieżki (seam) o minimalnym sumarycznym score z uwzględnieniem kary za zmianę kierunku.
        /// Przy każdym przejściu, gdy kierunek ruchu różni się od poprzedniego, do łącznego kosztu dodawana jest kara K.
        /// Pierwszy krok (z pierwszego wiersza) nie podlega karze.
        /// </summary>
        /// <param name="S">macierz score o wymiarach H x W</param>
        /// <param name="K">kara za zmianę kierunku (K >= 1)</param>
        /// <returns>
        /// (int cost, (int, int)[] seam) - 
        /// cost: minimalny łączny koszt ścieżki (suma wartości pikseli oraz naliczonych kar);
        /// seam: tablica pozycji pikseli tworzących ścieżkę.
        /// </returns>
        public (int cost, (int i, int j)[] seam) Stage2(int[,] S, int K)
        {
            int H = S.GetLength(0);
            int W = S.GetLength(1);
            const int inf = int.MaxValue;

            // dp[i, j] = najmniejszy score by dojść do i, j jeśli przyszliśmy z lewej (l), środka (d), prawej (r)
            (int l, int d, int r)[,] dp = new (int, int, int)[H, W];
            (int i, int j)[] seam = new (int, int)[H];

            // pierwszy wiersz
            {
                for (int i = 0; i < W; i++)
                {
                    dp[0, i] = (S[0, i], S[0, i], S[0, i]);
                }

                dp[0, 0].l = inf;
                dp[0, W - 1].r = inf;
            }

            // drugi wiersz
            dp[1, 0] = (inf, dp[0, 0].d + S[1, 0], dp[0, 1].d + S[1, 0]);
            dp[1, W - 1] = (dp[0, W - 2].d + S[1, W - 1], dp[0, W - 1].d + S[1, W - 1], inf);
            for (int i = 1; i < W - 1; i++)
            {
                dp[1, i] = (dp[0, i - 1].d + S[1, i], dp[0, i].d + S[1, i], dp[0, i + 1].d + S[1, i]);
            }

            for (int i = 2; i < H; i++)
            {
                for (int j = 0; j < W; j++)
                {
                    var d1 = dp[i - 1, j].l == inf ? inf : dp[i - 1, j].l + K;
                    var d2 = dp[i - 1, j].d == inf ? inf : dp[i - 1, j].d;
                    var d3 = dp[i - 1, j].r == inf ? inf : dp[i - 1, j].r + K;

                    if (j == 0)
                    {
                        var b1 = dp[i - 1, j + 1].l == inf ? inf : dp[i - 1, j + 1].l + K;
                        var b2 = dp[i - 1, j + 1].d == inf ? inf : dp[i - 1, j + 1].d + K;
                        var b3 = dp[i - 1, j + 1].r == inf ? inf : dp[i - 1, j + 1].r;

                        dp[i, j].l = inf;
                        dp[i, j].d = Math.Min(d1, Math.Min(d2, d3)) + S[i, j];
                        dp[i, j].r = Math.Min(b1, Math.Min(b2, b3)) + S[i, j];
                        continue;
                    }

                    if (j == W - 1)
                    {
                        var b1 = dp[i - 1, j - 1].l == inf ? inf : dp[i - 1, j - 1].l;
                        var b2 = dp[i - 1, j - 1].d == inf ? inf : dp[i - 1, j - 1].d + K;
                        var b3 = dp[i - 1, j - 1].r == inf ? inf : dp[i - 1, j - 1].r + K;

                        dp[i, j].l = Math.Min(b1, Math.Min(b2, b3)) + S[i, j];
                        dp[i, j].d = Math.Min(d1, Math.Min(d2, d3)) + S[i, j];
                        dp[i, j].r = inf;
                        continue;
                    }

                    var l1 = dp[i - 1, j - 1].l == inf ? inf : dp[i - 1, j - 1].l;
                    var l2 = dp[i - 1, j - 1].d == inf ? inf : dp[i - 1, j - 1].d + K;
                    var l3 = dp[i - 1, j - 1].r == inf ? inf : dp[i - 1, j - 1].r + K;

                    var r1 = dp[i - 1, j + 1].l == inf ? inf : dp[i - 1, j + 1].l + K;
                    var r2 = dp[i - 1, j + 1].d == inf ? inf : dp[i - 1, j + 1].d + K;
                    var r3 = dp[i - 1, j + 1].r == inf ? inf : dp[i - 1, j + 1].r;

                    dp[i, j].l = Math.Min(l1, Math.Min(l2, l3)) + S[i, j];
                    dp[i, j].d = Math.Min(d1, Math.Min(d2, d3)) + S[i, j];
                    dp[i, j].r = Math.Min(r1, Math.Min(r2, r3)) + S[i, j];
                }
            }

            int cost = inf;
            // kierunek w którym powinniśmy iść -- lewo (-1), góra (0), prawo (1)
            int dir = -1;
            for (int i = 0; i < W; i++)
            {
                if (dp[H - 1, i].l < cost)
                {
                    cost = dp[H - 1, i].l;
                    seam[H - 1] = (H - 1, i);
                    dir = -1;
                }

                if (dp[H - 1, i].d < cost)
                {
                    cost = dp[H - 1, i].d;
                    seam[H - 1] = (H - 1, i);
                    dir = 0;
                }

                if (dp[H - 1, i].r < cost)
                {
                    cost = dp[H - 1, i].r;
                    seam[H - 1] = (H - 1, i);
                    dir = 1;
                }
            }

            for (int i = H - 2; i >= 0; i--)
            {
                int prevj = seam[i + 1].j;

                if (dir == -1)
                {
                    seam[i] = (i, prevj - 1);
                }
                else if (dir == 0)
                {
                    seam[i] = (i, prevj);
                }
                else
                {
                    seam[i] = (i, prevj + 1);
                }

                var v = dp[seam[i].i, seam[i].j];
                int l = v.l == inf ? inf : dir == -1 ? v.l : v.l + K;
                int d = v.d == inf ? inf : dir == 0 ? v.d : v.d + K;
                int r = v.r == inf ? inf : dir == 1 ? v.r : v.r + K;
                int m = Math.Min(l, Math.Min(d, r));
                if (m == l) dir = -1;
                else if (m == d) dir = 0;
                else dir = 1;
            }

            return (cost, seam);
        }
    }
}