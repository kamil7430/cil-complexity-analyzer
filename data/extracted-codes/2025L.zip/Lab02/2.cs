﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASD
{
    public class Lab02 : MarshalByRefObject
    {
        /// <summary>
        /// Etap 1 - Wyznaczenie ścieżki (seam) o minimalnym sumarycznym score.
        /// Ścieżka przebiega od górnego do dolnego wiersza obrazu.
        /// </summary>
        /// <param name="S">macierz score o wymiarach H x W, gdzie S[i, j] reprezentuje "ważność" piksela w wierszu i i kolumnie j</param>
        /// <returns>
        /// (int cost, (int, int)[] seam) - 
        /// cost: minimalny łączny koszt ścieżki (suma wartości pikseli);
        /// seam: tablica pozycji pikseli (włącznie z pikselem z pierwszego i ostatniego wiersza) tworzących ścieżkę.
        /// </returns>
        public (int cost, (int i, int j)[] seam) Stage1(int[,] S)
        {
            int H = S.GetLength(0);
            int W = S.GetLength(1);

            (int cost, (int i, int j))[,] paths = new (int cost, (int i, int j))[H, W];

            for (int j = 0; j < W; j++)
            {
                paths[0, j].cost = S[0, j];
            }

            for (int i = 1; i < H; i++)
            {
                for (int j = 0; j < W; j++)
                {
                    paths[i, j].cost = int.MaxValue;
                    if (IsViable(j - 1, W))
                    {
                        if (paths[i - 1, j - 1].cost + S[i, j] < paths[i, j].cost)
                        {
                            paths[i, j].cost = paths[i - 1, j - 1].cost + S[i, j];
                            paths[i, j].Item2.i = i - 1;
                            paths[i, j].Item2.j = j - 1;
                        }
                    }
                    if (IsViable(j, W))
                    {
                        if (paths[i - 1, j].cost + S[i, j] < paths[i, j].cost)
                        {
                            paths[i, j].cost = paths[i - 1, j].cost + S[i, j];
                            paths[i, j].Item2.i = i - 1;
                            paths[i, j].Item2.j = j;
                        }
                    }
                    if (IsViable(j + 1, W))
                    {
                        if (paths[i - 1, j + 1].cost + S[i, j] < paths[i, j].cost)
                        {
                            paths[i, j].cost = paths[i - 1, j + 1].cost + S[i, j];
                            paths[i, j].Item2.i = i - 1;
                            paths[i, j].Item2.j = j + 1;
                        }
                    }
                }
            }

            int indexi = H - 1;
            int indexj = 0;
            for (int j = 1; j < W; j++)
            {
                if (paths[H - 1, j].cost < paths[H - 1, indexj].cost)
                {
                    indexj = j;
                }
            }

            (int i, int j)[] seam = new (int i, int j)[H];
            int totalCost = paths[H-1, indexj].cost;
            seam[H - 1] = (indexi, indexj);
            while (indexi > 0)
            {
                seam[indexi - 1] = paths[indexi, indexj].Item2;
                indexj = paths[indexi, indexj].Item2.j;
                indexi--;
            }
            return (totalCost, seam);
        }

        public bool IsViable(int j, int Width)
        {
            return j >= 0 && j < Width;
        }

        /// <summary>
        /// Etap 2 - Wyznaczenie ścieżki (seam) o minimalnym sumarycznym score z uwzględnieniem kary za zmianę kierunku.
        /// Przy każdym przejściu, gdy kierunek ruchu różni się od poprzedniego, do łącznego kosztu dodawana jest kara K.
        /// Pierwszy krok (z pierwszego wiersza) nie podlega karze.
        /// </summary>
        /// <param name="S">macierz score o wymiarach H x W</param>
        /// <param name="K">kara za zmianę kierunku (K >= 1)</param>
        /// <returns>
        /// (int cost, (int, int)[] seam) - 
        /// cost: minimalny łączny koszt ścieżki (suma wartości pikseli oraz naliczonych kar);
        /// seam: tablica pozycji pikseli tworzących ścieżkę.
        /// </returns>
        public (int cost, (int i, int j)[] seam) Stage2(int[,] S, int K)
        {
            //Thread.Sleep(5000);

            int H = S.GetLength(0);
            int W = S.GetLength(1);

            if (K == 0 || H <= 2)
            {
                return Stage1(S);
            }

            // paths contains cost of the lowest cost paths using left(0), middle(1) and right(2) son to the i, j 
            (int cost, (int i, int j))[,,] paths = new (int cost, (int i, int j))[H, W, 3];

            // Fill first row
            for (int j = 0; j < W; j++)
            {
                paths[0, j, 0].cost = S[0, j];
                paths[0, j, 1].cost = S[0, j];
                paths[0, j, 2].cost = S[0, j];
            }

            // Fill second row
            for (int j = 0; j < W; j++)
            {
                paths[1, j, 0].cost = IsViable(j - 1, W) ? paths[0, j - 1, 0].cost + S[1, j] : int.MaxValue;
                paths[1, j, 1].cost = paths[0, j, 0].cost + S[1, j];
                paths[1, j, 2].cost = IsViable(j + 1, W) ? paths[0, j + 1, 0].cost + S[1, j] : int.MaxValue;
            }

            // Fill the rest
            for (int i = 2; i < H; i++)
            {
                for (int j = 0; j < W; j++)
                {
                    paths[i, j, 0] = (int.MaxValue, (-1, -1));
                    paths[i, j, 1] = (int.MaxValue, (-1, -1));
                    paths[i, j, 2] = (int.MaxValue, (-1, -1));

                    // Check left
                    if (j - 1 >= 0 && j - 1 < W)
                    {
                        // Without penalty
                        if (paths[i - 1, j - 1, 0].cost != int.MaxValue && paths[i - 1, j - 1, 0].cost + S[i, j] < paths[i, j, 0].cost)
                        {
                            paths[i, j, 0].cost = paths[i - 1, j - 1, 0].cost + S[i, j];
                            paths[i, j, 0].Item2.i = i - 2;
                            paths[i, j, 0].Item2.j = j - 2;
                        }
                        // With penalty
                        if (paths[i - 1, j - 1, 1].cost != int.MaxValue && paths[i - 1, j - 1, 1].cost + S[i, j] + K < paths[i, j, 0].cost)
                        {
                            paths[i, j, 0].cost = paths[i - 1, j - 1, 1].cost + S[i, j] + K;
                            paths[i, j, 0].Item2.i = i - 2;
                            paths[i, j, 0].Item2.j = j - 1;
                        }
                        // With penalty
                        if (paths[i - 1, j - 1, 2].cost != int.MaxValue && paths[i - 1, j - 1, 2].cost + S[i, j] + K < paths[i, j, 0].cost)
                        {
                            paths[i, j, 0].cost = paths[i - 1, j - 1, 2].cost + S[i, j] + K;
                            paths[i, j, 0].Item2.i = i - 2;
                            paths[i, j, 0].Item2.j = j;
                        }
                    }
                    // Check middle
                    if (j >= 0 && j < W)
                    {
                        // With penalty
                        if (paths[i - 1, j, 0].cost != int.MaxValue && paths[i - 1, j, 0].cost + S[i, j] + K < paths[i, j, 1].cost)
                        {
                            paths[i, j, 1].cost = paths[i - 1, j, 0].cost + S[i, j] + K;
                            paths[i, j, 1].Item2.i = i - 2;
                            paths[i, j, 1].Item2.j = j - 1;
                        }
                        // Without penalty
                        if (paths[i - 1, j, 1].cost != int.MaxValue && paths[i - 1, j, 1].cost + S[i, j] < paths[i, j, 1].cost)
                        {
                            paths[i, j, 1].cost = paths[i - 1, j, 1].cost + S[i, j];
                            paths[i, j, 1].Item2.i = i - 2;
                            paths[i, j, 1].Item2.j = j;
                        }
                        // With penalty
                        if (paths[i - 1, j, 2].cost != int.MaxValue && paths[i - 1, j, 2].cost + S[i, j] + K < paths[i, j, 1].cost)
                        {
                            paths[i, j, 1].cost = paths[i - 1, j, 2].cost + S[i, j] + K;
                            paths[i, j, 1].Item2.i = i - 2;
                            paths[i, j, 1].Item2.j = j + 1;
                        }
                    }
                    // Check right
                    if (j + 1 >= 0 && j + 1 < W)
                    {
                        // With penalty
                        if (paths[i - 1, j + 1, 0].cost != int.MaxValue && paths[i - 1, j + 1, 0].cost + S[i, j] + K < paths[i, j, 2].cost)
                        {
                            paths[i, j, 2].cost = paths[i - 1, j + 1, 0].cost + S[i, j] + K;
                            paths[i, j, 2].Item2.i = i - 2;
                            paths[i, j, 2].Item2.j = j;
                        }
                        // With penalty
                        if (paths[i - 1, j + 1, 1].cost != int.MaxValue && paths[i - 1, j + 1, 1].cost + S[i, j] + K < paths[i, j, 2].cost)
                        {
                            paths[i, j, 2].cost = paths[i - 1, j + 1, 1].cost + S[i, j] + K;
                            paths[i, j, 2].Item2.i = i - 2;
                            paths[i, j, 2].Item2.j = j + 1;
                        }
                        // Without penalty
                        if (paths[i - 1, j + 1, 2].cost != int.MaxValue && paths[i - 1, j + 1, 2].cost + S[i, j] < paths[i, j, 2].cost)
                        {
                            paths[i, j, 2].cost = paths[i - 1, j + 1, 2].cost + S[i, j];
                            paths[i, j, 2].Item2.i = i - 2;
                            paths[i, j, 2].Item2.j = j + 2;
                        }
                    }
                }
            }

            int indexi = H - 1;
            int indexj = 0;
            int indexd = 0; // direction index (0 - left, 1 - middle, 2 - right). Tells us we have to take in current step.

            // Find lowest cost and corresponding direction
            for (int j = 0; j < W; j++)
            {
                for (int direction = 0; direction < 3; direction++)
                {
                    if (paths[H - 1, j, direction].cost < paths[H - 1, indexj, indexd].cost)
                    {
                        indexj = j;
                        indexd = direction;
                    }
                }
            }

            (int i, int j)[] seam = new (int i, int j)[H];
            int totalCost = paths[H - 1, indexj, indexd].cost;

            seam[H - 1] = (indexi, indexj);
            seam[H - 2] = (indexi - 1, indexj - 1 + indexd);

            // recontructiong seam
            while (indexi > 1)
            {
                seam[indexi - 2] = paths[indexi, indexj, indexd].Item2;
                indexj = indexj + indexd - 1;
                indexd = seam[indexi - 2].j - indexj + 1;
                indexi--;
            }
            return (totalCost, seam);
        }
    }
}
