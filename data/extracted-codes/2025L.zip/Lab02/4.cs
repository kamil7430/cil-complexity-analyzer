﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASD
{
    public class Lab02 : MarshalByRefObject
    {
        /// <summary>
        /// Etap 1 - Wyznaczenie ścieżki (seam) o minimalnym sumarycznym score.
        /// Ścieżka przebiega od górnego do dolnego wiersza obrazu.
        /// </summary>
        /// <param name="S">macierz score o wymiarach H x W, gdzie S[i, j] reprezentuje "ważność" piksela w wierszu i i kolumnie j</param>
        /// <returns>
        /// (int cost, (int, int)[] seam) - 
        /// cost: minimalny łączny koszt ścieżki (suma wartości pikseli);
        /// seam: tablica pozycji pikseli (włącznie z pikselem z pierwszego i ostatniego wiersza) tworzących ścieżkę.
        /// </returns>
        public (int cost, (int i, int j)[] seam) Stage1(int[,] S)
        {
            int H = S.GetLength(0);
            int W = S.GetLength(1);

            int[,] dp = new int[H, W];
            (int x, int j)[,] coordinatesOfPrevious = new (int x, int j)[H, W];

            for (int j = 0; j < W; j++)
            {
                dp[0, j] = S[0, j];
                coordinatesOfPrevious[0, j] = (0, j);
            }

            for (int i = 1; i < H; i++)
            {
                for (int j = 0; j < W; j++)
                {
                    if (j == 0)
                    {
                        dp[i, j] = S[i, j] + Math.Min(dp[i - 1, j], dp[i - 1, j + 1]);
                        if (dp[i - 1, j] < dp[i - 1, j + 1]) coordinatesOfPrevious[i, j] = (i - 1, j);
                        else coordinatesOfPrevious[i, j] = (i - 1, j + 1);
                    }

                    else if (j == W - 1)
                    {
                        dp[i, j] = S[i, j] + Math.Min(dp[i - 1, j - 1], dp[i - 1, j]);
                        if (dp[i - 1, j - 1] < dp[i - 1, j]) coordinatesOfPrevious[i, j] = (i - 1, j - 1);
                        else coordinatesOfPrevious[i, j] = (i - 1, j);
                    }

                    else
                    {
                        dp[i, j] = S[i, j] + Math.Min(Math.Min(dp[i - 1, j - 1], dp[i - 1, j]), dp[i - 1, j + 1]);
                        if (dp[i - 1, j - 1] <= dp[i - 1, j] && dp[i - 1, j - 1] <= dp[i - 1, j + 1]) coordinatesOfPrevious[i, j] = (i - 1, j - 1);
                        else if (dp[i - 1, j] <= dp[i - 1, j - 1] && dp[i - 1, j] <= dp[i - 1, j + 1]) coordinatesOfPrevious[i, j] = (i - 1, j);
                        else coordinatesOfPrevious[i, j] = (i - 1, j + 1);                     
                    }
                }
            }

            int answer = int.MaxValue;
            int indexX =  H - 1;
            int indexY = 0;
            for (int j = 0; j < W; j++)
            {
                if (dp[H - 1, j] < answer)
                {
                    answer = dp[H - 1, j];
                    indexY = j;
                }
                
            }

            Stack<(int, int)> stack = new Stack<(int, int)> ();
            for (int i = 0; i < H; i++)
            {
                stack.Push((indexX, indexY));
                (indexX, indexY) = coordinatesOfPrevious[indexX, indexY];
            }

            (int i, int j)[] seam = new (int i, int j)[H];
            for (int i = 0; i < H; i++)
            {
                seam[i] = stack.Pop();
            }
            return (answer, seam);
        }
        
        /// <summary>
        /// Etap 2 - Wyznaczenie ścieżki (seam) o minimalnym sumarycznym score z uwzględnieniem kary za zmianę kierunku.
        /// Przy każdym przejściu, gdy kierunek ruchu różni się od poprzedniego, do łącznego kosztu dodawana jest kara K.
        /// Pierwszy krok (z pierwszego wiersza) nie podlega karze.
        /// </summary>
        /// <param name="S">macierz score o wymiarach H x W</param>
        /// <param name="K">kara za zmianę kierunku (K >= 1)</param>
        /// <returns>
        /// (int cost, (int, int)[] seam) - 
        /// cost: minimalny łączny koszt ścieżki (suma wartości pikseli oraz naliczonych kar);
        /// seam: tablica pozycji pikseli tworzących ścieżkę.
        /// </returns>
        public (int cost, (int i, int j)[] seam) Stage2(int[,] S, int K)
        {
            int H = S.GetLength(0);
            int W = S.GetLength(1);

            // Intuicja. Moja początkowa intuicja polegała na drobnej modyfikacji rozwiązania z etapu 1. Myślałem o tym, 
            // że można będzie stworzyć dodatkową tablicę int[,] PreviousDirection do przechowywania ostatniego kierunku
            // optymalnego ruchu. Np. jeśli optymalna ścieżka (tzn. z najmniejszą wartością sumy) do punktu [i,j] swoim 
            // ostatnim ruchem skręciła w prawo w dół, to PreviousDirection[i,j] = 1 (jeśli w dół = 0, jeśli w lewo w dół -
            // -1). Ta modyfikacja pozwoliła by na wzięcie pod uwagę kierunku ostatniego ruchu i na dodanie odpowiedniej 
            // kary do sumy w dp[i,j].
            // Natomiast niestety to rozwiązanie nie było poprawnym dla wszystkich przypadków. Problem tkwił w tym, że w 
            // momencie, kiedy 2 albo 3 różne ruchy dawały optymalne rozwiązanie w momencie [i,j], wybierało się losowo
            // jedno z tych dwóch/trzech możliwych kierunków. W niektórych przypadkach mogło ono doprowadzić do błędnej
            // odpowiedzi. Problem ten zauważyłem, kiedy moje rozwiązanie nie przeszło przez jeden z testów "wrednych".
            //    {1, 999, 999, 999, 1},
            //    { 999, 1, 999, 1, 999},
            //    { 999, 999, 1, 999, 999}, - taka macierz wejściowa S dawała sytuację, w której komórka dp[i,j] = 3, ale
            //    { 999, 1, 999, 1, 999},     rozwiązanie to nie było jednoznacznym (ścieżki (0,0)-(1,1)-(2,2) i 
            //    { 2, 999, 999, 999, 1}      (0,4)-(1,3)-(2,2) dawały ten sam wynik = 3 i mój algorytm losowo wybierał iść
            //                                dalej w lewo, co w wyniku prowadzało do błędnej odpowiedzi = 6. Gdyby wybrany 
            //                                został kierunek w prawo przy sytuacji "nieoczywistej", to odpowiedź byłaby 5.
            //
            // Dlatego postanowiłem stworzyć zamiast tablicy dwuwymiarowej tablicę trzywymiarową, gdzie trzeci wymiar
            // odpowiadał za przechowywanie wszystkich możliwych przejść (w lewo, w dół i w prawo). Dzięki temu miałem
            // możliwość obejść problem, o którym pisałem wyżej (bo różne ścieżki już nie scalały się w jedną, a szły 
            // niezależnie dalej).
            // Zmodyfikowałem też macierz coordinatesOfPrevious[,,] - teraz ona też była trzywymiarowa.



            int[,,] dp = new int[H, W, 3];
            (int i, int j, int d)[,,] coordinatesOfPrevious = new (int i, int j, int d)[H, W, 3];


            // Inicjalizacja zerowego wiersza
            for (int j = 0; j < W; j++)
            {
                for (int d = 0; d < 3; d++)
                {
                    dp[0, j, d] = S[0, j];
                    coordinatesOfPrevious[0, j, d] = (-1, -1, -1);
                }
            }

            // Inicjalizacja pierwszego wiersza (bez żadnych kar, bo jeszcze nie mogą pojawić się w tym momencie)
            for (int j = 0; j < W; j++)
            {
                if (j == 0)
                {
                    dp[1, j, 0] = S[1, j] + dp[0, j + 1, 0];
                    dp[1, j, 1] = S[1, j] + dp[0, j, 1];
                    dp[1, j, 2] = int.MaxValue;
                    coordinatesOfPrevious[1, j, 0] = (0, j + 1, 0);
                    coordinatesOfPrevious[1, j, 1] = (0, j, 1);
                    coordinatesOfPrevious[1, j, 2] = (-1, -1, -1);
                }

                else if (j == W - 1)
                {
                    dp[1, j, 0] = int.MaxValue;
                    dp[1, j, 1] = S[1, j] + dp[0, j, 1];
                    dp[1, j, 2] = S[1, j] + dp[0, j - 1, 2];
                    coordinatesOfPrevious[1, j, 0] = (-1, -1, -1);
                    coordinatesOfPrevious[1, j, 1] = (0, j, 1);
                    coordinatesOfPrevious[1, j, 2] = (0, j - 1, 2);
                }

                else
                {
                    dp[1, j, 0] = S[1, j] + dp[0, j + 1, 0];
                    dp[1, j, 1] = S[1, j] + dp[0, j, 1];
                    dp[1, j, 2] = S[1, j] + dp[0, j - 1, 2];
                    coordinatesOfPrevious[1, j, 0] = (0, j + 1, 0);
                    coordinatesOfPrevious[1, j, 1] = (0, j, 1);
                    coordinatesOfPrevious[1, j, 2] = (0, j - 1, 2);
                }     
            }


            // Obsługa pozostałych wierszy
            for (int i = 2; i < H; i++)
            {
                for (int j = 0; j < W; j++)
                {
                    // Początkowa inicjalizacja wszystkich stanów bieżącego wierszu (jako int.MaxValue)
                    for (int d = 0; d < 3; d++)
                    {
                        dp[i, j, d] = int.MaxValue;
                        coordinatesOfPrevious[i, j, d] = (-1, -1, -1);
                    }

                    // PossibleX = numer kolumny, skąd idzie bieżący krok
                    int PossibleLeft = j + 1;
                    int PossibleDown = j;
                    int PossibleRight = j - 1;

                    // Ogólnie w tej części kodu (if{} else if{} else{}) różnią się tylko wartości k, po którym iterują 
                    // się pętle wewnętrzne. Zrobione jest to, żeby osobno rozważyć 2 przypadki skrajne i nie wyjść poza
                    // wymiary tablicy.
                    if (j == 0)
                    {
                        for (int k = PossibleDown; k <= PossibleLeft; k++)
                        {                           
                            for (int d = 0; d < 3; d++)
                            {
                                if (dp[i - 1, k, d] == int.MaxValue) continue;
                                int Candidate = dp[i - 1, k, d] + S[i, j] + K;

                                // j - k + 1 - numer indeksu trzeciego wymiaru, odpowiadający kierunku ruchu
                                if (d == j - k + 1) Candidate -= K;

                                if (Candidate < dp[i, j, j - k + 1])
                                {
                                    dp[i, j, j - k + 1] = Candidate;
                                    coordinatesOfPrevious[i, j, j - k + 1] = (i - 1, k, d);
                                }
                            }
                        }
                    }

                    else if (j == W - 1)
                    {
                        for (int k = PossibleRight; k <= PossibleDown; k++)
                        {

                            for (int d = 0; d < 3; d++)
                            {
                                if (dp[i - 1, k, d] == int.MaxValue) continue;
                                int Candidate = dp[i - 1, k, d] + S[i, j] + K;

                                if (d == j - k + 1) Candidate -= K;

                                if (Candidate < dp[i, j, j - k + 1])
                                {
                                    dp[i, j, j - k + 1] = Candidate;
                                    coordinatesOfPrevious[i, j, j - k + 1] = (i - 1, k, d);
                                }

                            }

                        }

                    }

                    else
                    {
                        for (int k = PossibleRight; k <= PossibleLeft; k++)
                        {
                            for (int d = 0; d < 3; d++)
                            {
                                if (dp[i - 1, k, d] == int.MaxValue) continue;
                                int Candidate = dp[i - 1, k, d] + S[i, j] + K;

                                if (d == j - k + 1) Candidate -= K;

                                if (Candidate < dp[i, j, j - k + 1])
                                {
                                    dp[i, j, j - k + 1] = Candidate;
                                    coordinatesOfPrevious[i, j, j - k + 1] = (i - 1, k, d);
                                }

                            }
                        }
                    }
                }
            }

            int answer = int.MaxValue;
            int indexX = H - 1;
            int indexY = 0;
            int indexZ = 0;
            // Odbieranie indeksów ostatniego elementu na ścieżce i otrzymujemy answer -
            // najmniejsza liczba z ostatnich wierszy (we wszystkich wymiarach)
            for (int j = 0; j < W; j++)
            {
                for (int d = 0; d < 3; d++)
                {
                    if (dp[indexX, j, d] < answer)
                    {
                        answer = dp[indexX, j, d];
                        indexY = j;
                        indexZ = d;
                    }
                }
            }

            // Korzystasię ze stosu, żeby mieć LIFO (jest wygodniejsze, bo ścieżkę odbieram od końca)
            Stack<(int, int)> stack = new Stack<(int, int)>();
            for (int i = 0; i < H; i++)
            {
                stack.Push((indexX, indexY));
                (indexX, indexY, indexZ) = coordinatesOfPrevious[indexX, indexY, indexZ];
            }

            (int i, int j)[] seam = new (int i, int j)[H];
            for (int i = 0; i < H; i++)
            {
                seam[i] = stack.Pop();
            }
            return (answer, seam);
        }       
    }
}
