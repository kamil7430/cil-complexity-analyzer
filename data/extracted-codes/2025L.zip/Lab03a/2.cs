﻿
namespace ASD
{
    using ASD.Graphs;
    using System.Collections.Generic;

    public class Lab03 : System.MarshalByRefObject
    {
        // Część I
        // Funkcja zwracajaca kwadrat danego grafu.
        // Kwadratem grafu nazywamy graf o takim samym zbiorze wierzchołków jak graf pierwotny, w którym wierzchołki
        // połączone sa krawędzią jeśli w grafie pierwotnym były polączone krawędzia bądź ścieżką złożoną z 2 krawędzi
        // (ale pętli, czyli krawędzi o początku i końcu w tym samym wierzchołku, nie dodajemy!).
        public Graph Square(Graph graph)
        {
            Graph square = new Graph(graph.VertexCount, graph.Representation);
            for (int i = 0; i < graph.VertexCount; i++)
            {
                foreach (int neighbor in graph.OutNeighbors(i))
                {
                    square.AddEdge(i, neighbor);
                    foreach (int secondNeighbor in graph.OutNeighbors(neighbor))
                    {
                        if (secondNeighbor != i)
                        {
                            square.AddEdge(i, secondNeighbor);
                        }
                    }
                }
            }
            return square;
        }

        // Część II
        // Funkcja zwracająca Graf krawędziowy danego grafu.
        // Wierzchołki grafu krawędziwego odpowiadają krawędziom grafu pierwotnego, wierzcholki grafu krawędziwego
        // połączone sa krawędzią jeśli w grafie pierwotnym z krawędzi odpowiadającej pierwszemu z nich można przejść
        // na krawędź odpowiadającą drugiemu z nich przez wspólny wierzchołek.

        // Tablicę names tworzymy i wypełniamy według następującej zasady.
        // Każdemu wierzchołkowi grafu krawędziowego odpowiada element tablicy names (o indeksie równym numerowi wierzchołka)
        // zawierający informację z jakiej krawędzi grafu pierwotnego wierzchołek ten powstał.
        // Np.dla wierzchołka powstałego z krawedzi <0,1> do tablicy zapisujemy krotke (0, 1) - przyda się w dalszych etapach
        public Graph LineGraph(Graph graph, out (int x, int y)[] names)
        {
            Graph lineGraph = new Graph(graph.EdgeCount, graph.Representation);
            names = new (int x, int y)[graph.EdgeCount];
            int index = 0;

            foreach (Edge edge in graph.DFS().SearchAll())
            {
                if (names.Contains((edge.From, edge.To)) || names.Contains((edge.To, edge.From)))
                {
                    continue;
                }

                names[index] = (edge.From, edge.To);

                foreach (int neighbor in graph.OutNeighbors(edge.To))
                {
                    if (neighbor == edge.From)
                    {
                        continue;
                    }

                    if (names.Contains((edge.To, neighbor)))
                    {
                        lineGraph.AddEdge(index, Array.IndexOf(names, (edge.To, neighbor)));
                    }

                    if (names.Contains((neighbor, edge.To)))
                    {
                        lineGraph.AddEdge(index, Array.IndexOf(names, (neighbor, edge.To)));
                    }
                }

                foreach (int neighbor in graph.OutNeighbors(edge.From))
                {
                    if (neighbor == edge.To)
                    {
                        continue;
                    }
                    if (names.Contains((edge.From, neighbor)))
                    {
                        lineGraph.AddEdge(index, Array.IndexOf(names, (edge.From, neighbor)));
                    }
                    if (names.Contains((neighbor, edge.From)))
                    {
                        lineGraph.AddEdge(index, Array.IndexOf(names, (neighbor, edge.From)));
                    }
                }
                index++;
            }
            return lineGraph;

            //int n = graph.VertexCount, Ln = graph.EdgeCount;
            //Graph LG = new(Ln, graph.Representation);
            //names = new (int x, int y)[Ln];
            //int j = 0;
            //for (int i = 0; i < n; i++)
            //    foreach (var neigh in graph.OutNeighbors(i).Where(x => x > i))
            //    {
            //        names[j] = (i, neigh);
            //        j++;
            //    }
            //for (int i = 0; i < Ln; i++)
            //{
            //    var v = names[i];
            //    for (int k = i + 1; k < Ln; k++)
            //    {
            //        var t = names[k];
            //        if (v.x == t.x || v.x == t.y || v.y == t.x || v.y == t.y)
            //            LG.AddEdge(i, k);
            //    }
            //}
            //return LG;
        }

        // Część III
        // Funkcja znajdujaca poprawne kolorowanie wierzchołków danego grafu nieskierowanego.
        // Kolorowanie wierzchołków jest poprawne, gdy każde dwa sąsiadujące wierzchołki mają różne kolory
        // Funkcja ma szukać kolorowania według następujacego algorytmu zachłannego:

        // Dla wszystkich wierzchołków v (od 0 do n-1)
        // pokoloruj wierzcholek v kolorem o najmniejszym możliwym numerze(czyli takim, na który nie są pomalowani jego sąsiedzi)
        // Kolory numerujemy począwszy od 0.

        // UWAGA: Podany opis wyznacza kolorowanie jednoznacznie, jakiekolwiek inne kolorowanie, nawet jeśli spełnia formalnie
        // definicję kolorowania poprawnego, na potrzeby tego zadania będzie uznane za błędne.

        // Funkcja zwraca liczbę użytych kolorów (czyli najwyższy numer użytego koloru + 1),
        // a w tablicy colors zapamiętuje kolory poszczególnych wierzchołkow.
        public int VertexColoring(Graph graph, out int[] colors)
        {
            colors = new int[graph.VertexCount];
            for (int i = 0; i < graph.VertexCount; i++)
            {
                colors[i] = -1;
            }

            int maxColor = -1;

            for (int i = 0; i < graph.VertexCount; i++)
            {
                for (int j = 0; j <= maxColor + 1; j++)
                {
                    bool isColorUsed = false;
                    foreach (int neighbor in graph.OutNeighbors(i))
                    {
                        if (colors[neighbor] == j)
                        {
                            isColorUsed = true;
                            break;
                        }
                    }
                    if (!isColorUsed)
                    {
                        colors[i] = j;
                        if (j > maxColor)
                        {
                            maxColor = j;
                        }
                        break;
                    }
                }
            }

            return maxColor + 1;
        }

        // Funkcja znajduje silne kolorowanie krawędzi danego grafu.
        // Silne kolorowanie krawędzi grafu jest poprawne gdy każde dwie krawędzie, które są ze sobą sąsiednie
        // (czyli można przejść z jednej na drugą przez wspólny wierzchołek)
        // albo są połączone inną krawędzią(czyli można przejść z jednej na drugą przez ową inną krawędź), mają różne kolory.

        // Należy zwrocić nowy graf, który będzie miał strukturę identyczną jak zadany graf,
        // ale w wagach krawędzi zostaną zapisane przydzielone kolory.

        // Wskazówka - to bardzo proste.Należy wykorzystać wszystkie poprzednie funkcje.
        // Zastanowić się co możemy powiedzieć o kolorowaniu wierzchołków kwadratu grafu krawędziowego?
        // Jak się to ma do silnego kolorowania krawędzi grafu pierwotnego?
        public int StrongEdgeColoring(Graph graph, out Graph<int> coloredGraph)
        {
            Graph lineGraph = LineGraph(graph, out (int x, int y)[] names);
            Graph squareGraph = Square(lineGraph);
            int minColors = VertexColoring(squareGraph, out int[] colors);

            coloredGraph = new Graph<int>(graph.VertexCount, graph.Representation);

            foreach ((int x, int y) name in names)
            {
                if (graph.HasEdge(name.x, name.y))
                {
                    coloredGraph.AddEdge(name.x, name.y, colors[Array.IndexOf(names, name)]);
                }

                if (graph.HasEdge(name.y, name.x))
                {
                    coloredGraph.AddEdge(name.y, name.x, colors[Array.IndexOf(names, name)]);
                }
            }

            return minColors;
        }

    }

}
