﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ASD
{
    [Serializable]
    public struct Point
    {
        public double x;
        public double y;

        public Point(double x, double y)
        {
            this.x = x;
            this.y = y;
        }

        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public static bool operator ==(Point p1, Point p2) { return p1.x == p2.x && p1.y == p2.y; }

        public static bool operator !=(Point p1, Point p2) { return !(p1 == p2); }

        public override string ToString()
        {
            return string.Format("({0},{1})", x, y);
        }
        public static double Distance(Point p1, Point p2)
        {
            double dx, dy;
            dx = p1.x - p2.x;
            dy = p1.y - p2.y;
            return Math.Sqrt(dx * dx + dy * dy);
        }

    }

    public class Lab12 : MarshalByRefObject
    {

        private class ByY : IComparer<Point>
        {
            public int Compare(Point p1, Point p2)
            {
                int res = p1.y.CompareTo(p2.y);
                return res == 0 ? p1.x.CompareTo(p2.x) : res;
            }
        }


        /// <summary>
        /// Metoda zwraca dwa najbliższe punkty w dwuwymiarowej przestrzeni Euklidesowej
        /// </summary>
        /// <param name="points">Chmura punktów</param>
        /// <param name="minDistance">Odległość pomiędzy najbliższymi punktami</param>
        /// <returns>Para najbliższych punktów. Kolejność nie ma znaczenia</returns>
        /// <remarks>
        /// 1) Algorytm powinien mieć złożoność O(n^2), gdzie n to liczba punktów w chmurze
        /// </remarks>
        public Tuple<Point, Point> FindClosestPointsBrute(List<Point> points, out double minDistance)
        {
            //minDistance = double.MaxValue;
            //var best = (points[0], points[0]);
            //for (int i = 0; i < points.Count; i++)
            //{
            //    for (int j = 0; j < points.Count; j++)
            //    {
            //        if (i == j) continue;
            //        var d = Point.Distance(points[i], points[j]);
            //        if (d < minDistance)
            //        {
            //            minDistance = d;
            //            best = (points[i], points[j]);
            //        }
            //    }
            //}

            //return best.ToTuple();
            return FindClosestPoints(points, out minDistance);
        }

        /// <summary>
        /// Metoda zwraca dwa najbliższe punkty w dwuwymiarowej przestrzeni Euklidesowej
        /// </summary>
        /// <param name="points">Chmura punktów</param>
        /// <param name="minDistance">Odległość pomiędzy najbliższymi punktami</param>
        /// <returns>Para najbliższych punktów. Kolejność nie ma znaczenia</returns>
        /// <remarks>
        /// 1) Algorytm powinien mieć złożoność n*logn, gdzie n to liczba punktów w chmurze
        /// </remarks>
        public Tuple<Point, Point> FindClosestPoints(List<Point> points, out double d)
        {
            var n = points.Count;
            d = double.MaxValue / 2;
            var best = (points[0], points[1]);

            var D = new SortedSet<Point>(new ByY());
            var events = points.OrderBy(p => p.x).ToList();
            var past = new Queue<Point>();
            for (int i = 0; i < n; i++)
            {
                var x = events[i].x;
                var y = events[i].y;

                while (past.Count > 0 && past.First().x < x - d)
                {
                    var p = past.Dequeue();
                    D.Remove(p);
                }

                foreach (var p in D.GetViewBetween(new Point(x - d, y - d), new Point(x - d, y + d)))
                {
                    var dist = Point.Distance(p, events[i]);
                    if (dist < d)
                    {
                        d = dist;
                        best = (p, events[i]);
                    }
                }

                D.Add(events[i]);
                past.Enqueue(events[i]);
            }

            return best.ToTuple();
        }
    }
}
