﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ASD
{
    [Serializable]
    public struct Point
    {
        public double x;
        public double y;

        public Point(double x, double y)
        {
            this.x = x;
            this.y = y;
        }

        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public static bool operator ==(Point p1, Point p2) { return p1.x == p2.x && p1.y == p2.y; }

        public static bool operator !=(Point p1, Point p2) { return !(p1 == p2); }

        public override string ToString()
        {
            return string.Format("({0},{1})", x, y);
        }
        public static double Distance(Point p1, Point p2)
        {
            double dx, dy;
            dx = p1.x - p2.x;
            dy = p1.y - p2.y;
            return Math.Sqrt(dx * dx + dy * dy);
        }

    }

    public class Lab12 : MarshalByRefObject
    {

        private class ByY : IComparer<Point>
        {
            public int Compare(Point p1, Point p2)
            {
                int res = p1.y.CompareTo(p2.y);
                return res == 0 ? p1.x.CompareTo(p2.x) : res;
            }
        }


        /// <summary>
        /// Metoda zwraca dwa najbliższe punkty w dwuwymiarowej przestrzeni Euklidesowej
        /// </summary>
        /// <param name="points">Chmura punktów</param>
        /// <param name="minDistance">Odległość pomiędzy najbliższymi punktami</param>
        /// <returns>Para najbliższych punktów. Kolejność nie ma znaczenia</returns>
        /// <remarks>
        /// 1) Algorytm powinien mieć złożoność O(n^2), gdzie n to liczba punktów w chmurze
        /// </remarks>
        public Tuple<Point, Point> FindClosestPointsBrute(List<Point> points, out double minDistance)
        {
            minDistance = double.MaxValue;
            Point ans1 = points[0], ans2 = points[1];

            foreach (var point1 in points)
            {
                foreach (var point2 in points)
                {
                    if (point1 == point2) continue;
                    if (Point.Distance(point1, point2) < minDistance)
                    {
                        minDistance = Point.Distance(point1, point2);
                        ans1 = point1;
                        ans2 = point2;
                    }
                }
            }

            return Tuple.Create(ans1, ans2);
        }

        /// <summary>
        /// Metoda zwraca dwa najbliższe punkty w dwuwymiarowej przestrzeni Euklidesowej
        /// </summary>
        /// <param name="points">Chmura punktów</param>
        /// <param name="minDistance">Odległość pomiędzy najbliższymi punktami</param>
        /// <returns>Para najbliższych punktów. Kolejność nie ma znaczenia</returns>
        /// <remarks>
        /// 1) Algorytm powinien mieć złożoność n*logn, gdzie n to liczba punktów w chmurze
        /// </remarks>
        public Tuple<Point, Point> FindClosestPoints(List<Point> points, out double minDistance)
        {
            // Ogólnie cały algorytm został prawie w pełni podany w treści zadania :)
            // Chciałbym dodać tylko 2 krótkie wyjaśnienia:
            // 1 - Użyłem SortedSet do przechowywania wierzchołków, znajdujących się w konkretnym momencie algorytmu
            // w tzw. zbiorze D. Zbiór D zawiera w sobie wszystkie takie wierzchołki, które mają niezerową szansę na 
            // znaliezienie się w odległości od bieżącego wierzchołka x mniejszej niż dotychczas znaleziony najmniejszy
            // dystans. SortedSet ma strukturę drzewa CC i posortowany jest względem współrzędnej y (dzięki ByY : IComparer).
            // Dzięki temu można znacznie szybciej znaleźć wierzchołki w D, które leżą w pewnym przedziale względem y.
            // To podejście znacznie przyspiesza cały algorytm - jego złożoność staje się O(nlogn).
            // 2 - Na początku każdego kroku pętli głownej po wszystkich wierzchołkach mam krótką pętlę 'while', która 
            // ma za zadanie modyfikować zbiór D, biorąc pod uwagę bieżący wierzchołek oraz najlepszą na ten moment 
            // znalezioną odległość. Logika jest w miarę prosta. Na początku (przed pierwszym krokiem) D jest puste. 
            // Załóżmy, że jesteśmy w k-tym kroku. A więc po lewej stronie od k-tego wierzchołka znajduje się k-1 już
            // obejrzanych wierzhołków. Pętla while służy do usunięcia ze zbioru D tych wierzchołków, które na pewno znajdują się
            // od k-tego wierzchołka w odległości większej, niż dotychczas znaleziona najlepsza. Patrzymy na odległość względem x:
            // jeżeli ona jest większa, to odległość w dwóch wymiarach na pewno nie będzie mniejsza (to jest oczywiste). No i 
            // przeglądamy wierzchołki tylko po lewej od k-tego. Jeszcze dodałem dodatkową zmienną "indeksową". Ona służy do
            // zapamiętania, który wierzchołek został usunięty z D jako ostatni (czyli najbardziej po prawej usunięty). 
            // Zapamiętuję tą infomację, bo jeśli jakiś wierzchołek jest zbyt za daleko względem x od konkretnego k-tego wierzchołka
            // (k-tego co do wielkości wartości współrzędnej x), to oczywisćie, że będzie zbyt za daleko i dla kolejnych (k+1-szego,
            // k+2-go itd.) A więc nie ma sensu za każdym razem przeglądać tylko wszystkie wierzchołki od 0 do k-1 - wystarczy zatem
            // przejść po wszystkich od leftDIdx do k-1.

            List<Point> pointsSortedByX = points.OrderBy(p => p.x).ToList();

            Point best1 = pointsSortedByX[0];
            Point best2 = pointsSortedByX[1];

            minDistance = Point.Distance(best1 , best2);

            SortedSet<Point> currentD = new SortedSet<Point>(new ByY());
            int leftDIdx = 0;

            foreach (Point point in pointsSortedByX)
            {
                while (leftDIdx < pointsSortedByX.Count && point.x - pointsSortedByX[leftDIdx].x > minDistance)
                {
                    currentD.Remove(pointsSortedByX[leftDIdx]);
                    leftDIdx++;
                }

                foreach (Point pointInsideD in currentD.GetViewBetween(new Point(0, point.y - minDistance), new Point(0, point.y + minDistance)))
                {
                    if (Point.Distance(point, pointInsideD) < minDistance)
                    {
                        minDistance = Point.Distance(point, pointInsideD);
                        best1 = point;
                        best2 = pointInsideD;
                    }
                }

                currentD.Add(point);
            }

            return Tuple.Create(best1, best2);
        }
    }
}
