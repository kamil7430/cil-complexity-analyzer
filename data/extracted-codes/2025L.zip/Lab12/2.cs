﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ASD
{
    [Serializable]
    public struct Point
    {
        public double x;
        public double y;

        public Point(double x, double y)
        {
            this.x = x;
            this.y = y;
        }

        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public static bool operator ==(Point p1, Point p2) { return p1.x == p2.x && p1.y == p2.y; }

        public static bool operator !=(Point p1, Point p2) { return !(p1 == p2); }

        public override string ToString()
        {
            return string.Format("({0},{1})", x, y);
        }
        public static double Distance(Point p1, Point p2)
        {
            double dx, dy;
            dx = p1.x - p2.x;
            dy = p1.y - p2.y;
            return Math.Sqrt(dx * dx + dy * dy);
        }

    }

    public class Lab12 : MarshalByRefObject
    {
        private class ByY : IComparer<Point>
        {
            public int Compare(Point p1, Point p2)
            {
                int res = p1.y.CompareTo(p2.y);
                return res == 0 ? p1.x.CompareTo(p2.x) : res;
            }
        }

        private class ByX : IComparer<Point>
        {
            public int Compare(Point p1, Point p2)
            {
                int res = p1.x.CompareTo(p2.x);
                return res == 0 ? p1.y.CompareTo(p2.y) : res;
            }
        }


        /// <summary>
        /// Metoda zwraca dwa najbliższe punkty w dwuwymiarowej przestrzeni Euklidesowej
        /// </summary>
        /// <param name="points">Chmura punktów</param>
        /// <param name="minDistance">Odległość pomiędzy najbliższymi punktami</param>
        /// <returns>Para najbliższych punktów. Kolejność nie ma znaczenia</returns>
        /// <remarks>
        /// 1) Algorytm powinien mieć złożoność O(n^2), gdzie n to liczba punktów w chmurze
        /// </remarks>
        public Tuple<Point, Point> FindClosestPointsBrute(List<Point> points, out double minDistance)
        {
            int firstIndex = -1;
            int secondIndex = -1;
            minDistance = double.MaxValue;

            for (int i = 0; i < points.Count; i++)
            {
                for (int j = 0; j < points.Count; j++)
                {
                    if (i == j) continue;
                    double distance = Point.Distance(points[i], points[j]);
                    if (distance < minDistance)
                    {
                        minDistance = distance;
                        firstIndex = i;
                        secondIndex = j;
                    }
                }
            }
            return new Tuple<Point, Point>(points[firstIndex], points[secondIndex]);
        }

        /// <summary>
        /// Metoda zwraca dwa najbliższe punkty w dwuwymiarowej przestrzeni Euklidesowej
        /// </summary>
        /// <param name="points">Chmura punktów</param>
        /// <param name="minDistance">Odległość pomiędzy najbliższymi punktami</param>
        /// <returns>Para najbliższych punktów. Kolejność nie ma znaczenia</returns>
        /// <remarks>
        /// 1) Algorytm powinien mieć złożoność n*logn, gdzie n to liczba punktów w chmurze
        /// </remarks>
        public Tuple<Point, Point> FindClosestPoints(List<Point> points, out double minDistance)
        {
            Point leftClosestPoint;
            Point rightClosestPoint;
            double shortestDistance;

            SortedSet<Point> leftPoints = new SortedSet<Point>(new ByY());
            List<Point> sortedPoints = new List<Point>(points.Count);

            foreach (var point in points)
            {
                sortedPoints.Add(point);
            }
            sortedPoints.Sort(new ByX());

            leftClosestPoint = sortedPoints[0];
            rightClosestPoint = sortedPoints[1];
            shortestDistance = Point.Distance(leftClosestPoint, rightClosestPoint);

            int leftestValidPointIndex = 0;

            leftPoints.Add(sortedPoints[0]);
            leftPoints.Add(sortedPoints[1]);
            for (int index = 2; index < sortedPoints.Count; index++)
            {
                Point currentPoint = sortedPoints[index];

                while (currentPoint.x - sortedPoints[leftestValidPointIndex].x >= shortestDistance)
                {
                    leftPoints.Remove(sortedPoints[leftestValidPointIndex]);
                    leftestValidPointIndex++;
                }

                SortedSet<Point> rectangleSet = leftPoints.GetViewBetween(
                    new Point(currentPoint.x, currentPoint.y - shortestDistance), 
                    new Point(currentPoint.x, currentPoint.y + shortestDistance));

                foreach (var point in rectangleSet)
                {
                    if (Point.Distance(currentPoint, point) < shortestDistance)
                    {
                        shortestDistance = Point.Distance(currentPoint, point);
                        leftClosestPoint = point;
                        rightClosestPoint = currentPoint;
                    }
                }

                leftPoints.Add(currentPoint);
            }

            minDistance = shortestDistance;
            return new Tuple<Point, Point>(leftClosestPoint, rightClosestPoint);
        }
    }
}
