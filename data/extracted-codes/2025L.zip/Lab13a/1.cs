﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ASD
{
    public class LZ77 : MarshalByRefObject
    {
        private static int[] ComputeP(string s)
        {
            var n = s.Length;
            var P = new int[n + 1];

            var t = 0;
            for (var i = 2; i <= n; i++)
            {
                while (t > 0 && s[t] != s[i - 1])
                    t = P[t];
                if (s[t] == s[i - 1])
                    t++;
                P[i] = t;
            }

            return P;
        }
        /// <summary>
        /// Odkodowywanie napisu zakodowanego algorytmem LZ77. Dane kodowanie jest poprawne (nie trzeba tego sprawdzać).
        /// </summary>
        public string Decode(List<EncodingTriple> encoding)
        {
            var res = new StringBuilder(encoding.Count + encoding.Sum(t => t.c));
            foreach (var e in encoding)
            {
                // aaabca, p = 2
                //    ^
                var l = res.Length;
                var start = l - 1 - e.p;
                var end = start - 1 + e.c;
                if (start >= 0)
                    for (var i = start; i <= end; i++)
                        res.Append(res[i]);

                res.Append(e.s);
            }
            
            return res.ToString();
        }

        /// <summary>
        /// Kodowanie napisu s algorytmem LZ77
        /// </summary>
        /// <returns></returns>
        public List<EncodingTriple> Encode(string s, int pMax)
        {
            if (s.Length == 0) return [];
            // aabaaab|aabab
            //     ^^^ ^
            //         ^^^^ 
            //     
            var result = new List<EncodingTriple>{new(0, 0, s[0])};

            var i = 1;
            while (i < s.Length)
            {
                var wStart = Math.Max(i - pMax, 0);
                var best = 0;
                var bestWStart = wStart;
                for (var st = wStart; st < i; st++)
                {
                    var P = ComputeP(s[st..]);
                    var m = P.Max();
                    if (m > best)
                    {
                        best = m;
                        bestWStart = st;
                    }
                }

                i += best;
                if (i == s.Length)
                {
                    result.Add(new(0, 0, s[i - 1]));
                    break;
                }
                result.Add(new(i - bestWStart, best, s[i]));
                i++;
            }
            
            return result;
        }
    }

    [Serializable]
    public struct EncodingTriple
    {
        public int p, c;
        public char s;

        public EncodingTriple(int p, int c, char s)
        {
            this.p = p;
            this.c = c;
            this.s = s;
        }
    }
}
