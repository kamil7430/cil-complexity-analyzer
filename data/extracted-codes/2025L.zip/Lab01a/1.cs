﻿namespace ASD
{
    class CrossoutChecker
    {
        /// <summary>
        /// Sprawdza, czy podana lista wzorców zawiera wzorzec x
        /// </summary>
        /// <param name="patterns">Lista wzorców</param>
        /// <param name="x">Jedyny znak szukanego wzorca</param>
        /// <returns></returns>
        bool comparePattern(char[][] patterns, char x)
        {
            foreach (char[] pat in patterns)
            {
                if (pat.Length == 1 && pat[0] == x)
                    return true;
            }

            return false;
        }

        /// <summary>
        /// Sprawdza, czy podana lista wzorców zawiera wzorzec xy
        /// </summary>
        /// <param name="patterns">Lista wzorców</param>
        /// <param name="x">Pierwszy znak szukanego wzorca</param>
        /// <param name="y">Drugi znak szukanego wzorca</param>
        /// <returns></returns>
        bool comparePattern(char[][] patterns, char x, char y)
        {
            foreach (char[] pat in patterns)
            {
                if (pat.GetLength(0) == 2 && pat[0] == x && pat[1] == y)
                    return true;
            }

            return false;
        }

        private void Fill<T>(T[,] table, T elem)
        {
            for (int i = 0; i < table.GetLength(0); i++)
            {
                for (int j = 0; j < table.GetLength(1); j++)
                {
                    table[i, j] = elem;
                }
            }
        }

        /// <summary>
        /// Metoda sprawdza, czy podany ciąg znaków można sprowadzić do ciągu pustego przez skreślanie zadanych wzorców.
        /// Zakładamy, że każdy wzorzec składa się z jednego lub dwóch znaków!
        /// </summary>
        /// <param name="sequence">Ciąg znaków</param>
        /// <param name="patterns">Lista wzorców</param>
        /// <param name="crossoutsNumber">Minimalna liczba skreśleń gwarantująca sukces lub int.MaxValue, jeżeli się nie da</param>
        /// <returns></returns>
        public bool Erasable(char[] sequence, char[][] patterns, out int crossoutsNumber)
        {
            const int inf = int.MaxValue - 1;
            crossoutsNumber = inf;
            int n = sequence.Length;
            // T[i, j] = najmniejsza liczba wytarć dla patterns[i..=j]
            int[,] T = new int[n, n];
            Fill(T, -1);

            int ErasableR(int start, int end, int[,] dp)
            {
                if (start < 0 || end < 0 || start >= n || end >= n)
                    return 0;
                if (dp[start, end] != -1) return dp[start, end];

                switch (end - start)
                {
                    // pusty jest wycieralny
                    case < 0:
                    {
                        dp[start, end] = 0;
                        return dp[start, end];
                    }
                    // wzorzec jest wycieralny
                    case 0:
                    {
                        dp[start, end] = comparePattern(patterns, sequence[start]) ? 1 : inf;
                        return dp[start, end];
                    }
                    // wzorzec jest wycieralny
                    case 1:
                    {
                        if (comparePattern(patterns, sequence[start], sequence[end]))
                            dp[start, end] = 1;
                        else if (comparePattern(patterns, sequence[start]) && comparePattern(patterns, sequence[end]))
                            dp[start, end] = 2;
                        else
                            dp[start, end] = inf;
                        return dp[start, end];
                    }
                }

                int best = inf;
                // konkatenacja dwóch wycieralnych
                for (int i = start; i < end; i++)
                {
                    int first = ErasableR(start, i, dp);
                    int second = ErasableR(i + 1, end, dp);
                    if (first == inf || second == inf)
                        continue;
                    int c = first + second;
                    best = int.Min(best, c);
                }

                // zawiera (spójny) wycieralny i to co zostaje jest wzorcem
                if (comparePattern(patterns, sequence[start]))
                {
                    int c = 1 + ErasableR(start + 1, end, dp);
                    best = int.Min(best, c);
                }

                if (comparePattern(patterns, sequence[end]))
                {
                    int c = 1 + ErasableR(start, end - 1, dp);
                    best = int.Min(best, c);
                }

                if (comparePattern(patterns, sequence[start], sequence[end]))
                {
                    int c = 1 + ErasableR(start + 1, end - 1, dp);
                    best = int.Min(best, c);
                }

                if (comparePattern(patterns, sequence[start], sequence[start + 1]))
                {
                    int c = 1 + ErasableR(start + 2, end, dp);
                    best = int.Min(best, c);
                }

                if (comparePattern(patterns, sequence[end - 1], sequence[end]))
                {
                    int c = 1 + ErasableR(start, end - 2, dp);
                    best = int.Min(best, c);
                }

                dp[start, end] = best;
                return dp[start, end];
            }

            ErasableR(0, n - 1, T);
            crossoutsNumber = T[0, n - 1];

            if (crossoutsNumber != inf) return true;
            crossoutsNumber = int.MaxValue;
            return false;
        }

        /// <summary>
        /// Metoda sprawdza, jaka jest minimalna długość ciągu, który można uzyskać z podanego poprzez skreślanie zadanych wzorców.
        /// Zakładamy, że każdy wzorzec składa się z jednego lub dwóch znaków!
        /// </summary>
        /// <param name="sequence">Ciąg znaków</param>
        /// <param name="patterns">Lista wzorców</param>
        /// <returns></returns>
        public int MinimumRemainder(char[] sequence, char[][] patterns)
        {
            int n = sequence.Length;
            // T[i, j] = długość najkrótszego ciągu jaki można uzyskać z sequence[i..=j]
            int[,] T = new int[n, n];

            for (int i = 0; i < n; i++)
            {
                T[i, i] = comparePattern(patterns, sequence[i]) ? 0 : 1;
            }

            for (int len = 2; len <= n; len++)
            {
                for (int i = 0; i <= n - len; i++)
                {
                    int j = i + len - 1;
                    T[i, j] = len; // w najgorszym wypadku

                    // konkatenacja dwóch
                    for (int k = i; k < j; k++)
                    {
                        T[i, j] = int.Min(T[i, j], T[i, k] + T[k + 1, j]);
                    }

                    // usuwamy wzorzec z brzegu
                    if (comparePattern(patterns, sequence[i]))
                    {
                        T[i, j] = int.Min(T[i, j], T[i + 1, j]);
                    }

                    if (comparePattern(patterns, sequence[j]))
                    {
                        T[i, j] = int.Min(T[i, j], T[i, j - 1]);
                    }

                    if (comparePattern(patterns, sequence[i], sequence[j]))
                    {
                        T[i, j] = int.Min(T[i, j], T[i + 1, j - 1]);
                    }

                    if (i + 2 <= j && comparePattern(patterns, sequence[i], sequence[i + 1]))
                    {
                        T[i, j] = int.Min(T[i, j], T[i + 2, j]);
                    }

                    if (j - 2 >= i && comparePattern(patterns, sequence[j - 1], sequence[j]))
                    {
                        T[i, j] = int.Min(T[i, j], T[i, j - 2]);
                    }
                }
            }

            return T[0, n - 1];
        }
    }
}