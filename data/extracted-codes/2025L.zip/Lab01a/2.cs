﻿using System;

namespace ASD
{
    class CrossoutChecker
    {
        /// <summary>
        /// Sprawdza, czy podana lista wzorców zawiera wzorzec x
        /// </summary>
        /// <param name="patterns">Lista wzorców</param>
        /// <param name="x">Jedyny znak szukanego wzorca</param>
        /// <returns></returns>
        bool comparePattern(char[][] patterns, char x)
        {
            foreach (char[] pat in patterns)
            {
                if (pat.Length == 1 && pat[0] == x)
                    return true;
            }
            return false;
        }

        /// <summary>
        /// Sprawdza, czy podana lista wzorców zawiera wzorzec xy
        /// </summary>
        /// <param name="patterns">Lista wzorców</param>
        /// <param name="x">Pierwszy znak szukanego wzorca</param>
        /// <param name="y">Drugi znak szukanego wzorca</param>
        /// <returns></returns>
        bool comparePattern(char[][] patterns, char x, char y)
        {
            foreach (char[] pat in patterns)
            {
                if (pat.GetLength(0) == 2 && pat[0] == x && pat[1] == y)
                    return true;
            }
            return false;
        }

        /// <summary>
        /// Metoda sprawdza, czy podany ciąg znaków można sprowadzić do ciągu pustego przez skreślanie zadanych wzorców.
        /// Zakładamy, że każdy wzorzec składa się z jednego lub dwóch znaków!
        /// </summary>
        /// <param name="sequence">Ciąg znaków</param>
        /// <param name="patterns">Lista wzorców</param>
        /// <param name="crossoutsNumber">Minimalna liczba skreśleń gwarantująca sukces lub int.MaxValue, jeżeli się nie da</param>
        /// <returns></returns>
        public bool Erasable(char[] sequence, char[][] patterns, out int crossoutsNumber)
        {
            int n = sequence.Length;
            int[,] dp = new int[n, n];

            // Przetwarzanie wszystkich długości podciągów od 1 do n
            for (int len = 1; len <= n; len++)
            {
                for (int L = 0; L <= n - len; L++)
                {
                    int R = L + len - 1; // R to ostatni indeks w przedziale
                    dp[L, R] = int.MaxValue;

                    // Sprawdzenie, czy cały podciąg można usunąć w jednej operacji
                    if (len == 1)
                    {
                        if (comparePattern(patterns, sequence[L]))
                            dp[L, R] = 1;
                    }
                    else if (comparePattern(patterns, sequence[L], sequence[R]) && (len == 2 || dp[L + 1, R - 1] != int.MaxValue))
                    {
                        dp[L, R] = 1 + (len == 2 ? 0 : dp[L + 1, R - 1]);
                    }

                    // Sprawdzenie wszystkich możliwych podziałów przedziału [L, R]
                    for (int i = L; i < R; i++)
                    {
                        if (dp[L, i] != int.MaxValue && dp[i + 1, R] != int.MaxValue)
                        {
                            int c = dp[L, i] + dp[i + 1, R];
                            if (c < dp[L, R])
                                dp[L, R] = c;
                        }
                    }

                }
            }

            crossoutsNumber = dp[0, n - 1];
            return crossoutsNumber != int.MaxValue;
        }

        /// <summary>
        /// Metoda sprawdza, jaka jest minimalna długość ciągu, który można uzyskać z podanego poprzez skreślanie zadanych wzorców.
        /// Zakładamy, że każdy wzorzec składa się z jednego lub dwóch znaków!
        /// </summary>
        /// <param name="sequence">Ciąg znaków</param>
        /// <param name="patterns">Lista wzorców</param>
        /// <returns></returns>
        public int MinimumRemainder(char[] sequence, char[][] patterns)
        {
            int n = sequence.Length;
            int[,] minLen = new int[n, n];

            // Przetwarzanie wszystkich długości podciągów od 1 do n
            for (int len = 1; len <= n; len++)
            {
                for (int L = 0; L <= n - len; L++)
                {
                    int R = L + len - 1; // R to ostatni indeks w przedziale
                    minLen[L, R] = len;

                    // Sprawdzenie, czy cały podciąg można usunąć w jednej operacji
                    if (len == 1)
                    {
                        if (comparePattern(patterns, sequence[L]))
                        {
                            minLen[L, R] = 0;
                        }

                    }
                    else if (comparePattern(patterns, sequence[L], sequence[R]) && (len == 2 || minLen[L + 1, R - 1] == 0))
                    {
                        minLen[L, R] = 0;
                    }

                    // Sprawdzenie wszystkich możliwych podziałów przedziału [L, R]
                    for (int i = L; i < R; i++)
                    {
                        int c = minLen[L, i] + minLen[i + 1, R];
                        if (c < minLen[L, R])
                            minLen[L, R] = c;
                    }

                }
            }

            return minLen[0, n - 1];
        }

        // można dopisać metody pomocnicze

    }
}
