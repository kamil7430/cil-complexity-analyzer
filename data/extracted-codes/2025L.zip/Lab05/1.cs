using ASD.Graphs;
using System;
using System.Linq;
using System.Text;

namespace ASD
{
    public class Maze : MarshalByRefObject
    {
        /// <summary>
        /// Wersje zadania I oraz II
        /// Zwraca najkrótszy możliwy czas przejścia przez labirynt bez dynamitów lub z dowolną ich liczbą
        /// </summary>
        /// <param name="maze">labirynt</param>
        /// <param name="withDynamite">informacja, czy dostępne są dynamity 
        /// Wersja I zadania -> withDynamites = false, Wersja II zadania -> withDynamites = true</param>
        /// <param name="path">zwracana ścieżka</param>
        /// <param name="t">czas zburzenia ściany (dotyczy tylko wersji II)</param> 
        public int FindShortestPath(char[,] maze, bool withDynamite, out string path, int t = 0)
        {
            int width = maze.GetLength(1);
            int height = maze.GetLength(0);
            bool IsInBounds(int x, int y) => x >= 0 && x < width && y >= 0 && y < height;
            bool CanGo(int x, int y) => IsInBounds(x, y) && maze[y, x] != 'X';
            int GetIndex(int x, int y) => y * width + x;
            (int x, int y) GetCoords(int v) => (v % width, v / width);

            var G = new DiGraph<int>(maze.Length);
            (int x, int y) s = (0, 0), e = (0, 0);

            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    if (maze[y, x] == 'S') s = (x, y);
                    if (maze[y, x] == 'E') e = (x, y);

                    int v = GetIndex(x, y);
                    {
                        (int ux, int uy) = (x - 1, y);
                        if (IsInBounds(ux, uy))
                        {
                            if (CanGo(ux, uy))
                                G.AddEdge(v, GetIndex(ux, uy), 1);
                            else if (withDynamite)
                                G.AddEdge(v, GetIndex(ux, uy), t);
                        }
                    }
                    {
                        (int ux, int uy) = (x + 1, y);
                        if (IsInBounds(ux, uy))
                        {
                            if (CanGo(ux, uy))
                                G.AddEdge(v, GetIndex(ux, uy), 1);
                            else if (withDynamite)
                                G.AddEdge(v, GetIndex(ux, uy), t);
                        }
                    }
                    {
                        (int ux, int uy) = (x, y - 1);
                        if (IsInBounds(ux, uy))
                        {
                            if (CanGo(ux, uy))
                                G.AddEdge(v, GetIndex(ux, uy), 1);
                            else if (withDynamite)
                                G.AddEdge(v, GetIndex(ux, uy), t);
                        }
                    }
                    {
                        (int ux, int uy) = (x, y + 1);
                        if (IsInBounds(ux, uy))
                        {
                            if (CanGo(ux, uy))
                                G.AddEdge(v, GetIndex(ux, uy), 1);
                            else if (withDynamite)
                                G.AddEdge(v, GetIndex(ux, uy), t);
                        }
                    }
                }
            }

            var st = GetIndex(s.x, s.y);
            var en = GetIndex(e.x, e.y);
            var pi = Paths.Dijkstra(G, st);
            if (!pi.Reachable(st, en))
            {
                path = "";
                return -1;
            }

            var dist = pi.GetDistance(st, en);

            var pb = new StringBuilder();
            var prev = s;
            foreach (int v in pi.GetPath(st, en))
            {
                (int x, int y) vc = GetCoords(v);
                if (vc == s) continue;

                if (vc.x > prev.x)
                    pb.Append('E');
                else if (vc.x < prev.x)
                    pb.Append('W');
                else if (vc.y > prev.y)
                    pb.Append('S');
                else if (vc.y < prev.y)
                    pb.Append('N');

                prev = vc;
            }

            path = pb.ToString();
            return dist;
        }

        /// <summary>
        /// Wersja III i IV zadania
        /// Zwraca najkrótszy możliwy czas przejścia przez labirynt z użyciem co najwyżej k lasek dynamitu
        /// </summary>
        /// <param name="maze">labirynt</param>
        /// <param name="k">liczba dostępnych lasek dynamitu, dla wersji III k=1</param>
        /// <param name="path">zwracana ścieżka</param>
        /// <param name="t">czas zburzenia ściany</param>
        public int FindShortestPathWithKDynamites(char[,] maze, int k, out string path, int t)
        {
            int width = maze.GetLength(1);
            int height = maze.GetLength(0);
            bool IsInBounds(int x, int y, int z) => x >= 0 && x < width && y >= 0 && y < height && z >= 0 && z < k + 1;
            bool CanGo(int x, int y, int z) => IsInBounds(x, y, z) && maze[y, x] != 'X';
            int GetIndex(int x, int y, int z) => y * width + x + z * (width * height);

            (int x, int y, int z) GetCoords(int v)
            {
                int z = v / (width * height);
                int vNew = v - z * (width * height);
                return (vNew % width, vNew / width, z);
            }

            var G = new DiGraph<int>(maze.Length * (k + 1));
            (int x, int y) s = (0, 0), e = (0, 0);

            for (int z = 0; z < k + 1; z++)
            {
                for (int y = 0; y < height; y++)
                {
                    for (int x = 0; x < width; x++)
                    {
                        if (maze[y, x] == 'S') s = (x, y);
                        if (maze[y, x] == 'E') e = (x, y);

                        int v = GetIndex(x, y, z);
                        {
                            (int ux, int uy) = (x - 1, y);
                            if (IsInBounds(ux, uy, z))
                            {
                                if (CanGo(ux, uy, z))
                                    G.AddEdge(v, GetIndex(ux, uy, z), 1);
                                else if (z < k)
                                    G.AddEdge(v, GetIndex(ux, uy, z + 1), t);
                            }
                        }
                        {
                            (int ux, int uy) = (x + 1, y);
                            if (IsInBounds(ux, uy, z))
                            {
                                if (CanGo(ux, uy, z))
                                    G.AddEdge(v, GetIndex(ux, uy, z), 1);
                                else if (z < k)
                                    G.AddEdge(v, GetIndex(ux, uy, z + 1), t);
                            }
                        }
                        {
                            (int ux, int uy) = (x, y - 1);
                            if (IsInBounds(ux, uy, z))
                            {
                                if (CanGo(ux, uy, z))
                                    G.AddEdge(v, GetIndex(ux, uy, z), 1);
                                else if (z < k)
                                    G.AddEdge(v, GetIndex(ux, uy, z + 1), t);
                            }
                        }
                        {
                            (int ux, int uy) = (x, y + 1);
                            if (IsInBounds(ux, uy, z))
                            {
                                if (CanGo(ux, uy, z))
                                    G.AddEdge(v, GetIndex(ux, uy, z), 1);
                                else if (z < k)
                                    G.AddEdge(v, GetIndex(ux, uy, z + 1), t);
                            }
                        }
                    }
                }
            }

            var st = GetIndex(s.x, s.y, 0);
            var pi = Paths.Dijkstra(G, st);
            var bestEn = -1;
            for (int kk = 0; kk < k + 1; kk++)
            {
                var en = GetIndex(e.x, e.y, kk);
                if (pi.Reachable(st, en) && bestEn == -1)
                    bestEn = en;
                else if (pi.Reachable(st, en) && pi.GetDistance(st, en) < pi.GetDistance(st, bestEn))
                    bestEn = en;
            }

            if (bestEn == -1)
            {
                path = "";
                return -1;
            }

            var dist = pi.GetDistance(st, bestEn);

            var pb = new StringBuilder();
            var prev = s;
            foreach (int v in pi.GetPath(st, bestEn))
            {
                (int x, int y, int z) vc = GetCoords(v);
                if (vc.x == s.x && vc.y == s.y) continue;

                if (vc.x > prev.x)
                    pb.Append('E');
                else if (vc.x < prev.x)
                    pb.Append('W');
                else if (vc.y > prev.y)
                    pb.Append('S');
                else if (vc.y < prev.y)
                    pb.Append('N');

                prev.x = vc.x;
                prev.y = vc.y;
            }

            path = pb.ToString();
            return dist;
        }
    }
}