﻿using ASD.Graphs;
using System;
using System.Linq;
using System.Text;

namespace ASD
{
    public class Maze : MarshalByRefObject
    {

        /// <summary>
        /// Wersje zadania I oraz II
        /// Zwraca najkrótszy możliwy czas przejścia przez labirynt bez dynamitów lub z dowolną ich liczbą
        /// </summary>
        /// <param name="maze">labirynt</param>
        /// <param name="withDynamite">informacja, czy dostępne są dynamity 
        /// Wersja I zadania -> withDynamites = false, Wersja II zadania -> withDynamites = true</param>
        /// <param name="path">zwracana ścieżka</param>
        /// <param name="t">czas zburzenia ściany (dotyczy tylko wersji II)</param> 
        public int FindShortestPath(char[,] maze, bool withDynamite, out string path, int t = 0)
        {
            path = "";
            int start = -1;
            int end = -1;
            int height = maze.GetLength(0);
            int width = maze.GetLength(1);

            DiGraph<int> graph = new DiGraph<int>(maze.GetLength(0) * maze.GetLength(1));

            // create graph
            for (int i = 0; i < height; i++)
            {
                for (int j = 0; j < width; j++)
                {
                    if (maze[i, j] == 'S')
                    {
                        start = i * width + j;
                    }
                    else if (maze[i, j] == 'E')
                    {
                        end = i * width + j;
                    }

                    // left neighbour
                    if (IsValid(i, j - 1, height, width))
                    {
                        if (maze[i, j - 1] != 'X')
                        {
                            graph.AddEdge(i * width + j, i * width + j - 1, 1);
                        }
                        else if (withDynamite)
                        {
                            graph.AddEdge(i * width + j, i * width + j - 1, t);
                        }
                    }
                    // right neighbour
                    if (IsValid(i, j + 1, height, width))
                    {
                        if (maze[i, j + 1] != 'X')
                        {
                            graph.AddEdge(i * width + j, i * width + j + 1, 1);
                        }
                        else if (withDynamite)
                        {
                            graph.AddEdge(i * width + j, i * width + j + 1, t);
                        }
                    }
                    // top neighbour
                    if (IsValid(i - 1, j, height, width))
                    {
                        if (maze[i - 1, j] != 'X')
                        {
                            graph.AddEdge(i * width + j, (i - 1) * width + j, 1);
                        }
                        else if (withDynamite)
                        {
                            graph.AddEdge(i * width + j, (i - 1) * width + j, t);
                        }
                    }
                    // bottom neighbour
                    if (IsValid(i + 1, j, height, width))
                    {
                        if (maze[i + 1, j] != 'X')
                        {
                            graph.AddEdge(i * width + j, (i + 1) * width + j, 1);
                        }
                        else if (withDynamite)
                        {
                            graph.AddEdge(i * width + j, (i + 1) * width + j, t);
                        }
                    }
                }
            }

            // find shortest path
            PathsInfo<int> paths = Paths.Dijkstra(graph, start);

            int distance = -1;

            if (paths.Reachable(start, end) == true)
            {
                distance = paths.GetDistance(start, end);
                path = IntArrToString(paths.GetPath(start, end));
            }

            return distance;
        }

        bool IsValid(int i, int j, int height, int width)
        {
            return i >= 0 && i < height && j >= 0 && j < width;
        }

        string IntArrToString(int[] arr)
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < arr.Length - 1; i++)
            {
                int current = arr[i];
                int next = arr[i + 1];
                char direction = ' ';

                if (next == current - 1)
                {
                    direction = 'W';
                }
                else if (next == current + 1)
                {
                    direction = 'E';
                }
                else if (next < current)
                {
                    direction = 'N';
                }
                else if (next > current)
                {
                    direction = 'S';
                }

                sb.Append(direction);
            }
            return sb.ToString();
        }

        /// <summary>
        /// Wersja III i IV zadania
        /// Zwraca najkrótszy możliwy czas przejścia przez labirynt z użyciem co najwyżej k lasek dynamitu
        /// </summary>
        /// <param name="maze">labirynt</param>
        /// <param name="k">liczba dostępnych lasek dynamitu, dla wersji III k=1</param>
        /// <param name="path">zwracana ścieżka</param>
        /// <param name="t">czas zburzenia ściany</param>
        public int FindShortestPathWithKDynamites(char[,] maze, int k, out string path, int t)
        {
            path = "";
            int start = -1;
            int end = -1;
            int height = maze.GetLength(0);
            int width = maze.GetLength(1);
            int depth = k + 1;

            DiGraph<int> graph = new DiGraph<int>(maze.GetLength(0) * maze.GetLength(1) * depth);

            // create graph
            for (int i = 0; i < height; i++)
            {
                for (int j = 0; j < width; j++)
                {
                    if (maze[i, j] == 'S')
                    {
                        start = i * width + j;
                    }
                    else if (maze[i, j] == 'E')
                    {
                        end = i * width + j;
                    }

                    // left neighbour
                    if (IsValid(i, j - 1, height, width))
                    {
                        if (maze[i, j - 1] != 'X')
                        {
                            for (int l = 0; l < depth; l++)
                            {
                                graph.AddEdge(i * width + j + width * height * l, i * width + j - 1 + width * height * l, 1);
                            }
                        }
                        else if (maze[i, j - 1] == 'X')
                        {
                            for (int l = 0; l < depth - 1; l++)
                            {
                                graph.AddEdge(i * width + j + width * height * l, i * width + j - 1 + width * height * (l + 1), t);
                            }
                        }
                    }
                    // right neighbour
                    if (IsValid(i, j + 1, height, width))
                    {
                        if (maze[i, j + 1] != 'X')
                        {
                            for (int l = 0; l < depth; l++)
                            {
                                graph.AddEdge(i * width + j + width * height * l, i * width + j + 1 + width * height * l, 1);
                            }
                        }
                        else if (maze[i, j + 1] == 'X')
                        {
                            for (int l = 0; l < depth - 1; l++)
                            {
                                graph.AddEdge(i * width + j + width * height * l, i * width + j + 1 + width * height * (l + 1), t);
                            }
                        }
                    }
                    // top neighbour
                    if (IsValid(i - 1, j, height, width))
                    {
                        if (maze[i - 1, j] != 'X')
                        {
                            for (int l = 0; l < depth; l++)
                            {
                                graph.AddEdge(i * width + j + width * height * l, (i - 1) * width + j + width * height * l, 1);
                            }
                        }
                        else if (maze[i - 1, j] == 'X')
                        {
                            for (int l = 0; l < depth - 1; l++)
                            {
                                graph.AddEdge(i * width + j + width * height * l, (i - 1) * width + j + width * height * (l + 1), t);
                            }
                        }
                    }
                    // bottom neighbour
                    if (IsValid(i + 1, j, height, width))
                    {
                        if (maze[i + 1, j] != 'X')
                        {
                            for (int l = 0; l < depth; l++)
                            {
                                graph.AddEdge(i * width + j + width * height * l, (i + 1) * width + j + width * height * l, 1);
                            }
                        }
                        else if (maze[i + 1, j] == 'X')
                        {
                            for (int l = 0; l < depth - 1; l++)
                            {
                                graph.AddEdge(i * width + j + width * height * l, (i + 1) * width + j + width * height * (l + 1), t);
                            }
                        }
                    }
                }
            }

            // find shortest path
            PathsInfo<int> paths = Dijkstra<int>(graph, start);
            //PathsInfo<int> paths = Paths.FloydWarshall(graph, start);

            int shortestPathIndex = -1;
            int shortestPathLength = int.MaxValue;

            for (int i = 0; i < depth; i++)
            {
                if (paths.Reachable(start, end + width * height * i) == true)
                {
                    int distance = paths.GetDistance(start, end + width * height * i);
                    if (distance < shortestPathLength)
                    {
                        shortestPathLength = distance;
                        shortestPathIndex = i;
                    }
                }
            }

            if (shortestPathIndex != -1)
            {
                path = IntArrToString2(paths.GetPath(start, end + width * height * shortestPathIndex), width, height);
            }
            if (shortestPathLength == int.MaxValue)
            {
                shortestPathLength = -1;
            }

            return shortestPathLength;
        }

        string IntArrToString2(int[] arr, int width, int height)
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < arr.Length - 1; i++)
            {
                int current = arr[i] % (width * height);
                int next = arr[i + 1] % (width * height);
                char direction = ' ';

                if (next == (current - 1))
                {
                    direction = 'W';
                }
                else if (next == (current + 1))
                {
                    direction = 'E';
                }
                else if (next < current)
                {
                    direction = 'N';
                }
                else if (next > current)
                {
                    direction = 'S';
                }

                sb.Append(direction);
            }
            return sb.ToString();
        }

        public static PathsInfo<int> Dijkstra_for_int(IGraph<int> G, int source)
        {
            PathsInfo<int> pathsInfo = new PathsInfo<int>(G.VertexCount);
            SafePriorityQueue<int, int> safePriorityQueue = new SafePriorityQueue<int, int>(G.VertexCount);
            for (int i = 0; i < G.VertexCount; i++)
            {
                safePriorityQueue.Insert(i);
            }

            //_ = new int[G.VertexCount];
            //_ = new int[G.VertexCount];
            safePriorityQueue.UpdatePriority(source, 0);
            while (safePriorityQueue.Count > 0 && pathsInfo.Reachable(source, safePriorityQueue.Peek()))
            {
                int v = safePriorityQueue.Extract();
                foreach (Edge<int> item in G.OutEdges(v))
                {
                    if (item.Weight < 0)
                    {
                        throw new ArgumentException("Algorytm Dijkstry napotkał krawędź o ujemnej wadze!");
                    }

                    int num = item.Weight + pathsInfo.GetDistance(source, item.From);
                    if (!pathsInfo.Reachable(source, item.To) || num < pathsInfo.GetDistance(source, item.To))
                    {
                        safePriorityQueue.UpdatePriority(item.To, num);
                        pathsInfo.AddPathFragment(source, item.From, item.To, num);
                    }
                }
            }

            return pathsInfo;
        }

        public static PathsInfo<T> BellmanFord<T>(IGraph<T> G, int source) where T : IComparable<T>, new()
        {
            PathsInfo<T> pathsInfo = new PathsInfo<T>(G.VertexCount);
            bool flag = true;
            for (int i = 0; i < G.VertexCount && flag; i++)
            {
                flag = false;
                for (int j = 0; j < G.VertexCount; j++)
                {
                    if (!pathsInfo.Reachable(source, j))
                    {
                        continue;
                    }

                    foreach (Edge<T> item in G.OutEdges(j))
                    {
                        T distance = (dynamic)item.Weight + (dynamic)pathsInfo.GetDistance(source, item.From);
                        if (!pathsInfo.Reachable(source, item.To) || distance.CompareTo(pathsInfo.GetDistance(source, item.To)) == -1)
                        {
                            flag = true;
                            pathsInfo.AddPathFragment(source, item.From, item.To, distance);
                        }
                    }
                }
            }

            if (flag)
            {
                throw new ArgumentException("Algorytm Forda-Bellmana napotkał ujemny cykl!");
            }

            return pathsInfo;
        }

        public static PathsInfo<T> FloydWarshall<T>(IGraph<T> G) where T : IComparable<T>, new()
        {
            PathsInfo<T> pathsInfo = new PathsInfo<T>(G.VertexCount);
            for (int i = 0; i < G.VertexCount; i++)
            {
                foreach (Edge<T> item in G.OutEdges(i))
                {
                    pathsInfo.AddPathFragment(i, i, item.To, item.Weight);
                }
            }

            for (int j = 0; j < G.VertexCount; j++)
            {
                for (int k = 0; k < G.VertexCount; k++)
                {
                    for (int l = 0; l < G.VertexCount; l++)
                    {
                        if (pathsInfo.Reachable(k, j) && pathsInfo.Reachable(j, l) && k != j && l != j && (!pathsInfo.Reachable(k, l) || pathsInfo.GetDistance(k, l).CompareTo((T)((dynamic)pathsInfo.GetDistance(k, j) + (dynamic)pathsInfo.GetDistance(j, l))) > 0))
                        {
                            pathsInfo.AddPathFragment(k, pathsInfo.GetPrevious(j, l), l, (dynamic)pathsInfo.GetDistance(k, j) + (dynamic)pathsInfo.GetDistance(j, l));
                        }
                    }
                }
            }

            return pathsInfo;
        }

        public static PathsInfo<T> Johnson<T>(IGraph<T> G) where T : IComparable<T>, new()
        {
            PathsInfo<T> pathsInfo = new PathsInfo<T>(G.VertexCount);
            DiGraph<T> diGraph = new DiGraph<T>(G.VertexCount + 1, G.Representation);
            for (int i = 0; i < G.VertexCount; i++)
            {
                diGraph.AddEdge(G.VertexCount, i, new T());
                foreach (Edge<T> item in G.OutEdges(i))
                {
                    diGraph.AddEdge(item.From, item.To, item.Weight);
                }
            }

            PathsInfo<T> pathsInfo2 = BellmanFord<T>(diGraph, G.VertexCount);
            for (int j = 0; j < G.VertexCount; j++)
            {
                foreach (Edge<T> item2 in G.OutEdges(j))
                {
                    diGraph.SetEdgeWeight(item2.From, item2.To, (dynamic)item2.Weight + (dynamic)pathsInfo2.GetDistance(G.VertexCount, item2.From) - (dynamic)pathsInfo2.GetDistance(G.VertexCount, item2.To));
                }
            }

            for (int k = 0; k < G.VertexCount; k++)
            {
                PathsInfo<T> pathsInfo3 = Dijkstra(diGraph, k);
                for (int l = 0; l < G.VertexCount; l++)
                {
                    if (l != k && pathsInfo3.Reachable(k, l))
                    {
                        pathsInfo.AddPathFragment(k, pathsInfo3.GetPrevious(k, l), l, pathsInfo3.GetDistance(k, l));
                    }
                }
            }

            return pathsInfo;
        }

        public static PathsInfo<T> Dijkstra<T>(IGraph<T> G, int source) where T : IComparable<T>, new()
        {
            //if (typeof(T) == typeof(int))
            //{
            //    return Dijkstra_for_int((IGraph<int>)G, source) as PathsInfo<T>;
            //}

            PathsInfo<T> pathsInfo = new PathsInfo<T>(G.VertexCount);
            SafePriorityQueue<T, int> safePriorityQueue = new SafePriorityQueue<T, int>(G.VertexCount);
            for (int i = 0; i < G.VertexCount; i++)
            {
                safePriorityQueue.Insert(i);
            }

            _ = new T[G.VertexCount];
            _ = new int[G.VertexCount];
            safePriorityQueue.UpdatePriority(source, new T());
            while (safePriorityQueue.Count > 0 && pathsInfo.Reachable(source, safePriorityQueue.Peek()))
            {
                int v = safePriorityQueue.Extract();
                foreach (Edge<T> item in G.OutEdges(v))
                {
                    T weight = item.Weight;
                    if (weight.CompareTo(new T()) < 0)
                    {
                        throw new ArgumentException("Algorytm Dijkstry napotkał krawędź o ujemnej wadze!");
                    }

                    T val = (dynamic)item.Weight + (dynamic)pathsInfo.GetDistance(source, item.From);
                    if (!pathsInfo.Reachable(source, item.To) || val.CompareTo(pathsInfo.GetDistance(source, item.To)) == -1)
                    {
                        safePriorityQueue.UpdatePriority(item.To, val);
                        pathsInfo.AddPathFragment(source, item.From, item.To, val);
                    }
                }
            }

            return pathsInfo;
        }
    }
}