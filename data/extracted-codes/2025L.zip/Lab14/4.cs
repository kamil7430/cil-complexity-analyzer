﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ASD
{
    /// <summary>
    /// Klasa drzewa prefiksowego z możliwością wyszukiwania słów w zadanej odległości edycyjnej
    /// </summary>
    public class Lab14_Trie : System.MarshalByRefObject
    {
        
        // klasy TrieNode NIE WOLNO ZMIENIAĆ!
        private class TrieNode
        {
            public SortedDictionary<char, TrieNode> childs = new SortedDictionary<char, TrieNode>();
            public bool IsWord = false;
            public int WordCount = 0;
        }

        private TrieNode root;

        public Lab14_Trie()
        {
            root = new TrieNode();
        }

        /// <summary>
        /// Zwraca liczbę przechowywanych słów
        /// Ma działać w czasie stałym - O(1)
        /// </summary>
        public int Count { get { return root.WordCount; } }

        /// <summary>
        /// Zwraca liczbę przechowywanych słów o zadanym prefiksie
        /// Ma działać w czasie O(len(startWith))
        /// </summary>
        /// <param name="startWith">Prefiks słów do zliczenia</param>
        /// <returns>Liczba słów o zadanym prefiksie</returns>
        public int CountPrefix(string startWith)
        {
            TrieNode trieNode = root;
            foreach (char c in startWith)
            {
                if (trieNode.childs.ContainsKey(c))
                {
                    trieNode = trieNode.childs[c];
                }

                else return 0;
            }

            return trieNode.WordCount;
        }

        /// <summary>
        /// Dodaje słowo do słownika
        /// Ma działać w czasie O(len(newWord))
        /// </summary>
        /// <param name="newWord">Słowo do dodania</param>
        /// <returns>True jeśli słowo udało się dodać, false jeśli słowo już istniało</returns>
        public bool AddWord(string newWord)
        {
            TrieNode node = root;
            List<TrieNode> path = new List<TrieNode>();
            path.Add(node);

            foreach (char c in newWord)
            {
                if (node.childs.ContainsKey(c))
                {
                    node = node.childs[c];
                }
                else
                {
                    TrieNode newNode = new TrieNode();
                    node.childs[c] = newNode;
                    node = newNode;
                }

                path.Add(node);
            }

            if (node.IsWord)
                return false;

            node.IsWord = true;
            foreach (TrieNode n in path)
                n.WordCount++;

            return true;
        }

        /// <summary>
        /// Sprawdza czy podane słowo jest przechowywane w słowniku
        /// Ma działać w czasie O(len(word))
        /// </summary>
        /// <param name="word">Słowo do sprawdzenia</param>
        /// <returns>True jeśli słowo znajduje się w słowniku, wpp. false</returns>
        public bool Contains(string word)
        {
            TrieNode node = root;
            foreach (char c in word)
            {
                if (node.childs.ContainsKey(c))
                {
                    node = node.childs[c];
                    continue;
                }

                else return false;
            }
            return node.IsWord;
        }

        /// <summary>
        /// Usuwa podane słowo ze słownika
        /// Ma działać w czasie O(len(word))
        /// </summary>
        /// <param name="word">Słowo do usunięcia</param>
        /// <returns>True jeśli udało się słowo usunąć, false jeśli słowa nie było w słowniku</returns>
        public bool Remove(string word)
        {
            TrieNode node = root;
            List<TrieNode> path = new List<TrieNode>();
            path.Add(node);

            foreach (char c in word)
            {
                if (node.childs.ContainsKey(c))
                {
                    node = node.childs[c];
                    path.Add(node);
                }
                else return false;
            }

            if (!node.IsWord) return false;

            node.IsWord = false;

            foreach (TrieNode pathNode in path)
            {
                pathNode.WordCount--;
            }

            return true;
        }

        /// <summary>
        /// Zwraca wszystkie słowa o podanym prefiksie. 
        /// Dla pustego prefiksu zwraca wszystkie słowa ze słownika.
        /// Wynik jest w porządku alfabetycznym.
        /// Ma działać w czasie O(liczba węzłów w drzewie)
        /// </summary>
        /// <param name="startWith">Prefiks</param>
        /// <returns>Wyliczenie zawierające wszystkie słowa ze słownika o podanym prefiksie</returns>
        public List<string> AllWords(string startWith = "")
        {
            List<string> words = new List<string>();
            TrieNode node = root;

            foreach (char c in startWith)
            {
                if (node.childs.ContainsKey(c))
                {
                    node = node.childs[c];
                }

                else return words;
            }

            void DFS(TrieNode rootNode, string currentWord)
            {
                if (rootNode.IsWord) 
                    words.Add(currentWord);

                foreach (char c in rootNode.childs.Keys)
                {
                    TrieNode childNode = rootNode.childs[c];
                    DFS(childNode, currentWord + c);
                }
            }

            DFS(node, startWith);

            return words;
        }

        /// <summary>
        /// Wyszukuje w słowniku wszystkie słowa w podanej odległości edycyjnej od zadanego słowa
        /// Wynik jest w porządku alfabetycznym ze względu na słowa (a nie na odległość).
        /// Ma działać optymalnie - tj. niedozwolone jest wyszukanie wszystkich słów i sprawdzenie ich odległości
        /// Należy przeszukując drzewo odpowiednio odrzucać niektóre z gałęzi.
        /// Złożoność pesymistyczna (gdy wszystkie słowa w słowniku mieszczą się w zadanej odległości)
        /// O(len(word) * (liczba węzłów w drzewie))
        /// </summary>
        /// <param name="word">Słowo</param>
        /// <param name="distance">Odległość edycyjna</param>
        /// <returns>Lista zawierająca pary (słowo, odległość) spełniające warunek odległości edycyjnej</returns>
        public List<(string, int)> Search(string word, int distance = 1)
        {
            // Do rozwiązania tego etapu skorzystałem z pomysłu, który był podany w treści zadania (odległość edycyjna Levenshteina).
            // Tylko zamiast przechowywać osobną wersję tablicy dist[,] w algorytmie Levenshteina przechowywałem tylko ostatni jej wiersz,
            // bo jedynie tego potrzebuję, żeby wyznaczyć wartości bieżącego wiersza, a zatem wyznaczyć odległość Levenshteina dla bieżącego
            // prefiksu. 
            // Przykład:   ''  w  o  r  d         Załóżmy, że podane jest słowo - "word" i działamy aktualnie na prefiksie "win".
            //         ''   0  1  2  3  4         Krok przed tym, jak wejść do węzła 'n' wyznaczyliśmy sobie cały wiersz macierzy
            //          w   1  0  1  2  3         Levenshteina odpowiadający literze 'i' (2 1 1 2 3). Teraz chcemy wyznaczyć kolejny
            //          i   2  1  1  2  3         wiersz odpowiadający literze 'n', żeby zdobyć odległość edycyjną pomiędzy bieżącym 
            //          n   3  -  -  -  -         prefiksem "win" a "word". No i skoro dist[i,j] zależy tylko od dist[i-1,j-1],
            //                                    dist[i-1, j], dist[i, j-1] oraz słowa wejściowego wraz z bieżącym prefiksem, to
            //                                    zupełnie nas nie obchodzi już co znajduje się np. w wierszu odpowiadającym 'w'.
            //                                    I tak nie korzystamy już z tych danych. A więc wystarczy przechowywać i wrzucać do DFS'a
            //                                    tylko poprzedni wiersz. Wypełniamy go zgodnie z logiką algorytmu dynamicznego Levenshteina,
            //                                    odbieramy ostatnią wartość tego wiersza, która i jest odległością edycyjną pomiędzy
            //                                    "word" a "win". Sprawdzamy, czy ona leży w odpowiednim zakresie (czy jest <= distance) i
            //                                    jeżeli jest oraz jeżeli bieżący prefiks jest słowem, to dodajemy go do słownika wyjściowego.
            //                                    Potem wywołujemy DFS'a po wszystkich dzieci tego węzła 'n', gdzie podajemy bieżący wiersz
            //                                    jako poprzedni i "win" + symbol dziecka jako bieżący prefiks.
            //
            // Jeszcze dodałem dodatkowy warunek wyjścia z rekurencyjnego DFS'a, bo można zauważyć, że odległość edycyjna w pewnym momencie
            // algorytmu nie może być mniejsza, niż najmniejsza wartość elementu z wiersza poprzedniego. Jest to oczywiste, bo przecież
            // zawsze bierzemy Min(dist[i-1,j] + 1, dist[i-1,j-1] + 0/1, dist[i,j-1]). A więc jeżeli w pewnym momencie wiersz bieżący
            // będzie zapełniony zbyt dużymi liczbami i wszystkie one będą większe od distance, to wtedy nie ma sensu iść głębiej, bo i 
            // tak w żaden sposób nie zmniejszymy te liczby, a najwyżej one zostaną na tym samym poziomie. A więc wszystkie słowa z 
            // konkretnym prefiksem, który już jest od "word" w odległości edycyjnej większej niż distance, nie mają szans być w odległości
            // edycyjnej mniejszej. Dzięki temu w wielu przypadkach przyspieszamy algorytm (w pesymistycznym przypadku jednak nie). 

            List<(string, int)> words = new List<(string, int)>();
            int[] LevenshteinPreviousRow = new int[word.Length + 1];

            for (int i = 0; i <= word.Length; i++)
                LevenshteinPreviousRow[i] = i;

            void DFS (TrieNode rootNode, int[] previousRow, string currentPrefix)
            {
                int[] LevenshteinCurrentRow = new int[word.Length + 1];
                LevenshteinCurrentRow[0] = previousRow[0] + 1;

                for (int i = 1; i <= word.Length; i++)
                {
                    int isEqual = (word[i - 1] == currentPrefix[currentPrefix.Length - 1]) ? 0 : 1;
                    LevenshteinCurrentRow[i] = Math.Min(Math.Min(previousRow[i] + 1, LevenshteinCurrentRow[i - 1] + 1),
                        previousRow[i - 1] + isEqual);
                }

                if (LevenshteinCurrentRow.Min() > distance)
                    return;

                if (rootNode.IsWord && LevenshteinCurrentRow[word.Length] <= distance)             
                    words.Add((currentPrefix, LevenshteinCurrentRow[word.Length]));

                foreach (var pair in rootNode.childs)
                    DFS(pair.Value, LevenshteinCurrentRow, currentPrefix + pair.Key);
            }

            foreach (var childNodePair in root.childs)
                DFS(childNodePair.Value, LevenshteinPreviousRow, "" + childNodePair.Key);

            return words;
        }


        private int Levenshtein(string word1, string word2)
        {
            int n = word1.Length;
            int m = word2.Length;
            int[,] dist = new int[m + 1, n + 1];

            for (int i = 0; i <= n; i++) dist[0, i] = i;
            for (int j = 0; j <= m; j++) dist[j, 0] = j;
            
            for (int i = 1; i <= m; i++)
            {
                for (int j = 1; j <= n; j++)
                {
                    int isEqual = (word1[j - 1] == word2[i - 1]) ? 0 : 1;
                    dist[i, j] = Math.Min(Math.Min(dist[i, j - 1] + 1, dist[i - 1, j] + 1), dist[i - 1, j - 1] + isEqual);
                }
            }

            return dist[m, n];
        }
    }
}
