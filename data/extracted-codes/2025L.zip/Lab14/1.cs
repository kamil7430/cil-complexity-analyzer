﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
// using static ASD.TestCase;

namespace ASD
{
    /// <summary>
    /// Klasa drzewa prefiksowego z możliwością wyszukiwania słów w zadanej odległości edycyjnej
    /// </summary>
    public class Lab14_Trie : System.MarshalByRefObject
    {
        // klasy TrieNode NIE WOLNO ZMIENIAĆ!
        private class TrieNode
        {
            public SortedDictionary<char, TrieNode> childs = new SortedDictionary<char, TrieNode>();
            public bool IsWord = false;
            public int WordCount = 0;
        }

        private TrieNode root;

        public Lab14_Trie()
        {
            root = new TrieNode();
        }

        /// <summary>
        /// Zwraca liczbę przechowywanych słów
        /// Ma działać w czasie stałym - O(1)
        /// </summary>
        public int Count { get; private set; }

        /// <summary>
        /// Zwraca liczbę przechowywanych słów o zadanym prefiksie
        /// Ma działać w czasie O(len(startWith))
        /// </summary>
        /// <param name="startWith">Prefiks słów do zliczenia</param>
        /// <returns>Liczba słów o zadanym prefiksie</returns>
        public int CountPrefix(string startWith)
        {
            var p = root;
            for (int i = 0; i < startWith.Length; i++)
            {
                if (!p.childs.ContainsKey(startWith[i]))
                    return 0;
                p = p.childs[startWith[i]];
            }

            return p.WordCount;
        }

        /// <summary>
        /// Dodaje słowo do słownika
        /// Ma działać w czasie O(len(newWord))
        /// </summary>
        /// <param name="newWord">Słowo do dodania</param>
        /// <returns>True jeśli słowo udało się dodać, false jeśli słowo już istniało</returns>
        public bool AddWord(string newWord)
        {
            if (Contains(newWord)) return false;

            var p = root;
            for (int i = 0; i < newWord.Length; i++)
            {
                p.WordCount++;
                if (!p.childs.ContainsKey(newWord[i]))
                {
                    var newNode = new TrieNode();
                    p.childs.Add(newWord[i], newNode);
                }

                p = p.childs[newWord[i]];
            }

            p.IsWord = true;
            p.WordCount++;
            Count++;
            return true;
        }

        /// <summary>
        /// Sprawdza czy podane słowo jest przechowywane w słowniku
        /// Ma działać w czasie O(len(word))
        /// </summary>
        /// <param name="word">Słowo do sprawdzenia</param>
        /// <returns>True jeśli słowo znajduje się w słowniku, wpp. false</returns>
        public bool Contains(string word)
        {
            var p = root;
            for (int i = 0; i < word.Length; i++)
            {
                if (!p.childs.ContainsKey(word[i]))
                    return false;
                p = p.childs[word[i]];
            }

            return p.IsWord;
        }

        /// <summary>
        /// Usuwa podane słowo ze słownika
        /// Ma działać w czasie O(len(word))
        /// </summary>
        /// <param name="word">Słowo do usunięcia</param>
        /// <returns>True jeśli udało się słowo usunąć, false jeśli słowa nie było w słowniku</returns>
        public bool Remove(string word)
        {
            if (!Contains(word)) return false;
            var p = root;

            for (int i = 0; i < word.Length - 1; i++)
            {
                p.WordCount--;
                p = p.childs[word[i]];
            }

            var lastChar = word[word.Length - 1];
            if (p.childs[lastChar].childs.Count == 0)
            {
                p.childs.Remove(lastChar);
                return true;
            }

            p = p.childs[lastChar];
            p.IsWord = false;

            void Rec(TrieNode t)
            {
                t.WordCount--;

                foreach (var c in t.childs)
                {
                    Rec(t.childs[c.Key]);
                }
            }

            Rec(p);
            Count--;
            return true;
        }

        /// <summary>
        /// Zwraca wszystkie słowa o podanym prefiksie. 
        /// Dla pustego prefiksu zwraca wszystkie słowa ze słownika.
        /// Wynik jest w porządku alfabetycznym.
        /// Ma działać w czasie O(liczba węzłów w drzewie)
        /// </summary>
        /// <param name="startWith">Prefiks</param>
        /// <returns>Wyliczenie zawierające wszystkie słowa ze słownika o podanym prefiksie</returns>
        public List<string> AllWords(string startWith = "")
        {
            var result = new List<string>();
            var p = root;

            for (int i = 0; i < startWith.Length; i++)
            {
                if (!p.childs.ContainsKey(startWith[i]))
                    return result;
                p = p.childs[startWith[i]];
            }

            var word = new StringBuilder(startWith);

            void Rec(TrieNode t)
            {
                if (t.IsWord)
                {
                    result.Add(word.ToString());
                }

                foreach (var c in t.childs)
                {
                    word.Append(c.Key);
                    Rec(t.childs[c.Key]);
                    word.Remove(word.Length - 1, 1);
                }
            }

            Rec(p);
            return result;
        }

        /// <summary>
        /// Wyszukuje w słowniku wszystkie słowa w podanej odległości edycyjnej od zadanego słowa
        /// Wynik jest w porządku alfabetycznym ze względu na słowa (a nie na odległość).
        /// Ma działać optymalnie - tj. niedozwolone jest wyszukanie wszystkich słów i sprawdzenie ich odległości
        /// Należy przeszukując drzewo odpowiednio odrzucać niektóre z gałęzi.
        /// Złożoność pesymistyczna (gdy wszystkie słowa w słowniku mieszczą się w zadanej odległości)
        /// O(len(word) * (liczba węzłów w drzewie))
        /// </summary>
        /// <param name="word">Słowo</param>
        /// <param name="distance">Odległość edycyjna</param>
        /// <returns>Lista zawierająca pary (słowo, odległość) spełniające warunek odległości edycyjnej</returns>
        public List<(string, int)> Search(string word, int distance = 1)
        {
            var result = new List<(string, int)>();
            var n = word.Length;
            var initialRow = new int[n + 1];
            for (int i = 0; i <= n; i++)
                initialRow[i] = i;

            var prefix = new StringBuilder();
            foreach (var c in root.childs)
                InvokeRec(c.Value, c.Key, initialRow);

            void InvokeRec(TrieNode t, char newChar, int[] previousRow)
            {
                prefix.Append(newChar);
                Rec(t, previousRow);
                prefix.Remove(prefix.Length - 1, 1);
            }

            void Rec(TrieNode t, int[] previousRow)
            {
                var currentRow = new int[n + 1];
                currentRow[0] = previousRow[0] + 1;
                var currentRowMin = currentRow[0];

                for (int j = 1; j <= n; j++)
                {
                    var insertCost = currentRow[j - 1] + 1;
                    var deleteCost = previousRow[j] + 1;
                    var replaceCost = word[j - 1] == prefix[prefix.Length - 1]
                        ? previousRow[j - 1]
                        : previousRow[j - 1] + 1;

                    currentRow[j] = Math.Min(Math.Min(insertCost, deleteCost), replaceCost);
                    if (currentRow[j] < currentRowMin)
                        currentRowMin = currentRow[j];
                }
                
                var distanceAtEnd = currentRow[n];
                if (t.IsWord && distanceAtEnd <= distance)
                    result.Add((prefix.ToString(), distanceAtEnd));

                if (currentRowMin <= distance)
                {
                    foreach (var c in t.childs)
                        InvokeRec(c.Value, c.Key, currentRow);
                }
            }

            return result;
        }
    }
}