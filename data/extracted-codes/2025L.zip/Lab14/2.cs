﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ASD
{
    /// <summary>
    /// Klasa drzewa prefiksowego z możliwością wyszukiwania słów w zadanej odległości edycyjnej
    /// </summary>
    public class Lab14_Trie : System.MarshalByRefObject
    {
        
        // klasy TrieNode NIE WOLNO ZMIENIAĆ!
        private class TrieNode
        {
            public SortedDictionary<char, TrieNode> childs = new SortedDictionary<char, TrieNode>();
            public bool IsWord = false;
            public int WordCount = 0;
        }

        private TrieNode root;

        public Lab14_Trie()
        {
            root = new TrieNode();
        }

        /// <summary>
        /// Zwraca liczbę przechowywanych słów
        /// Ma działać w czasie stałym - O(1)
        /// </summary>
        public int Count { get; private set; }

        public bool IsShrunken { get; private set; } = true;

        /// <summary>
        /// Zwraca liczbę przechowywanych słów o zadanym prefiksie
        /// Ma działać w czasie O(len(startWith))
        /// </summary>
        /// <param name="startWith">Prefiks słów do zliczenia</param>
        /// <returns>Liczba słów o zadanym prefiksie</returns>
        public int CountPrefix(string startWith)
        {
            TrieNode iterator = root;
            foreach (char ch in startWith)
            {
                if (!iterator.childs.ContainsKey(ch))
                {
                    return 0;
                }
                iterator = iterator.childs[ch];
            }
            return iterator.WordCount;
        }

        /// <summary>
        /// Dodaje słowo do słownika
        /// Ma działać w czasie O(len(newWord))
        /// </summary>
        /// <param name="newWord">Słowo do dodania</param>
        /// <returns>True jeśli słowo udało się dodać, false jeśli słowo już istniało</returns>
        public bool AddWord(string newWord)
        {
            TrieNode iterator = root;
            foreach (char ch in newWord)
            {
                if (!iterator.childs.ContainsKey(ch))
                {
                    iterator.childs[ch] = new TrieNode();
                }
                iterator = iterator.childs[ch];
            }
            if (iterator.IsWord)
            {
                return false;
            }
            iterator.IsWord = true;
            Count++;

            iterator = root;
            foreach (char ch in newWord)
            {
                iterator.WordCount++;
                iterator = iterator.childs[ch];
            }
            iterator.WordCount++;

            IsShrunken = false;
            return true;
        }

        /// <summary>
        /// Sprawdza czy podane słowo jest przechowywane w słowniku
        /// Ma działać w czasie O(len(word))
        /// </summary>
        /// <param name="word">Słowo do sprawdzenia</param>
        /// <returns>True jeśli słowo znajduje się w słowniku, wpp. false</returns>
        public bool Contains(string word)
        {
            TrieNode iterator = root;
            foreach (char ch in word)
            {
                if (!iterator.childs.ContainsKey(ch))
                {
                    return false;
                }
                iterator = iterator.childs[ch];
            }
            return iterator.IsWord;
        }

        /// <summary>
        /// Usuwa podane słowo ze słownika
        /// Ma działać w czasie O(len(word))
        /// </summary>
        /// <param name="word">Słowo do usunięcia</param>
        /// <returns>True jeśli udało się słowo usunąć, false jeśli słowa nie było w słowniku</returns>
        public bool Remove(string word)
        {
            if (!Contains(word))
            {
                return false;
            }
            TrieNode iterator = root;
            foreach (char ch in word)
            {
                iterator.WordCount--;
                iterator = iterator.childs[ch];
            }
            iterator.IsWord = false;
            Count--;
            iterator.WordCount--;
            return true;
        }

        /// <summary>
        /// Zwraca wszystkie słowa o podanym prefiksie. 
        /// Dla pustego prefiksu zwraca wszystkie słowa ze słownika.
        /// Wynik jest w porządku alfabetycznym.
        /// Ma działać w czasie O(liczba węzłów w drzewie)
        /// </summary>
        /// <param name="startWith">Prefiks</param>
        /// <returns>Wyliczenie zawierające wszystkie słowa ze słownika o podanym prefiksie</returns>
        public List<string> AllWords(string startWith = "")
        {
            StringBuilder sb = new StringBuilder(startWith);
            List<string> result = new List<string>();
            TrieNode iterator = root;
            foreach (char ch in startWith)
            {
                if (!iterator.childs.ContainsKey(ch))
                {
                    return result;
                }
                iterator = iterator.childs[ch];
            }

            Stack<(TrieNode, StringBuilder)> stack = new Stack<(TrieNode, StringBuilder)>();
            stack.Push((iterator, sb));

            while (stack.Count > 0)
            {
                var (node, currentWord) = stack.Pop();
                if (node.IsWord)
                {
                    result.Add(currentWord.ToString());
                }
                Stack<KeyValuePair<char, TrieNode>> childrenToVisit = new Stack<KeyValuePair<char, TrieNode>>();
                foreach (var child in node.childs)
                {
                    childrenToVisit.Push(child);
                }

                foreach (var child in childrenToVisit)
                {
                    currentWord.Append(child.Key);
                    stack.Push((child.Value, new StringBuilder(currentWord.ToString())));
                    currentWord.Length--;
                }
            }
            return result;
        }

        /// <summary>
        /// Wyszukuje w słowniku wszystkie słowa w podanej odległości edycyjnej od zadanego słowa
        /// Wynik jest w porządku alfabetycznym ze względu na słowa (a nie na odległość).
        /// Ma działać optymalnie - tj. niedozwolone jest wyszukanie wszystkich słów i sprawdzenie ich odległości
        /// Należy przeszukując drzewo odpowiednio odrzucać niektóre z gałęzi.
        /// Złożoność pesymistyczna (gdy wszystkie słowa w słowniku mieszczą się w zadanej odległości)
        /// O(len(word) * (liczba węzłów w drzewie))
        /// </summary>
        /// <param name="word">Słowo</param>
        /// <param name="distance">Odległość edycyjna</param>
        /// <returns>Lista zawierająca pary (słowo, odległość) spełniające warunek odległości edycyjnej</returns>
        public List<(string, int)> Search(string word, int distance = 1, bool shrink = true)
        {
            // Opis zadania sugeruje, ze dominujaca operacja bedzie przeszukiwanie drzewa, a nie jego modyfikacja. Operacja Shrink, jest O(liczba wezlow), wiec i tak nie zmienia zlozonosci Search.
            if (shrink && !IsShrunken)
            {
                Shrink();
            }

            List<(string, int)> result = new List<(string, int)>();
            TrieNode iterator = root;
            Stack<(TrieNode, int[], string)> stack = new Stack<(TrieNode, int[], string)>();
            int[] firstColumn = new int[word.Length + 1];
            for (int i = 0; i < firstColumn.Length; i++)
            {
                firstColumn[i] = i;
            }
            stack.Push((iterator, firstColumn, ""));

            while (stack.Count > 0)
            {
                var (node, currentColumn, currentString) = stack.Pop();
                int currentDistance = currentColumn[currentColumn.Length - 1];
                if (node.IsWord && currentDistance <= distance)
                {
                    result.Add((currentString, currentDistance));
                }

                // Brak reverse() w starym dotnecie, a chcialem uniknac rekurencji. (wyczytałem, ze tak wewnetrznie dziala reverse)
                Stack<KeyValuePair<char, TrieNode>> childrenToVisit = new Stack<KeyValuePair<char, TrieNode>>();
                foreach (var child in node.childs)
                {
                    childrenToVisit.Push(child);
                }

                foreach (var child in childrenToVisit)
                {
                    int currentStringLength = currentString.Length;
                    int newCharIndex = currentString.Length;
                    int newStringLength = currentStringLength + 1;

                    bool przewrwanie = currentDistance - ((word.Length + distance) - currentStringLength) > distance;
                    if (przewrwanie)
                    {
                        continue;
                    }

                    int[] nextColumn = CalclulateNextColumn(currentColumn, word, child.Key);
                    stack.Push((child.Value, nextColumn, currentString + child.Key));
                }
            }
            return result;
            // pesymistycznie O(len(word) * (liczba węzłów w drzewie))
        }

        private int[] CalclulateNextColumn(int[] previousColumn, string word, char horizontalChar)
        {
            int height = previousColumn.Length;
            int[] nextColumn = new int[height];
            nextColumn[0] = previousColumn[0] + 1;

            for (int i = 1; i < height; i++)
            {
                int cost = horizontalChar == word[i - 1] ? 0 : 1;
                nextColumn[i] = Math.Min(Math.Min(previousColumn[i - 1] + cost, previousColumn[i] + 1), nextColumn[i - 1] + 1);
               
            }
            return nextColumn;
            // O(word.Lenght)
        }

        public void Shrink()
        {
            // O(liczba wezłów w drzewie)
            TrieNode iterator = root;
            Stack<TrieNode> stack = new Stack<TrieNode>();
            Stack<char> toRemove = new Stack<char>();
            stack.Push(iterator);
            while (stack.Count > 0)
            {
                iterator = stack.Pop();
                foreach (var child in iterator.childs)
                {
                    if (child.Value.WordCount == 0)
                    {
                        toRemove.Push(child.Key);
                    }
                    else
                    {
                        stack.Push(child.Value);
                    }
                }
                while (toRemove.Count > 0)
                {
                    iterator.childs.Remove(toRemove.Pop());
                }
            }
        }
    }
}