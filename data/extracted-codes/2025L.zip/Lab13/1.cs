﻿using System;
using System.Text;

namespace Lab15
{
    public static class stringExtender
    {
        private static int[] ComputeP(string s)
        {
            var n = s.Length;
            var P = new int[n + 1];

            var t = 0;
            for (var i = 2; i <= n; i++)
            {
                while (t > 0 && s[t] != s[i - 1])
                    t = P[t];
                if (s[t] == s[i - 1])
                    t++;
                P[i] = t;
            }

            return P;
        }
        
        /// <summary>
        /// Metoda zwraca okres słowa s, tzn. najmniejszą dodatnią liczbę p taką, że s[i]=s[i+p] dla każdego i od 0 do |s|-p-1.
        /// 
        /// Metoda musi działać w czasie O(|s|)
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        public static int Period(this string s)
        {
            var P = ComputeP(s);
            
            return s.Length - P[^1];
        }

        /// <summary>
        /// Metoda wyznacza największą potęgę zawartą w słowie s.
        /// 
        /// Jeżeli x jest słowem, wówczas przez k-tą potęgę słowa x rozumiemy k-krotne powtórzenie słowa x
        /// (na przykład xyzxyzxyz to trzecia potęga słowa xyz).
        /// 
        /// Należy zwrócić największe k takie, że k-ta potęga jakiegoś słowa jest zawarta w s jako spójny podciąg.
        /// </summary>
        /// <param name="s"></param>
        /// <param name="startIndex">Pierwszy indeks fragmentu zawierającego znalezioną potęgę</param>
        /// <param name="endIndex">Pierwszy indeks po fragmencie zawierającym znalezioną potęgę</param>
        /// <returns></returns>
        public static int MaxPower(this string s, out int startIndex, out int endIndex)
        {
                var n = s.Length;
                startIndex = endIndex = 0;
                var best = 0;

                for (int i = 0; i < n; i++)
                {
                    var P = ComputeP(s[i..]);
                    for (int j = i + 1; j <= n; j++)
                    {
                        var len = j - i;
                        var period = len - P[j - i];
                        if (len % period != 0) continue;
                        var pow = len / period;
                        if (pow > best)
                        {
                            best = pow;
                            startIndex = i;
                            endIndex = j;
                        }
                    }
                }
                
                return best;
        }
    }
}
