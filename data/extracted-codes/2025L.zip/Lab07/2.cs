﻿using ASD.Graphs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASD
{
    public static class FlowExtender
    {

        /// <summary>
        /// Metod wylicza minimalny s-t-przekrój.
        /// </summary>
        /// <param name="undirectedGraph">Nieskierowany graf</param>
        /// <param name="s">wierzchołek źródłowy</param>
        /// <param name="t">wierzchołek docelowy</param>
        /// <param name="minCut">minimalny przekrój</param>
        /// <returns>wartość przekroju</returns>
        public static double MinCut(this Graph<double> undirectedGraph, int s, int t, out Edge<double>[] minCut)
        {
            DiGraph<double> directedGraph = new DiGraph<double>(undirectedGraph); // chyba niepotrzebne
            (double maxFlow, DiGraph<double> flowGraph) = MyFordFulkerson<double>(directedGraph, s, t);



            minCut = new Edge<double>[0];
            return maxFlow;
        }

        public static (T, DiGraph<T>) MyFordFulkerson<T>(this IGraph<T> G, int source, int sink) where T : IComparable<T>, new()
        {
            if (source == sink)
            {
                throw new ArgumentException($"Szukanie przeływu od wierzchołka {source} do niego samego!");
            }

            if (source < 0 || source >= G.VertexCount || sink < 0 || sink > G.VertexCount)
            {
                throw new ArgumentException($"Numer źródła ({source}) lub ujścia ({sink}) poza zakresem!");
            }

            T val = new T();
            T val2 = val;
            DiGraph<T> diGraph = new DiGraph<T>(G.VertexCount, G.Representation);
            DiGraph<T> diGraph2 = new DiGraph<T>(G.VertexCount, G.Representation);
            for (int i = 0; i < G.VertexCount; i++)
            {
                foreach (Edge<T> item in G.OutEdges(i))
                {
                    if (val.CompareTo(item.Weight) < 0)
                    {
                        diGraph2.AddEdge(item.From, item.To, item.Weight);
                    }
                    else if (val.CompareTo(item.Weight) > 0)
                    {
                        throw new ArgumentException("Próba wyznaczenia przepływu w sieci z ujemnymi przepustowościami!");
                    }
                }
            }

            int[] array;
            while ((array = BFSPath(diGraph2, source, sink)) != null)
            {
                T edgeWeight = diGraph2.GetEdgeWeight(array[0], array[1]);
                for (int j = 1; j < array.GetLength(0) - 1; j++)
                {
                    if (edgeWeight.CompareTo(diGraph2.GetEdgeWeight(array[j], array[j + 1])) > 0)
                    {
                        edgeWeight = diGraph2.GetEdgeWeight(array[j], array[j + 1]);
                    }
                }

                val2 = (dynamic)val2 + (dynamic)edgeWeight;
                for (int k = 0; k < array.GetLength(0) - 1; k++)
                {
                    T val3 = edgeWeight;
                    if (diGraph.HasEdge(array[k + 1], array[k]))
                    {
                        T edgeWeight2 = diGraph.GetEdgeWeight(array[k + 1], array[k]);
                        if (edgeWeight2.CompareTo(val3) > 0)
                        {
                            T weight = (dynamic)edgeWeight2 - (dynamic)edgeWeight;
                            diGraph.SetEdgeWeight(array[k + 1], array[k], weight);
                            continue;
                        }

                        diGraph.RemoveEdge(array[k + 1], array[k]);
                        val3 = (dynamic)edgeWeight - (dynamic)edgeWeight2;
                    }

                    if (!diGraph.HasEdge(array[k], array[k + 1]))
                    {
                        diGraph.AddEdge(array[k], array[k + 1]);
                    }

                    T weight2 = (dynamic)diGraph.GetEdgeWeight(array[k], array[k + 1]) + (dynamic)val3;
                    diGraph.SetEdgeWeight(array[k], array[k + 1], weight2);
                    if (weight2.CompareTo(new T()) == 0)
                    {
                        diGraph.RemoveEdge(array[k], array[k + 1]);
                    }
                }

                for (int l = 0; l < array.GetLength(0) - 1; l++)
                {
                    if (!diGraph2.HasEdge(array[l + 1], array[l]))
                    {
                        diGraph2.AddEdge(array[l + 1], array[l]);
                    }

                    T weight3 = (dynamic)diGraph2.GetEdgeWeight(array[l + 1], array[l]) + (dynamic)edgeWeight;
                    diGraph2.SetEdgeWeight(array[l + 1], array[l], weight3);
                    T weight4 = (dynamic)diGraph2.GetEdgeWeight(array[l], array[l + 1]) - (dynamic)edgeWeight;
                    if (weight4.CompareTo(val) == 0)
                    {
                        diGraph2.RemoveEdge(array[l], array[l + 1]);
                    }
                    else
                    {
                        diGraph2.SetEdgeWeight(array[l], array[l + 1], weight4);
                    }
                }
            }

            return (val2, diGraph);
        }

        // Zwraca ścieżkę jako tablicę wierzchołków lub null, jeśli ścieżka nie istnieje
        public static int[] BFSPath<T>(DiGraph<T> residualGraph, int source, int sink) where T : IComparable<T>, new()
        {
            int n = residualGraph.VertexCount;
            var queue = new Queue<int>();
            var visited = new bool[n];
            var parent = new int[n];
            for (int i = 0; i < n; ++i) parent[i] = -1;

            queue.Enqueue(source);
            visited[source] = true;
            T zero = new T();

            while (queue.Count > 0)
            {
                int u = queue.Dequeue();

                if (u == sink)
                {
                    var path = new List<int>();
                    int current = sink;
                    while (current != -1)
                    {
                        path.Add(current);
                        current = parent[current];
                    }
                    if (path.Count == 0 || path[path.Count - 1] != source)
                    {
                        return null;
                    }
                    path.Reverse();
                    return path.ToArray();
                }

                foreach (var edge in residualGraph.OutEdges(u))
                {
                    int v = edge.To;
                    if (!visited[v])
                    {
                        visited[v] = true;
                        parent[v] = u;
                        queue.Enqueue(v);
                    }
                }
            }
            return null;
        }

        /// <summary>
        /// Metada liczy spójność krawędziową grafu oraz minimalny zbiór rozcinający.
        /// </summary>
        /// <param name="undirectedGraph">nieskierowany graf</param>
        /// <param name="cutingSet">zbiór krawędzi rozcinających</param>
        /// <returns>spójność krawędziowa</returns>
        public static int EdgeConnectivity(this Graph<double> undirectedGraph, out Edge<double>[] cutingSet)
        {
            cutingSet = null;
            return 0;
        }
        
    }
}
