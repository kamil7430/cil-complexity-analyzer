﻿using ASD.Graphs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASD
{
    public static class FlowExtender
    {
        /// <summary>
        /// Metod wylicza minimalny s-t-przekrój.
        /// </summary>
        /// <param name="undirectedGraph">Nieskierowany graf</param>
        /// <param name="s">wierzchołek źródłowy</param>
        /// <param name="t">wierzchołek docelowy</param>
        /// <param name="minCut">minimalny przekrój</param>
        /// <returns>wartość przekroju</returns>
        public static double MinCut(this Graph<double> undirectedGraph, int s, int t, out Edge<double>[] minCut)
        {
            var n = undirectedGraph.VertexCount;
            var G = new DiGraph<double>(n, undirectedGraph.Representation);
            for (var v = 0; v < n; v++)
            {
                foreach (var e in undirectedGraph.OutEdges(v))
                    G.AddEdge(e.From, e.To, e.Weight);
            }

            var (val, f) = Flows.FordFulkerson(G, s, t);

            var resid = new DiGraph<double>(n, undirectedGraph.Representation);
            for (var u = 0; u < n; u++)
            {
                foreach (var w in G.OutNeighbors(u))
                {
                    var c = G.GetEdgeWeight(u, w) -
                            (f.HasEdge(u, w) ? f.GetEdgeWeight(u, w) : 0) +
                            (f.HasEdge(w, u) ? f.GetEdgeWeight(w, u) : 0);
                    if (c > 0)
                        resid.AddEdge(u, w, c);
                }
            }

            var visited = new bool[n];
            visited[s] = true;
            foreach (var e in resid.DFS().SearchFrom(s))
            {
                visited[e.To] = true;
            }
            
            var cutEdges = new List<Edge<double>>();
            for (var v = 0; v < n; v++)
            {
                if (!visited[v]) continue;
                foreach (var e in G.OutEdges(v))
                {
                    if (!visited[e.To])
                        cutEdges.Add(e);
                }
            }

            minCut = cutEdges.ToArray();
            return val;
        }

        /// <summary>
        /// Metada liczy spójność krawędziową grafu oraz minimalny zbiór rozcinający.
        /// </summary>
        /// <param name="undirectedGraph">nieskierowany graf</param>
        /// <param name="cutingSet">zbiór krawędzi rozcinających</param>
        /// <returns>spójność krawędziowa</returns>
        public static int EdgeConnectivity(this Graph<double> undirectedGraph, out Edge<double>[] cutingSet)
        {
            int n = undirectedGraph.VertexCount;
            var bestCut = double.MaxValue;
            cutingSet = null;
            for (var v = 1; v < n; v++)
            {
                var tmp = new Edge<double>[] {};
                var cut = MinCut(undirectedGraph, 0, v, out tmp);
                if (cut < bestCut)
                {
                    bestCut = cut;
                    cutingSet = tmp;
                }
            }
            
            return (int)bestCut;
        }
    }
}