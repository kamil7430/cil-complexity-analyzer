﻿using ASD.Graphs;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ASD
{
    public class Lab10 : MarshalByRefObject
    {
        /// <summary>
        /// Szukanie najdłuższego powtórzenia w zadanym kolorowaniu grafu.
        /// </summary>
        /// <param name="G">Graf prosty</param>
        /// <param name="color">Kolorowanie wierzchołków G (color[v] to kolor wierzchołka v)</param>
        /// <returns>Ścieżka, na której występuje powtórzenie (numery kolejnych wierzchołków)</returns>
        /// <remarks>W przypadku braku powtórzeń należy zwrócić null lub tablicę o długości 0</remarks>
        public int[] FindLongestRepetition(Graph H, int[] color)
        {
            var n = H.VertexCount;

            // przemapowywujemy kolory na wypadek gdyby nie były kolejnymi liczbami całkowitymi
            var distinctColors = new HashSet<int>(color);
            var sorted = distinctColors.OrderBy(c => c).ToList();
            var map = new Dictionary<int, int>(sorted.Count);
            for (int i = 0; i < sorted.Count; i++)
                map[sorted[i]] = i;
            for (int v = 0; v < color.Length; v++)
                color[v] = map[color[v]];

            var cn = color.Length;
            var totalColors = new int[cn];
            foreach (var c in color) totalColors[c]++;

            // usuwamy krawędzie do wierzchołków z unikalnym kolorem
            var (G, singleColor) = CleanGraph(H, color, totalColors);

            var totalPairs = new int[cn, cn];
            for (int u = 0; u < n; u++)
                foreach (int v in G.OutNeighbors(u))
                    totalPairs[color[u], color[v]]++;

            var best = new int[0];
            var used = new bool[n];
            for (var v = 0; v < n; v++)
                if (totalColors[color[v]] == 1)
                    used[v] = true;

            // graf mówiący jak da się przechodzić między kolorami - potrzebny do generowania sekwencji kolorów
            var C = MakeColorGraph(G, color, totalPairs);

            var colorSeq = new List<int>(n / 2);
            var currentPath = new List<int>(n);
            var seqCount = new int[cn];
            var seqPairCount = new int[cn, cn];

            // reachedPairs[k] = lista wierzchołków (v1, v2) tż istnieją 2 rozłączne ścieżki spełniające colorSeq[0..k]
            // kończące się odpowiedniow na v1 i na v2 oraz maska wierzchołków użytych na tych ścieżkach
            var reachedPairs = new List<(int, int, bool[])>[n / 2];
            var seen = new int[n, n];

            ColorRec(0);
            return best;

            void ColorRec(int k)
            {
                if (k > (n - singleColor) / 2) return;

                if (k == 1)
                {
                    reachedPairs[0] = new List<(int, int, bool[])>();

                    for (int i = 0; i < n; i++)
                    for (int j = i + 1; j < n; j++)
                        if (!used[i] && !used[j] && color[i] == colorSeq[0] && color[j] == colorSeq[0])
                        {
                            var usd = new bool[n];
                            usd[i] = true;
                            usd[j] = true;
                            reachedPairs[0].Add((i, j, usd));
                        }
                }

                if (k > 1)
                {
                    reachedPairs[k - 1] = new List<(int, int, bool[])>();
                    foreach (var (u1, u2, m) in reachedPairs[k - 2])
                    {
                        foreach (int v1 in G.OutNeighbors(u1))
                        {
                            if (m[v1]) continue;
                            if (used[v1] || color[v1] != colorSeq[k - 1]) continue;
                            foreach (int v2 in G.OutNeighbors(u2))
                            {
                                if (m[v2]) continue;
                                if (v1 == v2) continue;
                                if (used[v2] || color[v2] != colorSeq[k - 1]) continue;

                                if (seen[v1, v2] == k) continue;
                                seen[v1, v2] = k;
                                seen[v2, v1] = k;

                                var newUsed = (bool[])m.Clone();
                                newUsed[v1] = true;
                                newUsed[v2] = true;

                                reachedPairs[k - 1].Add((v1, v2, newUsed));
                            }
                        }
                    }

                    if (reachedPairs[k - 1].Count == 0) return;
                }

                if (2 * k > best.Length) PathRec(0);

                if (k == 0)
                {
                    for (var col = 0; col < cn; col++)
                    {
                        seqCount[col]++;
                        colorSeq.Add(col);
                        if (seqCount[col] <= totalColors[col] / 2)
                            ColorRec(k + 1);
                        colorSeq.RemoveAt(k);
                        seqCount[col]--;
                    }

                    return;
                }

                foreach (var col in C.OutNeighbors(colorSeq[k - 1]))
                {
                    if (seqPairCount[colorSeq[k - 1], col] + 1 > totalPairs[colorSeq[k - 1], col] / 2)
                        continue;

                    if (seqCount[col] + 1 > totalColors[col] / 2) continue;

                    seqPairCount[colorSeq[k - 1], col]++;
                    seqPairCount[col, colorSeq[k - 1]]++;
                    seqCount[col]++;
                    colorSeq.Add(col);

                    ColorRec(k + 1);

                    colorSeq.RemoveAt(k);
                    seqCount[col]--;
                    seqPairCount[colorSeq[k - 1], col]--;
                    seqPairCount[col, colorSeq[k - 1]]--;
                }
            }

            void PathRec(int k)
            {
                if (k == 2 * colorSeq.Count)
                {
                    if (k > best.Length)
                        best = currentPath.ToArray();
                    return;
                }

                var nei = k == 0 ? Enumerable.Range(0, n) : G.OutNeighbors(currentPath[k - 1]);
                foreach (var v in nei)
                {
                    if (used[v] || color[v] != colorSeq[k % colorSeq.Count]) continue;

                    used[v] = true;
                    currentPath.Add(v);
                    PathRec(k + 1);
                    currentPath.RemoveAt(k);
                    used[v] = false;
                }
            }
        }

        private Graph MakeColorGraph(Graph G, int[] color, int[,] totalPairs)
        {
            var n = color.Max() + 1;
            var C = new Graph(n, G.Representation);

            for (var u = 0; u < G.VertexCount; u++)
                foreach (var v in G.OutNeighbors(u))
                    if (totalPairs[color[u], color[v]] > 1 && color[u] != color[v])
                        C.AddEdge(color[u], color[v]);

            return C;
        }

        private (Graph, int) CleanGraph(Graph G, int[] color, int[] totalColors)
        {
            int n = G.VertexCount;
            var H = new Graph(n, G.Representation);

            var singleColor = 0;
            foreach (var c in color)
                if (totalColors[c] == 1)
                    singleColor++;
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    if (G.HasEdge(i, j) && totalColors[color[i]] > 1 && totalColors[color[j]] > 1)
                        H.AddEdge(i, j);
                }
            }

            return (H, singleColor);
        }
    }
}