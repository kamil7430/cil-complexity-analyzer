﻿using ASD.Graphs;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ASD
{
    public class Lab10 : MarshalByRefObject
    {
        /// <summary>
        /// Szukanie najdłuższego powtórzenia w zadanym kolorowaniu grafu.
        /// </summary>
        /// <param name="G">Graf prosty</param>
        /// <param name="color">Kolorowanie wierzchołków G (color[v] to kolor wierzchołka v)</param>
        /// <returns>Ścieżka, na której występuje powtórzenie (numery kolejnych wierzchołków)</returns>
        /// <remarks>W przypadku braku powtórzeń należy zwrócić null lub tablicę o długości 0</remarks>
        public int[] FindLongestRepetition(Graph G, int[] color)
        {
            // Rozwiązanie, które podałem na zajęciach działało strasznie długo, bo "ziarnem" mojego algorytmu było 
            // przeszukiwanie wszystkich możliwych ścieżek. Oczywiście, stosowałem różne warunki wcześniejszego zakończenia
            // rekurencji (parzystość ścieżki, unikalne wierzchołki względem koloru, zbyt krótka ścieżka etc.), jednak nadal 
            // nie dawało to znacznego przyspieszenia. 
            // Musiałem wymyśleć jakieś inne podejście i zrezygnować z przeglądania wszystkich ścieżek.
            //
            // Idea algorytmu: równolegle buduję dwie ścieżki, które będą zawierać te same sekwencje kolorów (np. 1 -> 3 -> 4, 1 -> 3 -> 4).
            // Za każdym razem po dodaniu nowych wierzchołków o tym samym kolorze do obydwu ścieżek sprawdzam, czy mogę połączyć koniec
            // pierwszej ścieżki z początkiem drugiej krawędzią (lub na odwrót), tym samym robiąc 2x dłuższą ścieżkę,
            // która pasuje do tej, którą mam zwrócić. Uaktualniam zmienną przechowującą aktualnie najlepsze znalezione rozwiązanie
            // jeżeli znalazłem lepszą ścieżkę. Cała ta logika znajduje się w funkcji ExplorePairOfVerteces.
            // Zatem wystarczy przeszukać wszystkie unikalne pary wierzchołków, które są tego samego koloru.

            int n = G.VertexCount;
            bool[] usedVerteces = new bool[n];
            List<int> bestPath = null;

            // Tworzę słownik do "sortowania" wszystkich wierzchołków w grafie według ich kolorów.
            Dictionary<int, List<int>> vertecesByColor = new Dictionary<int, List<int>>();
            for (int v = 0; v < n; v++)
            {
                int vertexColor = color[v];
                if (!vertecesByColor.ContainsKey(vertexColor))
                    vertecesByColor[vertexColor] = new List<int>();

                vertecesByColor[vertexColor].Add(v);
            }

            // Tutaj rozpatruję wszystkie stworzone listy wierzchołków o tych samych kolorach. Dla każdej unikalnej pary wierzchołków
            // tego samego koloru wywołuję funkcję ExplorePairOfVerteces, która zawiera logikę algorytmu.
            // Warto zauważyć, że nie przeglądam tą samą parę wierzchołków dwa razy (czyli jak już obsłużyłem (u, v), to nie rozpatruję (v, u)).
            // Nie ma to sensu, bo później, jak będę próbował łączyć dwie ścieżki do jednej pasującej do rozwiązania, to wezmę pod uwagę 
            // zarówno możliwość łączenia "prawej" do "lewej", jak i "lewej" do "prawej". A więc ponowne rozpatrzenie (v, u) po już rozpatrzonym
            // (u, v) nie da żadnych lepszych wyników (a dokładnie da to samo, co i poprzednio dało (u, v)).
            foreach (List<int> concreteColorList in vertecesByColor.Values)
            {
                for (int i = 0; i < concreteColorList.Count; i++)
                {
                    for (int j = i + 1; j < concreteColorList.Count; j++)
                    {  
                        ExplorePairOfVerteces(concreteColorList[i], concreteColorList[j]);
                    }
                }
            }

            // Funkcja przyjmuję 2 wierzchołki - 2 początki równoległych ścieżek.
            void ExplorePairOfVerteces(int u, int v)
            {
                // Resetuję tablicę usedVerteces.
                for (int i = 0; i < usedVerteces.Length; i++)
                {
                    usedVerteces[i] = false;
                }

                // Tworzę listy do przechowywania informacji o bieżących ścieżkach i dodaję tam pierwsze wierzchołki (czyli u oraz v).
                List<int> leftPart = new List<int>();
                leftPart.Add(u);
                List<int> rightPart = new List<int>();
                rightPart.Add(v);

                usedVerteces[u] = true;
                usedVerteces[v] = true;

                // Backtracking został zrealizowany w tej funkcji Rec.
                void Rec(int lastLeftVertex, int lastRightVertex, int usedCount)
                {
                    // Po pierwsze muszę sprawdzić, czy można "poprawnie" połączyć dwie obecne ścieżki
                    // (czyli czy istnieje krawędź pomiędzy lastLeftVertex a v albo pomiędzy u a rightLastVertex).
                    // Jeśli znalazłem krawędź, która może poprawnie połączyć dwie obecne ścieżki i obecna połączona 
                    // ścieżka wyjdzie większej długości, niż dotychczasowa najdłuższa, to uaktualniam dotychczasową najdłuższą.
                    foreach (int neighbour in G.OutNeighbors(lastLeftVertex))
                    {
                        if (neighbour == v) 
                        {
                            if (bestPath == null || bestPath.Count < usedCount)
                            {
                                bestPath = new List<int>(leftPart);
                                bestPath.AddRange(rightPart);
                            }
                            break;
                        }
                    }
                    foreach (int neighbour in G.OutNeighbors(u))
                    {
                        if (neighbour == lastRightVertex)
                        {
                            if (bestPath == null || bestPath.Count < usedCount)
                            {
                                bestPath = new List<int>(rightPart);
                                bestPath.AddRange(leftPart);
                            }
                            break;
                        }
                    }
                    

                    if (bestPath != null)
                    {
                        // Sprawdzamy, czy da się w ogóle powiększyć aktualnie najdłuższą ścieżkę.
                        // Jeśli nie da się, to można wyjść z tego poziomu rekurencji już w tym momencie.
                        if (leftPart.Count + rightPart.Count + (n - usedCount) / 2 * 2 <= bestPath.Count)
                            return;
                    }

                    // Ta pętla podwójna rozważa wszystkie pary wierzchołków o następujących własnościach:
                    // - jeden wierzchołek jest sąsiadem końca lewej ścieżki, drugi - sąsiadem końca prawej ścieżki
                    // - para nie może się składać z tego samego wierzchołku (wtedy ścieżka będzie o nieparzystej długości)
                    // - każdy wierzchołek z tej pary nie pojawiał się wcześcniej na żadnej z tych dwóch ścieżek
                    // - te dwa wierzchołki z pary są tego samego koloru
                    // Jak znalazłem pasujące 2 wierzchołki, to dodaje ich do odpowiednich list, aktualizuję tablicę usedVerteces oraz
                    // wywołuję rekurencję z nowymi danymi. Kiedy rekurencja się kończy (nieważne z jakim wynikiem), odbywa się backtracking
                    // i ostatnio dodane wierzchołki zostają usunięte z odpowiednich list + usedVerteces zostaje ponownie zaktualizowana.
                    foreach (int neighbourOfLeft in G.OutNeighbors(lastLeftVertex))
                    {
                        if (usedVerteces[neighbourOfLeft])
                            continue;

                        foreach (int neighbourOfRight in G.OutNeighbors(lastRightVertex))
                        {
                            if (usedVerteces[neighbourOfRight])
                                continue;
                            if (neighbourOfLeft == neighbourOfRight) 
                                continue;
                            if (color[neighbourOfLeft] != color[neighbourOfRight])
                                continue;

                            usedVerteces[neighbourOfLeft] = true;
                            usedVerteces[neighbourOfRight] = true;
                            leftPart.Add(neighbourOfLeft);
                            rightPart.Add(neighbourOfRight);

                            Rec(neighbourOfLeft, neighbourOfRight, usedCount + 2);

                            leftPart.RemoveAt(leftPart.Count - 1);
                            rightPart.RemoveAt(rightPart.Count - 1);
                            usedVerteces[neighbourOfLeft] = false;
                            usedVerteces[neighbourOfRight] = false;
                        }
                    }
                }

                // Wywołuję rekurencyjną funkcję z początkowymi danymi.
                Rec(u, v, 2);
            }   

            return (bestPath == null) ? null : bestPath.ToArray();
        }
    }

}


