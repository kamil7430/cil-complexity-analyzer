﻿using ASD.Graphs;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ASD
{
    public class Lab10 : MarshalByRefObject
    {
        /// <summary>
        /// Szukanie najdłuższego powtórzenia w zadanym kolorowaniu grafu.
        /// </summary>
        /// <param name="G">Graf prosty</param>
        /// <param name="color">Kolorowanie wierzchołków G (color[v] to kolor wierzchołka v)</param>
        /// <returns>Ścieżka, na której występuje powtórzenie (numery kolejnych wierzchołków)</returns>
        /// <remarks>W przypadku braku powtórzeń należy zwrócić null lub tablicę o długości 0</remarks>
        public int[] FindLongestRepetition(Graph G, int[] color)
        {
            // Tworzymy wszystkie mozliwe pary sciezek o tej samej dlugosci i tej samej sekwencji kolorow
            List<int> segmentA = new List<int>();
            List<int> segmentB = new List<int>();
            List<int> longestPath = new List<int>();

            // Grupujemy wierzchołki kolorami
            Dictionary<int, HashSet<int>> singleColorVertices = new Dictionary<int, HashSet<int>>();
            for (int vertex = 0; vertex < G.VertexCount; vertex++)
            {
                if (!singleColorVertices.ContainsKey(color[vertex]))
                {
                    singleColorVertices.Add(color[vertex], new HashSet<int>());
                }
                singleColorVertices[color[vertex]].Add(vertex);
            }

            ReduceSingularSetsDictionary(singleColorVertices, color);

            foreach (HashSet<int> singleColorSet in singleColorVertices.Values)
            {
                foreach (int vertexA in singleColorSet.ToList())
                {
                    foreach(int vertexB in singleColorSet.ToList())
                    {
                        if (vertexA == vertexB)
                        {
                            continue;
                        }
                        segmentA.Add(vertexA);
                        singleColorSet.Remove(vertexA);
                        segmentB.Add(vertexB);
                        singleColorSet.Remove(vertexB);
                        LongestPathRec(G, color, segmentA, segmentB, longestPath, singleColorVertices);
                        segmentA.Remove(vertexA);
                        singleColorSet.Add(vertexA);
                        segmentB.Remove(vertexB);
                        singleColorSet.Add(vertexB);
                    }
                }
            }
            return longestPath.ToArray();
        }

        /// <summary>
        /// Czysci kazdy HashSet, ktorego Count rowna sie 1.
        /// </summary>
        /// <param name="singleColorVertices">Dictionary mapujacy kolor na zbior wierzcholkow o tym kolorze.</param>
        /// <param name="color">Tablica mapujaca wierzcholek na jego kolor.</param>
        /// <returns>liste zawierajaca ValueTuple(wierzcholek, kolor) dla kazdego usunietego wierzcholka.</returns>
        private List<(int, int)> ReduceSingularSetsDictionary(Dictionary<int, HashSet<int>> singleColorVertices, int[] color)
        {
            List<(int, int)> removedVertices = new List<(int, int)> ();
            foreach (HashSet<int> singleColorSet in singleColorVertices.Values)
            {
                if (singleColorSet.Count == 1)
                {
                    int vertex = singleColorSet.First();
                    int vertexColor = color[vertex];
                    removedVertices.Add(new ValueTuple<int, int>(vertex, vertexColor));
                    singleColorSet.Remove(vertex);
                }
            }
            return removedVertices;
        }

        /// <summary>
        /// Rekurencyjnie znajduje najdluzsze powtorzenie, ktorego pierwsza czesc zaczyna sie od segmentA, a druga od segmentB. 
        /// </summary>
        /// <param name="G"></param>
        /// <param name="color">Tablica mapujaca wierzcholek na jego kolor.</param>
        /// <param name="segmentA">Sciezka bedaca poczatkiem pierwszej czesci powtorzenia.</param>
        /// <param name="segmentB">Sciezka bedaca poczatkiem drugiej czesci powtorzenia.</param>
        /// <param name="longestPath">Lista przechowująca dotychczas znalezione najdłuższe powtórzenie.</param>
        /// <param name="singleColorVertices">Dictionary mapujacy kolor na zbior wierzcholkow o tym kolorze.</param>
        /// <remarks>segmentA i segmentB powinny miec identyczna sekwencje kolorow i skladac sie z roznych wierzcholkow.
        /// singleColorVertices nie powinien zawierac wierzcholkow obecnych w segmentA lub segmentB.</remarks>
        private void LongestPathRec(Graph G, int[] color, List<int> segmentA, List<int> segmentB, List<int> longestPath, Dictionary<int, HashSet<int>> singleColorVertices)
        {
            if (segmentA.Count + segmentB.Count > longestPath.Count && G.HasEdge(segmentA[segmentA.Count - 1], segmentB[0]))
            {
                longestPath.Clear();
                foreach (int vertex in segmentA)
                {
                    longestPath.Add(vertex);
                }
                foreach (int vertex in segmentB)
                {
                    longestPath.Add(vertex);
                }
            }

            List<(int, int)> removedVertices = ReduceSingularSetsDictionary(singleColorVertices, color);

            int availableVerticesCount = 0;
            foreach (HashSet<int> singleColorSet in singleColorVertices.Values)
            {
                availableVerticesCount += singleColorSet.Count;
            }
            if (longestPath.Count < segmentA.Count + segmentB.Count + availableVerticesCount)
            {
                foreach (int neighborA in G.OutNeighbors(segmentA[segmentA.Count - 1]))
                {
                    foreach (int neighborB in G.OutNeighbors(segmentB[segmentB.Count - 1]))
                    {
                        if (neighborA == neighborB
                            || color[neighborA] != color[neighborB]
                            || !singleColorVertices[color[neighborA]].Contains(neighborA)
                            || !singleColorVertices[color[neighborB]].Contains(neighborB))
                        {
                            continue;
                        }

                        segmentA.Add(neighborA);
                        singleColorVertices[color[neighborA]].Remove(neighborA);
                        segmentB.Add(neighborB);
                        singleColorVertices[color[neighborB]].Remove(neighborB);

                        LongestPathRec(G, color, segmentA, segmentB, longestPath, singleColorVertices);

                        segmentA.Remove(neighborA);
                        singleColorVertices[color[neighborA]].Add(neighborA);
                        segmentB.Remove(neighborB);
                        singleColorVertices[color[neighborB]].Add(neighborB);
                    }
                }
            }

            // Wstawiamy z powrotem usuniete pojedyncze wierzcholki
            foreach ((int vertex, int vertexColor) in removedVertices)
            {
                singleColorVertices[vertexColor].Add(vertex);
            }
        }
    }
}


