﻿
using System;

namespace ASD
{

    class ChangeMaking
    {

        /// <summary>
        /// Metoda wyznacza rozwiązanie problemu wydawania reszty przy pomocy minimalnej liczby monet
        /// bez ograniczeń na liczbę monet danego rodzaju
        /// </summary>
        /// <param name="amount">Kwota reszty do wydania</param>
        /// <param name="coins">Dostępne nominały monet</param>
        /// <param name="change">Liczby monet danego nominału użytych przy wydawaniu reszty</param>
        /// <returns>Minimalna liczba monet potrzebnych do wydania reszty</returns>
        /// <remarks>
        /// coins[i]  - nominał monety i-tego rodzaju
        /// change[i] - liczba monet i-tego rodzaju (nominału) użyta w rozwiązaniu
        /// Jeśli dostepnymi monetami nie da się wydać danej kwoty to change = null,
        /// a metoda również zwraca null
        ///
        /// Wskazówka/wymaganie:
        /// Dodatkowa uzyta pamięć powinna (musi) być proporcjonalna do wartości amount ( czyli rzędu o(amount) )
        /// </remarks>
        public int? NoLimitsDynamic(int amount, int[] coins, out int[] change)
        {
            int[,] array = new int[amount + 1, coins.Length + 1];
            for (int i = 0; i <= amount; i++)
            {
                if (i == 0) array[i, 0] = 0;
                else array[i, 0] = int.MaxValue;
            }

            int[] lastCoin = new int[amount + 1];
            for (int i = 0; i <= amount; i++)
            {
                lastCoin[i] = -1;
            }

            for (int i = 0; i < coins.Length; i++)
            {
                for (int j = 0; j <= amount; j++)
                {
                    array[j, i + 1] = array[j, i];
                }

                for (int j = 0; j <= amount; j++)
                {
                    if (array[j, i + 1] != int.MaxValue && j + coins[i] <= amount)
                    {
                        if (array[j, i + 1] + 1 < array[j + coins[i], i + 1])
                        {
                            array[j + coins[i], i + 1] = array[j, i + 1] + 1;
                            lastCoin[j + coins[i]] = i;
                        }
                    }
                }
            }

            if (array[amount, coins.Length] == int.MaxValue)
            {
                change = null;
                return null;
            }

            else
            {
                change = new int[coins.Length];
                int counter = amount;
                while (true)
                {
                    if (counter <= 0) break;
                    change[lastCoin[counter]]++;
                    counter -= coins[lastCoin[counter]];
                }
                return array[amount, coins.Length];
            }
        }

        /// <summary>
        /// Metoda wyznacza rozwiązanie problemu wydawania reszty przy pomocy minimalnej liczby monet
        /// z uwzględnieniem ograniczeń na liczbę monet danego rodzaju
        /// </summary>
        /// <param name="amount">Kwota reszty do wydania</param>
        /// <param name="coins">Dostępne nominały monet</param>
        /// <param name="limits">Liczba dostępnych monet danego nomimału</param>
        /// <param name="change">Liczby monet danego nominału użytych przy wydawaniu reszty</param>
        /// <returns>Minimalna liczba monet potrzebnych do wydania reszty</returns>
        /// <remarks>
        /// coins[i]  - nominał monety i-tego rodzaju
        /// limits[i] - dostepna liczba monet i-tego rodzaju (nominału)
        /// change[i] - liczba monet i-tego rodzaju (nominału) użyta w rozwiązaniu
        /// Jeśli dostepnymi monetami nie da się wydać danej kwoty to change = null,
        /// a metoda również zwraca null
        ///
        /// Wskazówka/wymaganie:
        /// Dodatkowa uzyta pamięć powinna (musi) być proporcjonalna do wartości iloczynu amount*(liczba rodzajów monet)
        /// ( czyli rzędu o(amount*(liczba rodzajów monet)) )
        /// </remarks>
        public int? Dynamic(int amount, int[] coins, int[] limits, out int[] change)
        {
            // "array" - dwuwymiarowa tablica do przechowywania bieżącego stanu algorytmu. 
            // Wartość array[i, j] oznacza minimalną liczbę monet do wydania i-tej kwoty za pomocą j pierwszych nominałów
            int[,] array = new int[amount + 1, coins.Length + 1];
            for (int i = 0; i <= amount; i++)
            {
                if (i == 0) array[i, 0] = 0;
                else array[i, 0] = int.MaxValue;
            }

            // "tempChange" - dwuwymiarowa tablica, która przechowuje bieżącą informację o tym, ile monet każdego nominalu należy wydać
            // żeby otrzymać kwotę. Np. w tempChange[i, j] znajduję się info o tym, ile monet j-go nominalu należy wziąć, żeby wydać i-tą kwotę.
            // UWAGA: "tempChange" przechowuje tylko bieżący stan dla każdej kwoty (od 0 do amount). Za każdym nowym nominalem i za każdym nowym
            // użyciem kolejnej monety dowolnego nominalu tempChange zmienia się, tym samym gubiąc info o z poprzedniego stanu. Na początku "tempChange"
            // zostaje wyzerowany.
            int[,] tempChange = new int[amount + 1, coins.Length];
            for (int i = 0; i <= amount; i++)
            {
                for (int j = 0; j < coins.Length; j++)
                {
                    tempChange[i, j] = 0;
                }
            }

            // "Change" - tablica, stworzona z podobnym celem do tablicy "tempChange". Ona służy do "kopiowania" stanu z tempChange i działania na kopii,
            // bo tego wymaga rozwiązanie zadania. Na początku też się zeruje i za każdym użyciem kolejnej monety dowolnego nominalu wartość "Change"
            // zostaje przypisana do "tempChange" (odbywa się odnowianie bieżącego stanu).
            int[,] Change = new int[amount + 1, coins.Length];
            for (int i = 0; i <= amount; i++)
            {
                for (int j = 0; j < coins.Length; j++)
                {
                    Change[i, j] = 0;
                }
            }

            // Główna pętla iteracyjna. Idzie po wszystkich nominałach z "coins".
            for (int i = 0; i < coins.Length; i++)
            {
                // Na początku należy wypełnić następną kolumnę wyrazami z poprzedniej.
                for (int j = 0; j <= amount; j++)
                {
                    array[j, i + 1] = array[j, i];
                }

                // Tablica pomocnicza jednowymiarowa. Nie możemy bezpośrednio zmieniać wartości w kolumnie oryginalnego "array".
                int[] tempArray = new int[amount + 1];
                for (int j = 0; j <= amount; j++)
                {
                    tempArray[j] = array[j, i];
                }

                // Pętla po każdej z monet z konkretngo nominału i.
                for (int k = 0; k < limits[i]; k++)
                {
                    // Pętla po wszystkich wartościach od 0 do amount.
                    for (int j = 0; j <= amount; j++)
                    {
                        // Jeśli resztę o wartości j + nominał monety mozna wydać lepszym sposobem (mniejszą liczbą monet), to
                        // uaktualniamy wartość w "tempArray" i w "Change".
                        if (tempArray[j] != int.MaxValue && j + coins[i] <= amount && tempArray[j + coins[i]] > tempArray[j] + 1)
                        {
                            array[j + coins[i], i + 1] = tempArray[j] + 1;
                            for (int l = 0; l < coins.Length; l++)
                            {
                                if (l == i) Change[j + coins[i], l] = tempChange[j, l] + 1;
                                else Change[j + coins[i], l] = tempChange[j, l];
                            }
                        }
                    }

                    // Zapisujemy wyniki kroku do "array".
                    for (int j = 0; j <= amount; j++)
                    {
                        tempArray[j] = array[j, i + 1];
                    }

                    // Zapisujemy wyniki do "tempChange".
                    for (int j = 0; j <= amount; j++)
                    {
                        for (int l = 0; l < coins.Length; l++)
                        {
                            tempChange[j, l] = Change[j, l];
                        }
                    }
                }   
            }
            
            // Jeśli nie uda się wydać amount za pomocą tych monet, zwracamy null.
            if (array[amount, coins.Length] == int.MaxValue)
            {
                change = null;
                return null;
            }

            // Jeśli uda się, to zwracamy ostatnią komórkę "array" - wynik algorytmu dynamicznego. Poza tym zapisujemy ostatni wierz 
            // tablicy dwuwymiarowej "tempChange" do out change[].
            else
            {
                change = new int[coins.Length];
                for (int i = 0; i < coins.Length; i++)
                {
                    change[i] = tempChange[amount, i];
                }
                return array[amount, coins.Length];
            }

        }

    }

}
