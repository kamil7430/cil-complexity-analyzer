﻿
using System;

namespace ASD
{

    class ChangeMaking
    {

        /// <summary>
        /// Metoda wyznacza rozwiązanie problemu wydawania reszty przy pomocy minimalnej liczby monet
        /// bez ograniczeń na liczbę monet danego rodzaju
        /// </summary>
        /// <param name="amount">Kwota reszty do wydania</param>
        /// <param name="coins">Dostępne nominały monet</param>
        /// <param name="change">Liczby monet danego nominału użytych przy wydawaniu reszty</param>
        /// <returns>Minimalna liczba monet potrzebnych do wydania reszty</returns>
        /// <remarks>
        /// coins[i]  - nominał monety i-tego rodzaju
        /// change[i] - liczba monet i-tego rodzaju (nominału) użyta w rozwiązaniu
        /// Jeśli dostepnymi monetami nie da się wydać danej kwoty to change = null,
        /// a metoda również zwraca null
        ///
        /// Wskazówka/wymaganie:
        /// Dodatkowa uzyta pamięć powinna (musi) być proporcjonalna do wartości amount ( czyli rzędu o(amount) )
        /// </remarks>
        public int? NoLimitsDynamic(int amount, int[] coins, out int[] change)
        {
            int[] coinsToGetThatAmount = new int[amount + 1];
            coinsToGetThatAmount[0] = 0;
            int[] lowestCoinAmountPath = new int[amount + 1];

            for (int currentAmount = 1; currentAmount <= amount; currentAmount++)
            {
                coinsToGetThatAmount[currentAmount] = int.MaxValue;
                for (int coinIndex = 0; coinIndex < coins.Length; coinIndex++)
                {
                    if (currentAmount < coins[coinIndex]) continue;
                    if (coinsToGetThatAmount[currentAmount - coins[coinIndex]] == int.MaxValue) continue;
                    int coinsToGetCurrentAmount = 1 + coinsToGetThatAmount[currentAmount - coins[coinIndex]];
                    if (coinsToGetCurrentAmount < coinsToGetThatAmount[currentAmount])
                    {
                        coinsToGetThatAmount[currentAmount] = coinsToGetCurrentAmount;
                        lowestCoinAmountPath[currentAmount] = coinIndex;
                    }
                }
            }
            if (coinsToGetThatAmount[amount] == int.MaxValue)
            {
                change = null;
                return null;
            }
            change = new int[coins.Length];
            int pathIndex = amount;
            while (pathIndex > 0)
            {
                change[lowestCoinAmountPath[pathIndex]]++;
                pathIndex -= coins[lowestCoinAmountPath[pathIndex]];
            }
            return coinsToGetThatAmount[amount];
        }

        /// <summary>
        /// Metoda wyznacza rozwiązanie problemu wydawania reszty przy pomocy minimalnej liczby monet
        /// z uwzględnieniem ograniczeń na liczbę monet danego rodzaju
        /// </summary>
        /// <param name="amount">Kwota reszty do wydania</param>
        /// <param name="coins">Dostępne nominały monet</param>
        /// <param name="limits">Liczba dostępnych monet danego nomimału</param>
        /// <param name="change">Liczby monet danego nominału użytych przy wydawaniu reszty</param>
        /// <returns>Minimalna liczba monet potrzebnych do wydania reszty</returns>
        /// <remarks>
        /// coins[i]  - nominał monety i-tego rodzaju
        /// limits[i] - dostepna liczba monet i-tego rodzaju (nominału)
        /// change[i] - liczba monet i-tego rodzaju (nominału) użyta w rozwiązaniu
        /// Jeśli dostepnymi monetami nie da się wydać danej kwoty to change = null,
        /// a metoda również zwraca null
        ///
        /// Wskazówka/wymaganie:
        /// Dodatkowa uzyta pamięć powinna (musi) być proporcjonalna do wartości iloczynu amount*(liczba rodzajów monet)
        /// ( czyli rzędu o(amount*(liczba rodzajów monet)) )
        /// </remarks>
        public int? Dynamic(int amount, int[] coins, int[] limits, out int[] change)
        {

            int[,] coinsToGetToThatAmount = new int[coins.Length, amount + 1];
            int[,] coinsUsed = new int[coins.Length, amount + 1];

            for (int coinIndex = 0; coinIndex < coins.Length; coinIndex++)
            {
                for (int currentAmount = 1; currentAmount <= amount; currentAmount++)
                {
                    coinsToGetToThatAmount[coinIndex, currentAmount] = int.MaxValue;

                    if (coinIndex == 0)
                    {
                        if (currentAmount % coins[coinIndex] == 0 && currentAmount / coins[0] <= limits[0])
                        {
                            coinsToGetToThatAmount[coinIndex, currentAmount] = currentAmount / coins[coinIndex];
                            coinsUsed[0, currentAmount] = coinsToGetToThatAmount[coinIndex, currentAmount];
                        }
                    }
                    else
                    {
                        coinsToGetToThatAmount[coinIndex, currentAmount] = coinsToGetToThatAmount[coinIndex - 1, currentAmount];
                        for (int k = 1; k <= limits[coinIndex]; k++)
                        {
                            if (currentAmount - k * coins[coinIndex] >= 0)
                            {
                                int c = k + coinsToGetToThatAmount[coinIndex - 1, currentAmount - k * coins[coinIndex]];

                                if (c > 0 && c < coinsToGetToThatAmount[coinIndex, currentAmount])
                                {
                                    coinsToGetToThatAmount[coinIndex, currentAmount] = c;
                                    coinsUsed[coinIndex, currentAmount] = k;
                                }
                            }
                        }
                    }
                }
            }

            if (coinsToGetToThatAmount[coins.Length - 1, amount] == int.MaxValue)
            {
                change = null;
                return null;
            }

            change = new int[coins.Length];

            int spareAmount = amount;
            for (int i = coins.Length - 1; i >= 0; i--)
            {
                change[i] = coinsUsed[i, spareAmount];
                spareAmount -= coins[i] * coinsUsed[i, spareAmount];
            }

            return coinsToGetToThatAmount[coins.Length - 1, amount];
        }

    }

}
