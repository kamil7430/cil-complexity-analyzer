﻿using System;

namespace ASD
{
    class ChangeMaking
    {
        /// <summary>
        /// Metoda wyznacza rozwiązanie problemu wydawania reszty przy pomocy minimalnej liczby monet
        /// bez ograniczeń na liczbę monet danego rodzaju
        /// </summary>
        /// <param name="amount">Kwota reszty do wydania</param>
        /// <param name="coins">Dostępne nominały monet</param>
        /// <param name="change">Liczby monet danego nominału użytych przy wydawaniu reszty</param>
        /// <returns>Minimalna liczba monet potrzebnych do wydania reszty</returns>
        /// <remarks>
        /// coins[i]  - nominał monety i-tego rodzaju
        /// change[i] - liczba monet i-tego rodzaju (nominału) użyta w rozwiązaniu
        /// Jeśli dostepnymi monetami nie da się wydać danej kwoty to change = null,
        /// a metoda również zwraca null
        ///
        /// Wskazówka/wymaganie:
        /// Dodatkowa uzyta pamięć powinna (musi) być proporcjonalna do wartości amount ( czyli rzędu o(amount) )
        /// </remarks>
        public int? NoLimitsDynamic(int amount, int[] coins, out int[] change)
        {
            change = null!;
            int[] T = new int[amount + 1]; // T[kk] = liczba monet w optylamnym rozwiązaniu dla kwoty kk
            int[] P = new int[amount + 1]; // P[kk] = nominał dodany aby uzyskać optymalną kwotę kk

            const int inf = int.MaxValue - 1;
            T[0] = 0;
            for (int kk = 1; kk <= amount; kk++)
            {
                T[kk] = inf;
                for (int l = 0; l < coins.Length; l++)
                {
                    if (kk - coins[l] < 0) continue;
                    int c = 1 + T[kk - coins[l]];
                    if (c < T[kk])
                    {
                        T[kk] = c;
                        P[kk] = l;
                    }
                }
            }

            if (T[amount] == inf)
            {
                return null;
            }

            int k = amount;
            change = new int[coins.Length];
            while (k > 0)
            {
                change[P[k]]++;
                k -= coins[P[k]];
            }

            return T[amount];
        }

        /// <summary>
        /// Metoda wyznacza rozwiązanie problemu wydawania reszty przy pomocy minimalnej liczby monet
        /// z uwzględnieniem ograniczeń na liczbę monet danego rodzaju
        /// </summary>
        /// <param name="amount">Kwota reszty do wydania</param>
        /// <param name="coins">Dostępne nominały monet</param>
        /// <param name="limits">Liczba dostępnych monet danego nomimału</param>
        /// <param name="change">Liczby monet danego nominału użytych przy wydawaniu reszty</param>
        /// <returns>Minimalna liczba monet potrzebnych do wydania reszty</returns>
        /// <remarks>
        /// coins[i]  - nominał monety i-tego rodzaju
        /// limits[i] - dostepna liczba monet i-tego rodzaju (nominału)
        /// change[i] - liczba monet i-tego rodzaju (nominału) użyta w rozwiązaniu
        /// Jeśli dostepnymi monetami nie da się wydać danej kwoty to change = null,
        /// a metoda również zwraca null
        ///
        /// Wskazówka/wymaganie:
        /// Dodatkowa uzyta pamięć powinna (musi) być proporcjonalna do wartości iloczynu amount*(liczba rodzajów monet)
        /// ( czyli rzędu o(amount*(liczba rodzajów monet)) )
        /// </remarks>
        public int? Dynamic(int amount, int[] coins, int[] limits, out int[] change)
        {
            change = null!;
            const int inf = int.MaxValue - 1;
            // T[i, j] = optymalna liczba monet dla n_1,...,n_i oraz amount=j
            int[,] T = new int[coins.Length, amount + 1];
            // P[i, j] = ile monet o nominale n_i zostało użyte do rozwiązania amount=j *przy pomocy monet n_1,...,n_i*
            int[,] P = new int[coins.Length, amount + 1];

            for (int j = 0; j <= amount; j++)
            {
                T[0, j] = j % coins[0] == 0 && j / coins[0] <= limits[0] ? j / coins[0] : inf;
                P[0, j] = T[0, j] != inf ? T[0, j] : 0;
            }

            for (int l = 1; l < coins.Length; l++)
            {
                for (int k = 1; k <= amount; k++)
                {
                    // nie używamy monet n_l
                    T[l, k] = T[l - 1, k];
                    P[l, k] = 0;

                    // rozważamy użycie i monet n_l
                    for (int i = 1; i <= limits[l]; i++)
                    {
                        if (i * coins[l] <= k && T[l - 1, k - i * coins[l]] != inf &&
                            i + T[l - 1, k - i * coins[l]] < T[l, k])
                        {
                            T[l, k] = i + T[l - 1, k - i * coins[l]];
                            P[l, k] = i;
                        }
                    }
                }
            }

            int result = T[coins.Length - 1, amount];
            if (result == inf)
                return null;

            change = new int[coins.Length];
            int a = amount;
            for (int i = coins.Length - 1; i >= 0; i--)
            {
                change[i] = P[i, a];
                a -= change[i] * coins[i];
            }

            return result;
        }
    }
}