﻿using System;
using ASD.Graphs;
using ASD;
using System.Collections.Generic;
using System.Linq;

namespace ASD
{
    public class Lab15 : System.MarshalByRefObject
    {
        /// <summary>
        /// Etap 1: Rozmiar najliczniejszej krainy w zadanym grafie (2.5p)
        /// 
        /// Przez krainę rozumiemy maksymalny zbiór wierzchołków, z których
        /// każde dwa należą do jakiegoś cyklu (równoważnie: najliczniejszy
        /// zbiór wierzchołków G indukujący podgraf 2-spójny wierzchołkowo).
        /// 
        /// Uwaga: Z powyższej definicji wynika, że zbiór pusty jest krainą, 
        /// a zbiór jednoelementowy nie.
        /// </summary>
        /// <param name="G">Graf prosty</param>
        /// <returns>Rozmiar największej bańki</returns>
        public int MaxProvinceSize(Graph G)
        {
            var n = G.VertexCount;
            var times = new int[n];
            var low = new int[n];

            var S = new Stack<int>();
            var onS = new bool[n];
            var time = 0;
            var maxComp = 0;

            void DFS(int u)
            {
                times[u] = low[u] = ++time;
                S.Push(u);
                onS[u] = true;

                foreach (var v in G.OutNeighbors(u))
                {
                    if (times[v] != 0)
                    {
                        if (onS[v])
                            low[u] = Math.Min(low[u], times[v]);
                        continue;
                    }

                    DFS(v);
                    low[u] = Math.Min(low[u], low[v]);

                    if (low[v] < times[u]) continue;
                    var comp = 0;
                    while (true)
                    {
                        var x = S.Pop();
                        onS[x] = false;
                        comp++;
                        if (x == v || S.Count == 0) break;
                    }

                    comp++; // jeszcze u

                    if (comp >= 3)
                        maxComp = Math.Max(maxComp, comp);
                }
            }

            for (int i = 0; i < n; i++)
                if (times[i] == 0)
                    DFS(i);

            return maxComp;
        }

        /// <summary>
        /// Etap 2: Wierzchołek znajdujący się w największej liczbie krain (2.5p)
        /// 
        /// Funcja zwraca wierzchołek znajdujący się w największej liczbie krain.
        /// 
        /// W przypadku remisu należy zwrócić wierzchołek o mniejszym numerze.
        /// </summary>
        /// <param name="G"></param>
        /// <returns></returns>
        public int VertexInMostProvinces(Graph G)
        {
            var n = G.VertexCount;
            var times = new int[n];
            var low = new int[n];

            var S = new Stack<int>();
            var onS = new bool[n];
            var time = 0;
            var count = new int[n];

            void DFS(int u)
            {
                times[u] = low[u] = ++time;
                S.Push(u);
                onS[u] = true;

                foreach (var v in G.OutNeighbors(u))
                {
                    if (times[v] != 0)
                    {
                        if (onS[v])
                            low[u] = Math.Min(low[u], times[v]);

                        continue;
                    }

                    DFS(v);
                    low[u] = Math.Min(low[u], low[v]);

                    if (low[v] < times[u]) continue;
                    var comp = new List<int>();
                    while (true)
                    {
                        var x = S.Pop();
                        onS[x] = false;
                        comp.Add(x);
                        if (x == v || S.Count == 0) break;
                    }
                    comp.Add(u);

                    if (comp.Count >= 3)
                        foreach (var w in comp)
                            count[w]++;
                }
            }

            for (int i = 0; i < n; i++)
                if (times[i] == 0)
                    DFS(i);

            int bestVertex = 0, bestCount = count[0];
            for (int i = 1; i < n; i++)
            {
                if (count[i] > bestCount)
                {
                    bestCount = count[i];
                    bestVertex = i;
                }
            }

            return bestVertex;
        }
    }
}