﻿using System;
using ASD.Graphs;
using ASD;
using System.Collections.Generic;
using System.Linq;

namespace ASD
{

    public class Lab15 : System.MarshalByRefObject
    {
        /// <summary>
        /// Etap 1: Rozmiar najliczniejszej krainy w zadanym grafie (2.5p)
        /// 
        /// Przez krainę rozumiemy maksymalny zbiór wierzchołków, z których
        /// każde dwa należą do jakiegoś cyklu (równoważnie: najliczniejszy
        /// zbiór wierzchołków G indukujący podgraf 2-spójny wierzchołkowo).
        /// 
        /// Uwaga: Z powyższej definicji wynika, że zbiór pusty jest krainą, 
        /// a zbiór jednoelementowy nie.
        /// </summary>
        /// <param name="G">Graf prosty</param>
        /// <returns>Rozmiar największej bańki</returns>
        public int MaxProvinceSize(Graph G)
        {
            int vertexCount = G.VertexCount;
            int[] discoveryTime = new int[vertexCount];
            int[] lowLink = new int[vertexCount];
            int[] parent = new int[vertexCount];
            List<Edge> currentEdges = new List<Edge>();
            int time = 0;
            int maxProvinceSize = 0;

            for (int i = 0; i < vertexCount; i++)
            {
                discoveryTime[i] = -1;
                lowLink[i] = -1;
                parent[i] = -1;
            }

            for (int vertex = 0; vertex < vertexCount; vertex++)
            {
                if (discoveryTime[vertex] == -1)
                {
                    MyDFS(G, vertex, discoveryTime, lowLink, currentEdges, parent, ref time, ref maxProvinceSize);
                }
            }

            return maxProvinceSize;
        }

        private void MyDFS(Graph G, int root, int[] discoveryTime, int[] lowLink, List<Edge> currentEdges, int[] parent, ref int time, ref int maxProvinceSize)
        {
            discoveryTime[root] = lowLink[root] = ++time;
            int children = 0;

            foreach (int neighbor in G.OutNeighbors(root))
            {
                int v = neighbor;
                if (discoveryTime[v] == -1)
                {
                    children++;
                    parent[v] = root;
                    currentEdges.Add(new Edge(root, v));
                    MyDFS(G, v, discoveryTime, lowLink, currentEdges, parent, ref time, ref maxProvinceSize);
                    lowLink[root] = Math.Min(lowLink[root], lowLink[v]);

                    if (lowLink[v] >= discoveryTime[root])
                    {
                        HashSet<int> currentBccVertices = new HashSet<int>();

                        while (currentEdges.Count > 0)
                        {
                            Edge edge = currentEdges.Last();
                            currentEdges.RemoveAt(currentEdges.Count - 1);

                            currentBccVertices.Add(edge.From);
                            currentBccVertices.Add(edge.To);

                            if (edge.From == root && edge.To == v)
                            {
                                break;
                            }
                        }

                        if (currentBccVertices.Count >= 3)
                        {
                            maxProvinceSize = Math.Max(maxProvinceSize, currentBccVertices.Count);
                        }
                    }
                }
                else if (v != parent[root] && discoveryTime[v] < discoveryTime[root])
                {
                    lowLink[root] = Math.Min(lowLink[root], discoveryTime[v]);
                    currentEdges.Add(new Edge(root, v));
                }
            }
        }

        private int[] _discoveryTimeVIP = Array.Empty<int>(); // VIP = VertexInMostProvinces
        private int[] _lowLinkVIP = Array.Empty<int>();
        private int[] _parentDfsVIP = Array.Empty<int>();
        private List<Edge> _edgeStackVIP = new List<Edge>();
        private int _dfsTimeCounterVIP;
        private int[] _vertexBccMembershipCountsVIP = Array.Empty<int>();

        /// <summary>
        /// Etap 2: Wierzchołek znajdujący się w największej liczbie krain (2.5p)
        /// 
        /// Funcja zwraca wierzchołek znajdujący się w największej liczbie krain.
        /// 
        /// W przypadku remisu należy zwrócić wierzchołek o mniejszym numerze.
        /// </summary>
        /// <param name="G"></param>
        /// <returns></returns>
        public int VertexInMostProvinces(Graph G)
        {
            int vertexCount = G.VertexCount;

            if (vertexCount == 0)
            {
                return 0;
            }

            _discoveryTimeVIP = new int[vertexCount];
            _lowLinkVIP = new int[vertexCount];
            _parentDfsVIP = new int[vertexCount];
            _edgeStackVIP = new List<Edge>();
            _dfsTimeCounterVIP = 0;
            _vertexBccMembershipCountsVIP = new int[vertexCount];

            for (int i = 0; i < vertexCount; i++)
            {
                _discoveryTimeVIP[i] = -1;
                _parentDfsVIP[i] = -1;
            }

            for (int vertex = 0; vertex < vertexCount; vertex++)
            {
                if (_discoveryTimeVIP[vertex] == -1)
                {
                    MyDFS2(G, vertex);
                }
            }

            int mostInterestingVertexId = 0;
            int maxBccsForAVertex = -1;

            mostInterestingVertexId = 0;
            maxBccsForAVertex = _vertexBccMembershipCountsVIP[0];


            for (int i = 0; i < vertexCount; i++)
            {
                if (_vertexBccMembershipCountsVIP[i] > maxBccsForAVertex)
                {
                    maxBccsForAVertex = _vertexBccMembershipCountsVIP[i];
                    mostInterestingVertexId = i;
                }
            }

            return mostInterestingVertexId;
        }

        private void MyDFS2(Graph G, int u)
        {
            _discoveryTimeVIP[u] = _lowLinkVIP[u] = ++_dfsTimeCounterVIP;

            foreach (int neighbor in G.OutNeighbors(u))
            {
                int v = neighbor;

                if (v == _parentDfsVIP[u])
                {
                    continue;
                }

                if (_discoveryTimeVIP[v] != -1)
                {
                    if (_discoveryTimeVIP[v] < _discoveryTimeVIP[u])
                    {
                        _lowLinkVIP[u] = Math.Min(_lowLinkVIP[u], _discoveryTimeVIP[v]);
                        _edgeStackVIP.Add(new Edge(u, v));
                    }
                }
                else
                {
                    _parentDfsVIP[v] = u;
                    _edgeStackVIP.Add(new Edge(u, v));

                    MyDFS2(G, v);

                    _lowLinkVIP[u] = Math.Min(_lowLinkVIP[u], _lowLinkVIP[v]);

                    if (_lowLinkVIP[v] >= _discoveryTimeVIP[u])
                    {
                        HashSet<int> currentBccVerticesSet = new HashSet<int>();

                        while (_edgeStackVIP.Count > 0)
                        {
                            Edge stackEdge = _edgeStackVIP.Last();
                            _edgeStackVIP.RemoveAt(_edgeStackVIP.Count - 1);

                            currentBccVerticesSet.Add(stackEdge.From);
                            currentBccVerticesSet.Add(stackEdge.To);

                            if ((stackEdge.From == u && stackEdge.To == v) ||
                                (stackEdge.From == v && stackEdge.To == u))
                            {
                                break;
                            }
                        }

                        if (currentBccVerticesSet.Count >= 3)
                        {
                            foreach (int vertexInBcc in currentBccVerticesSet)
                            {
                                _vertexBccMembershipCountsVIP[vertexInBcc]++;
                            }
                        }
                    }
                }
            }
        }
    }
}