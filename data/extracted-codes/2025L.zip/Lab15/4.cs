﻿using System;
using ASD.Graphs;
using ASD;
using System.Collections.Generic;
using System.Linq;

namespace ASD
{

    public class Lab15 : System.MarshalByRefObject
    {
        /// <summary>
        /// Etap 1: Rozmiar najliczniejszej krainy w zadanym grafie (2.5p)
        /// 
        /// Przez krainę rozumiemy maksymalny zbiór wierzchołków, z których
        /// każde dwa należą do jakiegoś cyklu (równoważnie: najliczniejszy
        /// zbiór wierzchołków G indukujący podgraf 2-spójny wierzchołkowo).
        /// 
        /// Uwaga: Z powyższej definicji wynika, że zbiór pusty jest krainą, 
        /// a zbiór jednoelementowy nie.
        /// </summary>
        /// <param name="G">Graf prosty</param>
        /// <returns>Rozmiar największej bańki</returns>
        public int MaxProvinceSize(Graph G)
        {
            // Najpierw chciałbym powiedzieć swoją wizję tego zadania. Skoro kraina to maksymalny zbiór wierzchołków, w którym
            // każde dwa wierzchołki u i v mają dwie rozłączne ścieżki ze wspólnymi końcami w u i v, to można powiedzieć, że 
            // kraina - to podgraf wierzchołkowo dwuspójny. Z tego faktu wywnioskowałem, że jeżeli cały graf G nie jest jedną dużą
            // krainą, to istnieją wierzchołki rozcinające w G. Zacząłem się zastanawiać, w jaki sposób będą one wyglądać. Ogólnie 
            // znalazłem 2 możliwe podstawowe pozycje wierzchołków rozcinających:
            // 1)    1   5    - tutaj '3' jest wierzchołkiem rozcinającym, który należy jednocześnie do zbiórów {1, 2, 3}, {3, 4, 5}
            //      / \ / \     oraz {3, 6, 7} - każdy z tych zbiórów jest krainą. Ten przykład opisuje takie sytuacje, w których 
            //     2 - 3 - 4    wierzchołek roczinający należy do dwóch czy więcej krain jednocześnie. Może to być dowolna liczba.
            //        / \
            //       6 - 7
            //
            // 2)   1               8        - tutaj wierzchołki 4 i 5 są wierzchołkami rozcinającymi, które nie należą do żadnych z krain
            //     / \             / \         natomiast wierzchołki 3 oraz 6 są wierzchołkami rozcinającymi, które jednak należą do krain
            //    2 - 3 - 4 - 5 - 6 - 7        {1, 2, 3} oraz {6, 7, 8} odpowiednio.
            //
            // Ogólnie zamiast trójkątów, które tutaj reprezentują krainy, mogą być dowolne podgrafy wierzchołkowo-2-spójne. 
            // Można powiedzieć, że każdy wejściowy graf G jest w pewnym rodzaju "złożeniem" tych dwóch sytuacji. Tutaj chciałbym
            // zdefiniować wierzchołki rozcinające, które należą do pewnej krainy/kilku krain jako "skrajne" albo "graniczne".
            //
            // Główna idea mojego algorytmu jest następująca: buduję drzewo przeszukiwania DFS'owe i zapamiętuje numery porządkowe kolejnych
            // wierzchołków w moim przeszukiwaniu w głąb. Tablica DFSNumber jest, powiedzmy, "stała", tzn. wartość dla każdego wierzchołka
            // z G jest inicjalizowana w pewnym momencie algorytmu i już się nie zmienia. Jeśli wierzchołek z indeksem 2 odwiedziłem przez
            // DFS'a jako 10-y co do kolejności DFS'a, to DFSNumber[2] = 10 itd. Poza tym mam tablicę lowestBacktrack[v], która będzie
            // przechowywała DFSNumber wierzchołka, do którego mogę się cofnąć używająć krawędzi z poddrzewa DFS'owego ukorzenionego w v
            // używając tylko jednej krawędzi "wstecz". Ta tablica już będzie odpowiednio się modyfikować podczas rekurencyjnego DFS'a.
            // Moim zdaniem to właśnie ona jest sercem algorytmu. Zauważmy pewną kluczową własność: dla każdej krainy istnieje dokładnie 
            // jeden wierzchołek, przez który "wchodzimy" do tej krainy. Jest to jej wierzchołek rozcinający i jest on unikalny. To właśnie 
            // on rospójnia krainę od reszty grafu. Oznacza to, że jeśli DFSNumber[v] to numer porządkowy pewnego wierzchołka v,
            // od którego zaczynamy przeszukiwać krainę, to każdy wierzchołek z tej krainy w trakcie wykonywania DFS "wyśle" przez rekurencję
            // wartość lowestBacktrack w górę drzewa DFS, która w końcu "zatrzyma się" na tym wierzchołku v. A więc wszystko co pozostaje 
            // nam zrobić - to właśnie wyłapać moment, kiedy rekurencja wróci do dziecka v w drzewie przeszukiwania (ozn. u). Wtedy na Stacku
            // który przechowuje krawędzie, będziemy mieli wszystkie krawędzie z bieżącej krainy. Wtedy "pauzuję" DFS'a na moment, zdejmuję
            // wszystkie krawędzie dotyczące tej krainy i dzięki tej informacji zdobywam rozmiar tej krainy. Uaktualniam odpowiedź globalną,
            // jeżeli jest na to potrzeba. Potem kontynuuję DFS'a aż do jego końca. 

            int n = G.VertexCount;
            int currentNumber = 1;
            int answer = 0;
            int[] DFSNumber = new int[n];
            int[] lowestBacktrack = new int[n];
            Stack<Edge> edgeStack = new Stack<Edge>();
            for (int i = 0; i < n; i++)
            {
                DFSNumber[i] = 0;
                lowestBacktrack[i] = 0;
            }

            void DFS (int rootVertex, int parent)
            {
                DFSNumber[rootVertex] = currentNumber;

                // Na początku ta wartość jest ustalona na rodzica, bo wiemy, że do rodzica na pewno da się wrócić.
                lowestBacktrack[rootVertex] = (parent == -1) ? currentNumber : DFSNumber[parent];
                currentNumber++;

                foreach (int neighbor in G.OutNeighbors(rootVertex))
                {
                    if (neighbor == parent) // Nie cofam się do swojego rodzica w ścieżce przeszukiwania DFS'a.
                        continue;
                    
                    if (DFSNumber[neighbor] == 0) // Jeśli sąsiad jeszcze nie został odwiedzony, to go odwiedzam: dodaję krawędź do Stacku
                        // i odpalam DFS'a dla sąsiada.
                    {
                        edgeStack.Push(new Edge(rootVertex, neighbor));
                        DFS(neighbor, rootVertex);

                        // Skończyłem przeszukiwać sąsiada. Teraz jeśli wiem, że od sąsiada mam możliwość cofnąć się wcześniej, niż 
                        // od siebie dotychczas, to i ja też mogę tam się cofnąć. Np. jeśli ja jestem '4', mój sąsiad - '5', sąsiad ma 
                        // krawędź "wstecz" do '2', to wtedy lowestBacktrack[5] = 2. Ale wtedy i od '4' mam możliwość cofnąć się do '2' -
                        // '4' -> '5' -> '2'. A więc uaktualniam - lowestBacktrack[4] = 2.
                        lowestBacktrack[rootVertex] = Math.Min(lowestBacktrack[rootVertex], lowestBacktrack[neighbor]);

                        // Tutaj właśnie sprawdzam warunek, o którym mówiłem na początku. Jeśli rekurencja wróciła do dziecka wierzchołka
                        // rozcinającego, czyli jeśli z całego poddrzewa o korzeniu neighbor nie da się cofnąć wcześniej niż do rootVertex,
                        // czyli do rodzica neighbor, to możemy stwierdzić, że mamy do czynienia z punktem wejściowym do krainy. 
                        // rootVertex jest jej wierzchołkiem "skrajnym", a krawędź rootVertex-neighbor jest pierwsza, którą dodaliśmy do
                        // Stacka. A więc zdejmujemy wszystkie krawędzie z tego Stacka aż do pierwszej (rootVertex-neighbor). Odbieramy
                        // potrzebną informację i kończymy zabawę z tą krainą na zawsze.
                        if (lowestBacktrack[neighbor] >= DFSNumber[rootVertex])
                        {
                            int edgeCount = 0;
                            HashSet<int> newPotentialMaxProvince = new HashSet<int>();
                            Edge stackEdge = edgeStack.Pop();
                            while (!(stackEdge.From == rootVertex && stackEdge.To == neighbor))
                            {
                                newPotentialMaxProvince.Add(stackEdge.From);
                                newPotentialMaxProvince.Add(stackEdge.To);
                                edgeCount++;
                                stackEdge = edgeStack.Pop();
                            }

                            newPotentialMaxProvince.Add(rootVertex);
                            newPotentialMaxProvince.Add(neighbor);
                            edgeCount++;

                            if (edgeCount >= newPotentialMaxProvince.Count)
                                answer = Math.Max(answer, newPotentialMaxProvince.Count);
                        }
                    }
                    else if (DFSNumber[neighbor] < DFSNumber[rootVertex]) // Jeśli sąsiad już został odwiedzony przez DFS'a wcześniej, to
                        // jedynie muszę sprawdzić, czy mogę jeszcze zmniejszyć wartość lowestBacktrack przez niego. No i oczywiście dodaję
                        // tą krawędź do Stacka.
                    {
                        edgeStack.Push(new Edge(rootVertex, neighbor));
                        lowestBacktrack[rootVertex] = Math.Min(DFSNumber[neighbor], lowestBacktrack[rootVertex]);
                    }
                }
            }

            // Tutaj wywołuję napisanego DFS'a. Robię to na każdej spójnej składowej.
            for (int vertex = 0; vertex < n; vertex++)
            {
                if (DFSNumber[vertex] == 0)
                    DFS(vertex, -1);
            }

            return answer;
        }


        /// <summary>
        /// Etap 2: Wierzchołek znajdujący się w największej liczbie krain (2.5p)
        /// 
        /// Funcja zwraca wierzchołek znajdujący się w największej liczbie krain.
        /// 
        /// W przypadku remisu należy zwrócić wierzchołek o mniejszym numerze.
        /// </summary>
        /// <param name="G"></param>
        /// <returns></returns>
        public int VertexInMostProvinces(Graph G)
        {
            // Rozwiązanie drugiego etapu jest już bardzo proste, jak mam rozwiązanie pierwszego. Po zdobyciu informacji o jakiejkolwiek
            // krainie mam zwiększyć licznik wystąpień każdego wierzchołka tej krainy o jeden. Na końcu wystarczy zwrócić ten z największym
            // licznikiem i koniec. 

            int n = G.VertexCount;
            int currentNumber = 1;
            int answer = 0;
            int[] DFSNumber = new int[n];
            int[] lowestBacktrack = new int[n];
            int[] numberOfProvinces = new int[n];
            Stack<Edge> edgeStack = new Stack<Edge>();
            for (int i = 0; i < n; i++)
            {
                DFSNumber[i] = 0;
                lowestBacktrack[i] = 0;
                numberOfProvinces[i] = 0;
            }

            void DFS(int rootVertex, int parent)
            {
                DFSNumber[rootVertex] = currentNumber;
                lowestBacktrack[rootVertex] = (parent == -1) ? currentNumber : DFSNumber[parent];
                currentNumber++;

                foreach (int neighbor in G.OutNeighbors(rootVertex))
                {
                    if (neighbor == parent)
                        continue;

                    if (DFSNumber[neighbor] == 0)
                    {
                        edgeStack.Push(new Edge(rootVertex, neighbor));
                        DFS(neighbor, rootVertex);

                        lowestBacktrack[rootVertex] = Math.Min(lowestBacktrack[rootVertex], lowestBacktrack[neighbor]);

                        if (lowestBacktrack[neighbor] >= DFSNumber[rootVertex])
                        {
                            int edgeCount = 0;
                            HashSet<int> newPotentialMaxProvince = new HashSet<int>();
                            Edge stackEdge = edgeStack.Pop();
                            while (!(stackEdge.From == rootVertex && stackEdge.To == neighbor))
                            {
                                newPotentialMaxProvince.Add(stackEdge.From);
                                newPotentialMaxProvince.Add(stackEdge.To);
                                edgeCount++;
                                stackEdge = edgeStack.Pop();
                            }

                            newPotentialMaxProvince.Add(rootVertex);
                            newPotentialMaxProvince.Add(neighbor);
                            edgeCount++;

                            if (edgeCount >= newPotentialMaxProvince.Count)
                            {
                                foreach (int provinceVertex in newPotentialMaxProvince)
                                {
                                    numberOfProvinces[provinceVertex]++;
                                }
                            }
                        }
                    }
                    else if (DFSNumber[neighbor] < DFSNumber[rootVertex])
                    {
                        edgeStack.Push(new Edge(rootVertex, neighbor));
                        lowestBacktrack[rootVertex] = Math.Min(DFSNumber[neighbor], lowestBacktrack[rootVertex]);
                    }
                }
            }

            for (int vertex = 0; vertex < n; vertex++)
            {
                if (DFSNumber[vertex] == 0)
                    DFS(vertex, -1);
            }

            int currentMaxProvinces = 0;
            for (int i = 0; i < n; i++)
            {
                if (numberOfProvinces[i] > currentMaxProvinces)
                {
                    answer = i;
                    currentMaxProvinces = numberOfProvinces[i];
                }
            }

            return answer;
        }
    }
}