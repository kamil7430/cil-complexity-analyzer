﻿using System;
using ASD.Graphs;
using ASD;
using System.Collections.Generic;
using System.Reflection.Metadata.Ecma335;

namespace ASD
{

    public class Lab03GraphFunctions : System.MarshalByRefObject
    {

        // Część 1
        // Wyznaczanie odwrotności grafu
        //   0.5 pkt
        // Odwrotność grafu to graf skierowany o wszystkich krawędziach przeciwnie skierowanych niż w grafie pierwotnym
        // Parametry:
        //   g - graf wejściowy
        // Wynik:
        //   odwrotność grafu
        // Uwagi:
        //   1) Graf wejściowy pozostaje niezmieniony
        //   2) Graf wynikowy musi być w takiej samej reprezentacji jak wejściowy
        public DiGraph Lab03Reverse(DiGraph g)
        {
            DiGraph newG = new DiGraph(g.VertexCount, g.Representation);

            foreach (Edge e in g.DFS().SearchAll())
            {
                newG.AddEdge(e.To, e.From);
            }
            return newG;
        }

        // Część 2
        // Badanie czy graf jest dwudzielny
        //   0.5 pkt
        // Graf dwudzielny to graf nieskierowany, którego wierzchołki można podzielić na dwa rozłączne zbiory
        // takie, że dla każdej krawędzi jej końce należą do róźnych zbiorów
        // Parametry:
        //   g - badany graf
        //   vert - tablica opisująca podział zbioru wierzchołków na podzbiory w następujący sposób
        //          vert[i] == 1 oznacza, że wierzchołek i należy do pierwszego podzbioru
        //          vert[i] == 2 oznacza, że wierzchołek i należy do drugiego podzbioru
        // Wynik:
        //   true jeśli graf jest dwudzielny, false jeśli graf nie jest dwudzielny (w tym przypadku parametr vert ma mieć wartość null)
        // Uwagi:
        //   1) Graf wejściowy pozostaje niezmieniony
        //   2) Podział wierzchołków może nie być jednoznaczny - znaleźć dowolny
        //   3) Pamiętać, że każdy z wierzchołków musi być przyporządkowany do któregoś ze zbiorów
        //   4) Metoda ma mieć taki sam rząd złożoności jak zwykłe przeszukiwanie (za większą będą kary!)
        public bool Lab03IsBipartite(Graph g, out int[] vert)
        {
            int[] color = new int[g.VertexCount];
            foreach (Edge e in g.DFS().SearchAll())
            {
                if (color[e.From] == 0) // nowa składowa
                {
                    color[e.From] = 1;
                }
                if (color[e.To] == 0) // nowy wierzchołek
                {
                    color[e.To] = 3 - color[e.From];
                }
                if (color[e.From] == color[e.To])
                {
                    vert = null;
                    return false;
                }
            }
            for (int i = 0; i < g.VertexCount; i++)
            {
                if (color[i] == 0)
                    color[i] = 1;
            }
            vert = color;
            return true;
        }

        // Część 3
        // Wyznaczanie minimalnego drzewa rozpinającego algorytmem Kruskala
        //   1 pkt
        // Schemat algorytmu Kruskala
        //   1) wrzucić wszystkie krawędzie do "wspólnego worka"
        //   2) wyciągać z "worka" krawędzie w kolejności wzrastających wag
        //      - jeśli krawędź można dodać do drzewa to dodawać, jeśli nie można to ignorować
        //      - punkt 2 powtarzać aż do skonstruowania drzewa (lub wyczerpania krawędzi)
        // Parametry:
        //   g - graf wejściowy
        //   mstw - waga skonstruowanego drzewa (lasu)
        // Wynik:
        //   skonstruowane minimalne drzewo rozpinające (albo las)
        // Uwagi:
        //   1) Graf wejściowy pozostaje niezmieniony
        //   2) Wykorzystać klasę UnionFind z biblioteki Graph
        //   3) Jeśli graf g jest niespójny to metoda wyznacza las rozpinający
        //   4) Graf wynikowy (drzewo) musi być w takiej samej reprezentacji jak wejściowy
        public Graph<int> Lab03Kruskal(Graph<int> g, out int mstw)
        {
            SafePriorityQueue<int, Edge<int>> queue = new SafePriorityQueue<int, Edge<int>>();
            
            foreach (Edge<int> e in g.DFS<int>().SearchAll())
            {
                queue.Insert(e, e.Weight);
            }

            UnionFind unionFind = new UnionFind(g.VertexCount);
            Graph<int> mst = new Graph<int>(g.VertexCount, g.Representation);

            mstw = 0;
            while (queue.Count > 0)
            {
                Edge<int> e = queue.Extract();
                if (unionFind.Find(e.From) != unionFind.Find(e.To))
                {
                    unionFind.Union(e.From, e.To);
                    mstw += e.Weight;
                    mst.AddEdge(e.From, e.To, e.Weight);
                }
            }
            return mst;
        }

        // Część 4
        // Badanie czy graf nieskierowany jest acykliczny
        //   0.5 pkt
        // Parametry:
        //   g - badany graf
        // Wynik:
        //   true jeśli graf jest acykliczny, false jeśli graf nie jest acykliczny
        // Uwagi:
        //   1) Graf wejściowy pozostaje niezmieniony
        //   2) Najpierw pomysleć jaki, prosty do sprawdzenia, warunek spełnia acykliczny graf nieskierowany
        //      Zakodowanie tego sprawdzenia nie powinno zająć więcej niż kilka linii!
        //      Zadanie jest bardzo łatwe (jeśli wydaje się trudne - poszukać prostszego sposobu, a nie walczyć z trudnym!)
        public bool Lab03IsUndirectedAcyclic(Graph g)
        {
            int cc = 0;
            int m = 0;
            int n = g.VertexCount;
            bool[] visited = new bool[n];

            for (int i = 0; i < n; i++)
            {
                if (visited[i])
                    continue;

                visited[i] = true;
                cc++;
                foreach (Edge e in g.DFS().SearchFrom(i))
                {
                    m++;
                    visited[e.To] = true;
                }
            }
            return m / 2 == n - cc;
        }

    }

}
