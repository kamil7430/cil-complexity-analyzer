﻿using System;
using ASD.Graphs;
using ASD;
using System.Collections.Generic;

namespace ASD
{

    public class Lab03GraphFunctions : System.MarshalByRefObject
    {

        // Część 1
        // Wyznaczanie odwrotności grafu
        //   0.5 pkt
        // Odwrotność grafu to graf skierowany o wszystkich krawędziach przeciwnie skierowanych niż w grafie pierwotnym
        // Parametry:
        //   g - graf wejściowy
        // Wynik:
        //   odwrotność grafu
        // Uwagi:
        //   1) Graf wejściowy pozostaje niezmieniony
        //   2) Graf wynikowy musi być w takiej samej reprezentacji jak wejściowy
        public DiGraph Lab03Reverse(DiGraph g)
        {
            DiGraph ret = new DiGraph(g.VertexCount, g.Representation);

            foreach (Edge e in g.BFS().SearchAll())
            {
                ret.AddEdge(e.To, e.From);
            }

            return ret;
        }

        // Część 2
        // Badanie czy graf jest dwudzielny
        //   0.5 pkt
        // Graf dwudzielny to graf nieskierowany, którego wierzchołki można podzielić na dwa rozłączne zbiory
        // takie, że dla każdej krawędzi jej końce należą do róźnych zbiorów
        // Parametry:
        //   g - badany graf
        //   vert - tablica opisująca podział zbioru wierzchołków na podzbiory w następujący sposób
        //          vert[i] == 1 oznacza, że wierzchołek i należy do pierwszego podzbioru
        //          vert[i] == 2 oznacza, że wierzchołek i należy do drugiego podzbioru
        // Wynik:
        //   true jeśli graf jest dwudzielny, false jeśli graf nie jest dwudzielny (w tym przypadku parametr vert ma mieć wartość null)
        // Uwagi:
        //   1) Graf wejściowy pozostaje niezmieniony
        //   2) Podział wierzchołków może nie być jednoznaczny - znaleźć dowolny
        //   3) Pamiętać, że każdy z wierzchołków musi być przyporządkowany do któregoś ze zbiorów
        //   4) Metoda ma mieć taki sam rząd złożoności jak zwykłe przeszukiwanie (za większą będą kary!)
        public bool Lab03IsBipartite(Graph g, out int[] vert)
        {
            int[] color = new int[g.VertexCount]; // 0 - brak koloru, 1 - kolor pierwszy, 2 - kolor drugi
            foreach (Edge e in g.DFS().SearchAll())
            {
                if (color[e.From] == 0)
                {
                    color[e.From] = 1;
                }

                if (color[e.To] == 0)
                {
                    color[e.To] = 3 - color[e.From];
                }

                if (color[e.From] == color[e.To])
                {
                    vert = null;
                    return false;
                }
            }

            // Dla wierzchołków bez krawędzi
            for (int i = 0; i < g.VertexCount; i++)
            {
                if (color[i] == 0) color[i] = 1;
            }

            vert = color;
            return true;
        }

        // Część 3
        // Wyznaczanie minimalnego drzewa rozpinającego algorytmem Kruskala
        //   1 pkt
        // Schemat algorytmu Kruskala
        //   1) wrzucić wszystkie krawędzie do "wspólnego worka"
        //   2) wyciągać z "worka" krawędzie w kolejności wzrastających wag
        //      - jeśli krawędź można dodać do drzewa to dodawać, jeśli nie można to ignorować
        //      - punkt 2 powtarzać aż do skonstruowania drzewa (lub wyczerpania krawędzi)
        // Parametry:
        //   g - graf wejściowy
        //   mstw - waga skonstruowanego drzewa (lasu)
        // Wynik:
        //   skonstruowane minimalne drzewo rozpinające (albo las)
        // Uwagi:
        //   1) Graf wejściowy pozostaje niezmieniony
        //   2) Wykorzystać klasę UnionFind z biblioteki Graph
        //   3) Jeśli graf g jest niespójny to metoda wyznacza las rozpinający
        //   4) Graf wynikowy (drzewo) musi być w takiej samej reprezentacji jak wejściowy
        public Graph<int> Lab03Kruskal(Graph<int> g, out int mstw)
        {
            UnionFind unionFind = new UnionFind(g.VertexCount);
            Dictionary<(int from, int to), int> edges = new Dictionary<(int, int), int>();

            bool[] visited = new bool[g.VertexCount];
            int cc = 0;

            for (int i = 0; i < g.VertexCount; i++)
            {
                if (visited[i]) continue;

                visited[i] = true;
                cc++;
                foreach (Edge<int> e in g.DFS().SearchFrom(i))
                {
                    visited[e.To] = true;
                }
            }

            foreach (Edge<int> e in g.DFS().SearchAll())
            {
                if (edges.ContainsKey((e.From, e.To)) || edges.ContainsKey((e.To, e.From)))
                    continue;

                else
                {
                    edges.Add((e.To, e.From), e.Weight);
                }
            }

            var sortedEdges = edges.OrderBy(edge => edge.Value)
                .ToDictionary(edge => edge.Key, edge => edge.Value);

            Graph<int> tree = new Graph<int>(g.VertexCount, g.Representation);
            mstw = 0;
            int edgesAdded = 0;
            
            foreach (var e in sortedEdges)
            {
                if (unionFind.Find(e.Key.from) != unionFind.Find(e.Key.to))
                {
                    tree.AddEdge(e.Key.from, e.Key.to);
                    unionFind.Union(e.Key.from, e.Key.to);
                    mstw += e.Value;
                    edgesAdded++;

                    if (edgesAdded == g.VertexCount - cc)
                        break;
                }

                else continue;
            }

            if (edgesAdded == g.VertexCount - cc)
                return tree;
            else return null;

            // Poniższe rozwiązanie teroretycznie jest poprawne, jednak jest zbyt wolne, dlatego pozostało zakomentowane
            /*
            Dictionary<(int, int), int> edges = new Dictionary<(int, int), int>();
            foreach (Edge<int> e in g.DFS().SearchAll())
            {
                if (edges.ContainsKey((e.From, e.To)) || edges.ContainsKey((e.To, e.From)))
                    continue;

                else
                {
                    edges.Add((e.To, e.From), e.Weight);
                }
            }

            var sortedEdges = edges.OrderBy(edge => edge.Value)
                .ToDictionary(edge => edge.Key, edge => edge.Value);

            Graph<int> tree = new Graph<int>(g.VertexCount, g.Representation);
            mstw = 0;
            bool[] spanned = new bool[g.VertexCount];
            bool success = false;
            

            while (true)
            {
                if (sortedEdges.Count == 0)
                {
                    success = false;
                    break;                 
                }

                if (spanned.All(lambda => lambda == true) && tree.EdgeCount == tree.VertexCount - 1)
                {
                    success = true;
                    break;
                }

                else
                {
                    int from = sortedEdges.ElementAt(0).Key.Item1;
                    int to = sortedEdges.ElementAt(0).Key.Item2;
                    int weight = sortedEdges.ElementAt(0).Value;

                    sortedEdges.Remove(sortedEdges.ElementAt(0).Key);

                    tree.AddEdge(from, to);
                    if (!Lab03IsUndirectedAcyclic(tree))
                    {
                        tree.RemoveEdge(from, to);
                        continue;
                    }
                    else
                    {
                        mstw += weight;
                        spanned[from] = true;
                        spanned[to] = true;
                        continue;
                    }
                }     
            }
            if (success) return tree;
            else return null;
            */
        }

        // Część 4
        // Badanie czy graf nieskierowany jest acykliczny
        //   0.5 pkt
        // Parametry:
        //   g - badany graf
        // Wynik:
        //   true jeśli graf jest acykliczny, false jeśli graf nie jest acykliczny
        // Uwagi:
        //   1) Graf wejściowy pozostaje niezmieniony
        //   2) Najpierw pomysleć jaki, prosty do sprawdzenia, warunek spełnia acykliczny graf nieskierowany
        //      Zakodowanie tego sprawdzenia nie powinno zająć więcej niż kilka linii!
        //      Zadanie jest bardzo łatwe (jeśli wydaje się trudne - poszukać prostszego sposobu, a nie walczyć z trudnym!)
        public bool Lab03IsUndirectedAcyclic(Graph g)
        {
            int cc = 0;
            int n = g.VertexCount;
            int m = g.EdgeCount;
            bool[] visited = new bool[g.VertexCount];

            for (int i = 0; i < n; i++)
            {
                if (visited[i]) continue;

                visited[i] = true;
                cc++;
                foreach (Edge e in g.DFS().SearchFrom(i))
                {
                    visited[e.To] = true;
                }   
            }

            return m == n - cc;
        }

    }

}
