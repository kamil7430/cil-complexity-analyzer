﻿using System;
using ASD.Graphs;
using ASD;
using System.Collections.Generic;

namespace ASD
{
    public class Lab03GraphFunctions : System.MarshalByRefObject
    {
        // Część 1
        // Wyznaczanie odwrotności grafu
        //   0.5 pkt
        // Odwrotność grafu to graf skierowany o wszystkich krawędziach przeciwnie skierowanych niż w grafie pierwotnym
        // Parametry:
        //   g - graf wejściowy
        // Wynik:
        //   odwrotność grafu
        // Uwagi:
        //   1) Graf wejściowy pozostaje niezmieniony
        //   2) Graf wynikowy musi być w takiej samej reprezentacji jak wejściowy
        public DiGraph Lab03Reverse(DiGraph g)
        {
            var h = new DiGraph(g.VertexCount, g.Representation);
            for (var v = 0; v < g.VertexCount; v++)
            {
                foreach (var u in g.OutNeighbors(v))
                {
                    h.AddEdge(u, v);
                }
            }

            return h;
        }

        // Część 2
        // Badanie czy graf jest dwudzielny
        //   0.5 pkt
        // Graf dwudzielny to graf nieskierowany, którego wierzchołki można podzielić na dwa rozłączne zbiory
        // takie, że dla każdej krawędzi jej końce należą do róźnych zbiorów
        // Parametry:
        //   g - badany graf
        //   vert - tablica opisująca podział zbioru wierzchołków na podzbiory w następujący sposób
        //          vert[i] == 1 oznacza, że wierzchołek i należy do pierwszego podzbioru
        //          vert[i] == 2 oznacza, że wierzchołek i należy do drugiego podzbioru
        // Wynik:
        //   true jeśli graf jest dwudzielny, false jeśli graf nie jest dwudzielny (w tym przypadku parametr vert ma mieć wartość null)
        // Uwagi:
        //   1) Graf wejściowy pozostaje niezmieniony
        //   2) Podział wierzchołków może nie być jednoznaczny - znaleźć dowolny
        //   3) Pamiętać, że każdy z wierzchołków musi być przyporządkowany do któregoś ze zbiorów
        //   4) Metoda ma mieć taki sam rząd złożoności jak zwykłe przeszukiwanie (za większą będą kary!)
        public bool Lab03IsBipartite(Graph g, out int[] vert)
        {
            vert = new int[g.VertexCount];
            var q = new Queue<int>();

            for (var s = 0; s < g.VertexCount; s++)
            {
                if (vert[s] != 0) continue;

                var color = 1;
                vert[s] = color;
                q.Enqueue(s);

                while (q.Count > 0)
                {
                    var v = q.Dequeue();
                    color = vert[v] == 1 ? 2 : 1;

                    foreach (var u in g.OutNeighbors(v))
                    {
                        if (vert[u] != 0)
                        {
                            if (vert[u] != color)
                            {
                                vert = null!;
                                return false;
                            }

                            continue;
                        }

                        vert[u] = color;
                        q.Enqueue(u);
                    }
                }
            }

            return true;
        }

        // Część 3
        // Wyznaczanie minimalnego drzewa rozpinającego algorytmem Kruskala
        //   1 pkt
        // Schemat algorytmu Kruskala
        //   1) wrzucić wszystkie krawędzie do "wspólnego worka"
        //   2) wyciągać z "worka" krawędzie w kolejności wzrastających wag
        //      - jeśli krawędź można dodać do drzewa to dodawać, jeśli nie można to ignorować
        //      - punkt 2 powtarzać aż do skonstruowania drzewa (lub wyczerpania krawędzi)
        // Parametry:
        //   g - graf wejściowy
        //   mstw - waga skonstruowanego drzewa (lasu)
        // Wynik:
        //   skonstruowane minimalne drzewo rozpinające (albo las)
        // Uwagi:
        //   1) Graf wejściowy pozostaje niezmieniony
        //   2) Wykorzystać klasę UnionFind z biblioteki Graph
        //   3) Jeśli graf g jest niespójny to metoda wyznacza las rozpinający
        //   4) Graf wynikowy (drzewo) musi być w takiej samej reprezentacji jak wejściowy
        public Graph<int> Lab03Kruskal(Graph<int> g, out int mstw)
        {
            mstw = 0;
            var pq = new PriorityQueue<int, Edge<int>>();
            var uf = new UnionFind(g.VertexCount);
            var t = new Graph<int>(g.VertexCount, g.Representation);
            
            for (var v = 0; v < g.VertexCount; v++)
            {
                foreach (var e in g.OutEdges(v))
                    pq.Insert(e, e.Weight);
            }

            while (pq.Count > 0)
            {
                var e = pq.Extract();
                if (uf.Find(e.From) == uf.Find(e.To)) continue;
                uf.Union(e.From, e.To);
                t.AddEdge(e.From, e.To, e.Weight);
                mstw += e.Weight;
            }

            return t;
        }

        // Część 4
        // Badanie czy graf nieskierowany jest acykliczny
        //   0.5 pkt
        // Parametry:
        //   g - badany graf
        // Wynik:
        //   true jeśli graf jest acykliczny, false jeśli graf nie jest acykliczny
        // Uwagi:
        //   1) Graf wejściowy pozostaje niezmieniony
        //   2) Najpierw pomysleć jaki, prosty do sprawdzenia, warunek spełnia acykliczny graf nieskierowany
        //      Zakodowanie tego sprawdzenia nie powinno zająć więcej niż kilka linii!
        //      Zadanie jest bardzo łatwe (jeśli wydaje się trudne - poszukać prostszego sposobu, a nie walczyć z trudnym!)
        public bool Lab03IsUndirectedAcyclic(Graph g)
        {
            var vis = new bool[g.VertexCount];
            var cc = 0;
            var st = new Stack<int>();
            for (var s = 0; s < g.VertexCount; s++)
            {
                if (vis[s]) continue;
                cc++;
                vis[s] = true;
                st.Push(s);

                while (st.Count > 0)
                {
                    var v = st.Pop();
                    foreach (var u in g.OutNeighbors(v))
                    {
                        if (vis[u]) continue;
                        vis[u] = true;
                        st.Push(u);
                    }
                }
            }

            return g.EdgeCount == g.VertexCount - cc;
        }
    }
}