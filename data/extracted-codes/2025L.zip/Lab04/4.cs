﻿using ASD.Graphs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASD
{
    public class Lab04 : MarshalByRefObject
    {
        /// <summary>
        /// Etap 1 - Wyznaczenie liczby oraz listy zainfekowanych serwisów po upływie K dni.
        /// Algorytm analizuje propagację infekcji w grafie i zwraca wszystkie dotknięte nią serwisy.
        /// </summary>
        /// <param name="G">Graf reprezentujący infrastrukturę serwisów.</param>
        /// <param name="K">Liczba dni propagacji infekcji.</param>
        /// <param name="s">Indeks początkowo zainfekowanego serwisu.</param>
        /// <returns>
        /// (int numberOfInfectedServices, int[] listOfInfectedServices) - 
        /// numberOfInfectedServices: liczba zainfekowanych serwisów,
        /// listOfInfectedServices: tablica zawierająca numery zainfekowanych serwisów w kolejności rosnącej.
        /// </returns>
        public (int numberOfInfectedServices, int[] listOfInfectedServices) Stage1(Graph G, int K, int s)
        {
            int n = G.VertexCount;
            int m = G.EdgeCount;

            bool[] infected = new bool[n];

            infected[s] = true;
            Queue<(int vertex, int day)> queue = new Queue<(int vertex, int day)>();

            queue.Enqueue((s, 1));

            while (queue.Count > 0)
            {
                (int currentVertex, int currentDay) = queue.Dequeue();

                if (currentDay < K)
                {
                    foreach (int neighbour in G.OutNeighbors(currentVertex))
                    {
                        if (!infected[neighbour])
                        {
                            infected[neighbour] = true;
                            queue.Enqueue((neighbour, currentDay + 1));
                        }
                    }
                }
            }

            int count = 0;
            for (int i = 0; i < n; i++)
            {
                if (infected[i]) count++;
            }

            int[] listOfInfectedServices = new int[count];

            int index = 0;
            for (int i = 0; i < n; i++)
            {
                if (infected[i])
                {
                    listOfInfectedServices[index] = i;
                    index++;
                }
            }

            return (count, listOfInfectedServices);
        }

        /// <summary>
        /// Etap 2 - Wyznaczenie liczby oraz listy zainfekowanych serwisów przy uwzględnieniu wyłączeń.
        /// Algorytm analizuje propagację infekcji z możliwością wcześniejszego wyłączania serwisów.
        /// </summary>
        /// <param name="G">Graf reprezentujący infrastrukturę serwisów.</param>
        /// <param name="K">Liczba dni propagacji infekcji.</param>
        /// <param name="s">Tablica początkowo zainfekowanych serwisów.</param>
        /// <param name="serviceTurnoffDay">Tablica zawierająca dzień, w którym dany serwis został wyłączony (K + 1 oznacza brak wyłączenia).</param>
        /// <returns>
        /// (int numberOfInfectedServices, int[] listOfInfectedServices) - 
        /// numberOfInfectedServices: liczba zainfekowanych serwisów,
        /// listOfInfectedServices: tablica zawierająca numery zainfekowanych serwisów w kolejności rosnącej.
        /// </returns>
        public (int numberOfInfectedServices, int[] listOfInfectedServices) Stage2(Graph G, int K, int[] s, int[] serviceTurnoffDay)
        {
            int n = G.VertexCount;
            int m = G.EdgeCount;
            int p = s.Length;

            bool[] infected = new bool[n];
            Queue<(int vertex, int day)> queue = new Queue<(int vertex, int day)>();
            foreach (int startVertex in s)
            {
                infected[startVertex] = true;
                queue.Enqueue((startVertex, 1));
            }

            while (queue.Count > 0)
            {
                (int currentVertex, int currentDay) = queue.Dequeue();

                if (currentDay < K && serviceTurnoffDay[currentVertex] > (currentDay + 1))
                {

                    foreach (int neighbor in G.OutNeighbors(currentVertex))
                    {
                        if (!infected[neighbor] && serviceTurnoffDay[neighbor] > (currentDay + 1))
                        {
                            infected[neighbor] = true;
                            queue.Enqueue((neighbor, currentDay + 1));
                        }
                    }
                }
            }

            int count = 0;
            for (int i = 0; i < n; i++)
            {
                if (infected[i]) count++;
            }

            int[] listOfInfectedServices = new int[count];

            int index = 0;
            for (int i = 0; i < n; i++)
            {
                if (infected[i])
                {
                    listOfInfectedServices[index] = i;
                    index++;
                }
            }

            return (count, listOfInfectedServices);
        }

        /// <summary>
        /// Etap 3 - Wyznaczenie liczby oraz listy zainfekowanych serwisów z możliwością ponownego włączenia wyłączonych serwisów.
        /// Algorytm analizuje propagację infekcji uwzględniając serwisy, które mogą być ponownie uruchamiane po określonym czasie.
        /// </summary>
        /// <param name="G">Graf reprezentujący infrastrukturę serwisów.</param>
        /// <param name="K">Liczba dni propagacji infekcji.</param>
        /// <param name="s">Tablica początkowo zainfekowanych serwisów.</param>
        /// <param name="serviceTurnoffDay">Tablica zawierająca dzień, w którym dany serwis został wyłączony (K + 1 oznacza brak wyłączenia).</param>
        /// <param name="serviceTurnonDay">Tablica zawierająca dzień, w którym dany serwis został ponownie włączony.</param>
        /// <returns>
        /// (int numberOfInfectedServices, int[] listOfInfectedServices) - 
        /// numberOfInfectedServices: liczba zainfekowanych serwisów,
        /// listOfInfectedServices: tablica zawierająca numery zainfekowanych serwisów w kolejności rosnącej.
        /// </returns>
        public (int numberOfInfectedServices, int[] listOfInfectedServices) Stage3(Graph G, int K, int[] s, int[] serviceTurnoffDay, int[] serviceTurnonDay)
        {
            int n = G.VertexCount;
            int m = G.EdgeCount;
            int r = s.Length;

            // Idea rozwiązania jest następująca: robię tablicę kolejek. Do i-tej kolejki trafia wierzchołek, który 
            // zostanie zainfekowany przez swojego pewnego sąsiada w i-tym dniu. Zupełnie to nie oznacza, że nie może 
            // zostać zainfekowany wcześniej w jakiś inny sposób (np. przez jakichś innych swoich sąsiadów), ale na
            // razie to nie psuje rozwiązania. 
            // Na początku do pierwszej kolejki (days[1]) wrzucam wszystkie wierzchołki, które początkowo zostały
            // zainfekowane. Główna pętla iteracyjna idzie po wszystkich K kolejkach (żeby przejrzeć wszystkie dni).
            // Każdą kolejkę opróżnia pętla while. Dla każdego wierzchołka z kolejki robię następujący ciąg operacji:
            // - sprawdzam, czy ten wierzchołek już został rozpatrzony wcześniej (jeżeli tak, to nic nie robię i przechodzę dalej);
            // - jeżeli nie był jeszcze rozpatrzony, to zaczynam go rozpatrywać i zmieniam infected[x] na true;
            // - iteruję się po wszystkich sąsiadach wierzchołka x i sprawdzam, w którym dniu każdy z sąsiadów zostanie zainfekowany
            //   przez !!ten konkretny wierzchołek x!!. Robię to za pomocą funkcji pomocniczej samodzielnie zaimplementowanej;
            // - jeżeli sąsiad nie zostanie zainfekowany w ciągu K dni, to funkcja pomocnicza zwróci int.MaxValue i wtedy
            //   nic dalej nie robię;
            // - jeżeli sąsiad zostanie zainfekowany w ciągu K dni, to funkcja pomocnicza zwróci dzień, w którym zostanie 
            //   zainfekowany ten sąsiad. Wtedy dodaję ten wierzchołek do odpowiedniej kolejki (z numerem dnia zainfekowania);
            // Proszę zauważyć, że nie jest istotne, że dodaję ten sam wierzchołek do wielu kolejek. W każdym razie podczas 
            // zdejmowania wierzchołka z kolejki sprawdzam, czy on już był rozpatrzony, a więc i tak nie będę robił zbędnych operacji.
            // Po zakończeniu głównej pętli iteracyjnej robię to samo, co i w dwóch poprzednich etapach: liczę liczbę zainfekowanych
            // wierzchołków, robię tablicę zawierającą indeksy tych wierzchołków i zwracam te dwa obiekty, tym kończąc rozwiązanie. 

            Queue<int>[] days = new Queue<int>[K + 1];
            for (int i = 1; i <= K; i++)
            {
                days[i] = new Queue<int>();
            }
            bool[] infected = new bool[n];

            for (int i = 0; i < r; i++)
            {
                days[1].Enqueue(s[i]);
            }    

            
            for (int i = 1; i <= K; i++)
            {
                while (days[i].Count > 0)
                {
                    int currentVertex = days[i].Dequeue();

                    if (infected[currentVertex])
                        continue;
                    else
                    {
                        infected[currentVertex] = true;

                        foreach (int neighbour in G.OutNeighbors(currentVertex))
                        {
                            int dayOfInfection = DayOfInfection(serviceTurnoffDay[neighbour], serviceTurnonDay[neighbour],
                                serviceTurnoffDay[currentVertex], serviceTurnonDay[currentVertex], i, K);
                            if (dayOfInfection == int.MaxValue)
                            {
                                continue;
                            }

                            else
                            {
                                days[dayOfInfection].Enqueue(neighbour);
                                continue;
                            }     
                        }
                    }
                }
            }


            int count = 0;
            for (int i = 0; i < n; i++)
            {
                if (infected[i]) count++;
            }

            int[] listOfInfectedServices = new int[count];

            int index = 0;
            for (int i = 0; i < n; i++)
            {
                if (infected[i])
                {
                    listOfInfectedServices[index] = i;
                    index++;
                }
            }

            return (count, listOfInfectedServices);

        }

        // Funkcja pomocnicza, która zwraca dzień, w którym wierzchołek "ofiara" zostanie zainfekowany przez swojego sąsiada 
        // wierzchołka atakującego. Zwraca int.MaxValue, jeżeli nie zostanie zainfekowany w ciągu K dni.
        private int DayOfInfection(int victimOffDay, int victimOnDay, int attackerOffDay, int attackerOnDay, int attackerInfectedDay, int K)
        {
            // Szukam pierwszego dnia, w którym zarówno wierzchołek infekujący, jak i jego sąsiad będą włączone

            int candidateDay = attackerInfectedDay + 1; // Pierwszy możliwy dzień, w którym może zostać zainfekowany sąsiad

            while (candidateDay <= K)
            {
                // Zmienne, które mówią, czy wierzchołek i sąsiad działają w konkretnym dniu candidateDay
                bool attacker_is_turnedOn = (candidateDay < attackerOffDay || candidateDay > attackerOnDay); 
                bool victim_is_turnedOn = (candidateDay < victimOffDay || candidateDay > victimOnDay);

                // Jeśli oba są włączone, zwracam ten dzień
                if (attacker_is_turnedOn && victim_is_turnedOn)
                    return candidateDay;

                // Jeśli oba są wyłączone, przeskakuję od razu do najbliższego dnia, w którym ktoś z nich będzie pracował
                if (!attacker_is_turnedOn && !victim_is_turnedOn)
                    candidateDay = Math.Min(victimOnDay, attackerOnDay) + 1;

                // Jeśli wyłączony wierzchołek, przeskakuję do dnia, w którym on zacznie ponownie pracować
                else if (!attacker_is_turnedOn)
                    candidateDay = attackerOnDay + 1;

                // Jeśli wyłączony sąsiad, przeskakuje do dnia, w którym on zacznie ponownie pracować
                else if (!victim_is_turnedOn)
                    candidateDay = victimOnDay + 1;
            }

            // Jeśli jestem poza pętlą, to znaczy, że nie ma dnia w [attackerInfectedDay + 1, K],
            // gdzie oba są włączone jednocześnie - zwracam int.MaxValue
            return int.MaxValue; 
        }
    }
}
