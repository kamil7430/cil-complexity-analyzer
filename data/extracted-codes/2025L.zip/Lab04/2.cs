﻿using ASD.Graphs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASD
{
    public class Lab04 : MarshalByRefObject
    {

        /// <summary>
        /// Etap 1 - Wyznaczenie liczby oraz listy zainfekowanych serwisów po upływie K dni.
        /// Algorytm analizuje propagację infekcji w grafie i zwraca wszystkie dotknięte nią serwisy.
        /// </summary>
        /// <param name="G">Graf reprezentujący infrastrukturę serwisów.</param>
        /// <param name="K">Liczba dni propagacji infekcji.</param>
        /// <param name="s">Indeks początkowo zainfekowanego serwisu.</param>
        /// <returns>
        /// (int numberOfInfectedServices, int[] listOfInfectedServices) - 
        /// numberOfInfectedServices: liczba zainfekowanych serwisów,
        /// listOfInfectedServices: tablica zawierająca numery zainfekowanych serwisów w kolejności rosnącej.
        /// </returns>
        public (int numberOfInfectedServices, int[] listOfInfectedServices) Stage1(Graph G, int K, int s)
        {
            int n = G.VertexCount;
            int m = G.EdgeCount;
            

            int[] dayOfInfection = new int[n];
            for (int i = 0; i < n; i++)
            {
                dayOfInfection[i] = 0; // pętla być może do usunięcia
            }

            Queue<int> ableToInfect = new Queue<int>();

            dayOfInfection[s] = 1;
            ableToInfect.Enqueue(s);

            while (ableToInfect.Count > 0)
            {
                int currentVertex = ableToInfect.Dequeue();
                if (dayOfInfection[currentVertex] >= K)
                    break;

                foreach (int neighbor in G.OutNeighbors(currentVertex))
                {
                    if (dayOfInfection[neighbor] == 0)
                    {
                        dayOfInfection[neighbor] = dayOfInfection[currentVertex] + 1;
                        ableToInfect.Enqueue(neighbor);
                    }
                }
            }

            List<int> infectedVertices = new List<int>();
            for (int i = 0; i < n; i++)
            {
                if (dayOfInfection[i] != 0)
                {
                    infectedVertices.Add(i);
                }
            }

            return (infectedVertices.Count, infectedVertices.ToArray());
        }

        /// <summary>
        /// Etap 2 - Wyznaczenie liczby oraz listy zainfekowanych serwisów przy uwzględnieniu wyłączeń.
        /// Algorytm analizuje propagację infekcji z możliwością wcześniejszego wyłączania serwisów.
        /// </summary>
        /// <param name="G">Graf reprezentujący infrastrukturę serwisów.</param>
        /// <param name="K">Liczba dni propagacji infekcji.</param>
        /// <param name="s">Tablica początkowo zainfekowanych serwisów.</param>
        /// <param name="serviceTurnoffDay">Tablica zawierająca dzień, w którym dany serwis został wyłączony (K + 1 oznacza brak wyłączenia).</param>
        /// <returns>
        /// (int numberOfInfectedServices, int[] listOfInfectedServices) - 
        /// numberOfInfectedServices: liczba zainfekowanych serwisów,
        /// listOfInfectedServices: tablica zawierająca numery zainfekowanych serwisów w kolejności rosnącej.
        /// </returns>
        public (int numberOfInfectedServices, int[] listOfInfectedServices) Stage2(Graph G, int K, int[] s, int[] serviceTurnoffDay)
        {
            int n = G.VertexCount;
            int m = G.EdgeCount;
            int p = s.Length;

            int[] dayOfInfection = new int[n];
            for (int i = 0; i < n; i++)
            {
                dayOfInfection[i] = 0; // pętla być może do usunięcia
            }

            Queue<int> ableToInfect = new Queue<int>();

            for (int i = 0; i < p; i++)
            {
                dayOfInfection[s[i]] = 1;
                ableToInfect.Enqueue(s[i]);
            }

            int currentDay = 1;

            while (ableToInfect.Count > 0)
            {
                int currentVertex = ableToInfect.Dequeue();

                if (dayOfInfection[currentVertex] > currentDay)
                {
                    currentDay = dayOfInfection[currentVertex];
                }

                if (currentDay >= K) // oznacza, ze w kolejce zostaly tylko o tym samym dayOfInfection
                    break;

                if (isServiceOn(currentDay + 1, serviceTurnoffDay[currentVertex])) // sprawdzamy czy jtr rano moze zarazic
                {
                    foreach (int neighbor in G.OutNeighbors(currentVertex))
                    {
                        if (dayOfInfection[neighbor] == 0 && isServiceOn(currentDay + 1, serviceTurnoffDay[neighbor]))
                        {
                            dayOfInfection[neighbor] = currentDay + 1;
                            ableToInfect.Enqueue(neighbor);
                        }
                    }
                }
            }

            List<int> infectedVertices = new List<int>();
            for (int i = 0; i < n; i++)
            {
                if (dayOfInfection[i] != 0)
                {
                    infectedVertices.Add(i);
                }
            }

            return (infectedVertices.Count, infectedVertices.ToArray());
        }

        /// <summary>
        /// Etap 3 - Wyznaczenie liczby oraz listy zainfekowanych serwisów z możliwością ponownego włączenia wyłączonych serwisów.
        /// Algorytm analizuje propagację infekcji uwzględniając serwisy, które mogą być ponownie uruchamiane po określonym czasie.
        /// </summary>
       /// <param name="G">Graf reprezentujący infrastrukturę serwisów.</param>
        /// <param name="K">Liczba dni propagacji infekcji.</param>
        /// <param name="s">Tablica początkowo zainfekowanych serwisów.</param>
        /// <param name="serviceTurnoffDay">Tablica zawierająca dzień, w którym dany serwis został wyłączony (K + 1 oznacza brak wyłączenia).</param>
        /// <param name="serviceTurnonDay">Tablica zawierająca dzień, w którym dany serwis został ponownie włączony.</param>
        /// <returns>
        /// (int numberOfInfectedServices, int[] listOfInfectedServices) - 
        /// numberOfInfectedServices: liczba zainfekowanych serwisów,
        /// listOfInfectedServices: tablica zawierająca numery zainfekowanych serwisów w kolejności rosnącej.
        /// </returns>
        public (int numberOfInfectedServices, int[] listOfInfectedServices) Stage3(Graph G, int K, int[] s, int[] serviceTurnoffDay, int[] serviceTurnonDay)
        {
            int n = G.VertexCount;
            int m = G.EdgeCount;
            int p = s.Length;

            int[] dayOfInfection = new int[n];
            for (int i = 0; i < n; i++)
            {
                dayOfInfection[i] = 0; // pętla być może do usunięcia
            }

            Queue<int> ableToInfect = new Queue<int>();
            Queue<int>[] canBeInfectedThatDay = new Queue<int>[K + 1];

            for (int i = 1; i <= K; i++)
            {
                canBeInfectedThatDay[i] = new Queue<int>();
            }

            canBeInfectedThatDay[1] = new Queue<int>();
            for (int i = 0; i < p; i++)
            {
                canBeInfectedThatDay[1].Enqueue(s[i]);
            }

            int currentDay = 1;

            while (currentDay <= K)
            {
                Queue<int> infectedThatDay = canBeInfectedThatDay[currentDay];
                while (infectedThatDay.Count > 0)
                {
                    int infectedVertex = infectedThatDay.Dequeue();
                    if (dayOfInfection[infectedVertex] == 0)
                    {
                        dayOfInfection[infectedVertex] = currentDay;
                        ableToInfect.Enqueue(infectedVertex);
                    }
                }

                if (currentDay >= K) // przerywamy, bo nie chcemy zliczac zarazonych w K + 1 dniu
                    break;

                while (ableToInfect.Count > 0)
                {
                    int currentVertex = ableToInfect.Dequeue();

                    if (true)  // sprawdzamy czy jtr rano moze zarazic
                    {
                        //bool canInfectLater = false;
                        foreach (int neighbor in G.OutNeighbors(currentVertex))
                        {
                            bool serverCanInfectTomorrow = currentDay + 1 < serviceTurnoffDay[currentVertex] || currentDay >= serviceTurnonDay[currentVertex];
                            if (dayOfInfection[neighbor] == 0) //
                            {
                                bool neighborCanBeInfectedTomorrow = currentDay + 1 < serviceTurnoffDay[neighbor] || currentDay >= serviceTurnonDay[neighbor];

                                if (neighborCanBeInfectedTomorrow && serverCanInfectTomorrow) // moze zarzic teraz
                                {
                                    int infectionDay = currentDay + 1;
                                    if (infectionDay <= K)
                                    {
                                       canBeInfectedThatDay[infectionDay].Enqueue(neighbor);
                                    }
                                }
                                else if (neighborCanBeInfectedTomorrow) // serwer sie jtr wylacza
                                {
                                    bool wasNeighborDead = currentDay >= serviceTurnonDay[neighbor];
                                    if (wasNeighborDead)
                                    {
                                        int infectionDay = serviceTurnonDay[currentVertex] + 1;
                                        if (infectionDay <= K)
                                        {
                                            canBeInfectedThatDay[infectionDay].Enqueue(neighbor);
                                        }
                                    }
                                    else // neighbor bedzie wylaczony najwczesniej pojutrze
                                    {
                                        if (serviceTurnonDay[currentVertex] + 1 >= serviceTurnoffDay[neighbor]) // czasy wylaczenia nachodza na siebie  // tu zmiana
                                        {
                                            int infectionDay = Math.Max(serviceTurnonDay[currentVertex] + 1, serviceTurnonDay[neighbor] + 1);
                                            if (infectionDay <= K)
                                            {
                                               canBeInfectedThatDay[infectionDay].Enqueue(neighbor);
                                            }
                                        }
                                        else // czasy wylaczenia nie nachodza na siebie
                                        {
                                            int infectionDay = serviceTurnonDay[currentVertex] + 1;
                                            if (infectionDay <= K)
                                            {
                                               canBeInfectedThatDay[infectionDay].Enqueue(neighbor);
                                            }
                                        }
                                    }
                                }
                                else if (serverCanInfectTomorrow) // neighbor jest jtr wylaczony
                                {
                                    bool wasServerDead = currentDay >= serviceTurnonDay[currentVertex];
                                    if (wasServerDead)
                                    {
                                        int infectionDay = serviceTurnonDay[neighbor] + 1;
                                        if (infectionDay <= K)
                                        {
                                         canBeInfectedThatDay[infectionDay].Enqueue(neighbor);
                                        }
                                    }
                                    else // server bedzie wylaczony najwczesniej pojutrze
                                    {
                                        if (serviceTurnonDay[neighbor] + 1 >= serviceTurnoffDay[currentVertex]) // czasy wylaczenia nachodza na siebie
                                        {
                                            int infectionDay = Math.Max(serviceTurnonDay[neighbor] + 1, serviceTurnonDay[currentVertex] + 1);
                                            if (infectionDay <= K)
                                            {
                                                canBeInfectedThatDay[infectionDay].Enqueue(neighbor);
                                            }
                                        }
                                        else // czasy wylaczenia nie nachodza na siebie
                                        {
                                            int infectionDay = serviceTurnonDay[neighbor] + 1;
                                            if (infectionDay <= K)
                                            {
                                                canBeInfectedThatDay[infectionDay].Enqueue(neighbor);
                                            }
                                        }
                                    }
                                }
                                else // jtr jest serwer wylaczany i jest wylaczony neighbor
                                {
                                    int infectionDay = Math.Max(serviceTurnonDay[neighbor] + 1, serviceTurnonDay[currentVertex] + 1);
                                    if (infectionDay <= K)
                                    {
                                        canBeInfectedThatDay[infectionDay].Enqueue(neighbor);
                                    }
                                }
                            }
                        }
                    }
                }
                currentDay++;
            }

            

            List<int> infectedVertices = new List<int>();
            for (int i = 0; i < n; i++)
            {
                if (dayOfInfection[i] != 0)
                {
                    infectedVertices.Add(i);
                }
            }

            return (infectedVertices.Count, infectedVertices.ToArray());
        }

        private bool isServiceOff(int currentDay, int serviceTurnoffDay, int serviceTurnonDay = int.MaxValue)
        {
            return currentDay >= serviceTurnoffDay && currentDay < serviceTurnonDay;
        }

        private bool isServiceOn(int currentDay, int serviceTurnoffDay, int serviceTurnonDay = int.MaxValue)
        {
            return !isServiceOff(currentDay, serviceTurnoffDay, serviceTurnonDay);
        }
    }
}
