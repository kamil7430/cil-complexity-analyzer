using ASD.Graphs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASD
{
    public class Lab04 : MarshalByRefObject
    {
        /// <summary>
        /// Etap 1 - Wyznaczenie liczby oraz listy zainfekowanych serwisów po upływie K dni.
        /// Algorytm analizuje propagację infekcji w grafie i zwraca wszystkie dotknięte nią serwisy.
        /// </summary>
        /// <param name="G">Graf reprezentujący infrastrukturę serwisów.</param>
        /// <param name="K">Liczba dni propagacji infekcji.</param>
        /// <param name="s">Indeks początkowo zainfekowanego serwisu.</param>
        /// <returns>
        /// (int numberOfInfectedServices, int[] listOfInfectedServices) - 
        /// numberOfInfectedServices: liczba zainfekowanych serwisów,
        /// listOfInfectedServices: tablica zawierająca numery zainfekowanych serwisów w kolejności rosnącej.
        /// </returns>
        public (int numberOfInfectedServices, int[] listOfInfectedServices) Stage1(Graph G, int K, int s)
        {
            int n = G.VertexCount;
            int m = G.EdgeCount;

            var infected = new bool[n];
            var days = new int[n];
            var q = new Queue<int>();
            infected[s] = true;
            q.Enqueue(s);
            days[s] = 1;

            while (q.Count > 0)
            {
                var v = q.Dequeue();

                foreach (int u in G.OutNeighbors(v))
                {
                    if (infected[u]) continue;
                    days[u] = days[v] + 1;
                    infected[u] = true;
                    q.Enqueue(u);
                }
            }

            int nInfected = 0;
            var lInfected = new List<int>();
            for (int i = 0; i < n; i++)
            {
                if (infected[i] && days[i] <= K)
                {
                    nInfected++;
                    lInfected.Add(i);
                }
            }

            return (nInfected, lInfected.ToArray());
        }

        /// <summary>
        /// Etap 2 - Wyznaczenie liczby oraz listy zainfekowanych serwisów przy uwzględnieniu wyłączeń.
        /// Algorytm analizuje propagację infekcji z możliwością wcześniejszego wyłączania serwisów.
        /// </summary>
        /// <param name="G">Graf reprezentujący infrastrukturę serwisów.</param>
        /// <param name="K">Liczba dni propagacji infekcji.</param>
        /// <param name="s">Tablica początkowo zainfekowanych serwisów.</param>
        /// <param name="serviceTurnoffDay">Tablica zawierająca dzień, w którym dany serwis został wyłączony (K + 1 oznacza brak wyłączenia).</param>
        /// <returns>
        /// (int numberOfInfectedServices, int[] listOfInfectedServices) - 
        /// numberOfInfectedServices: liczba zainfekowanych serwisów,
        /// listOfInfectedServices: tablica zawierająca numery zainfekowanych serwisów w kolejności rosnącej.
        /// </returns>
        public (int numberOfInfectedServices, int[] listOfInfectedServices) Stage2(Graph G, int K, int[] s,
            int[] serviceTurnoffDay)
        {
            int n = G.VertexCount;
            int m = G.EdgeCount;
            int p = s.Length;

            var infected = new bool[n];
            var days = new int[n];
            const int inf = int.MaxValue;
            for (int i = 0; i < days.Length; i++)
            {
                days[i] = inf;
            }

            var q = new Queue<int>();

            foreach (var s0 in s)
            {
                infected[s0] = true;
                days[s0] = 1;
                q.Enqueue(s0);
            }

            while (q.Count > 0)
            {
                var v = q.Dequeue();

                foreach (int u in G.OutNeighbors(v))
                {
                    if (infected[u] || serviceTurnoffDay[u] <= days[v] + 1 ||
                        serviceTurnoffDay[v] <= days[v] + 1) continue;
                    days[u] = days[v] + 1;
                    infected[u] = true;
                    q.Enqueue(u);
                }
            }


            int nInfected = 0;
            var lInfected = new List<int>();
            for (int i = 0; i < n; i++)
            {
                if (infected[i] && days[i] <= K)
                {
                    nInfected++;
                    lInfected.Add(i);
                }
            }

            return (nInfected, lInfected.ToArray());
        }

        /// <summary>
        /// Etap 3 - Wyznaczenie liczby oraz listy zainfekowanych serwisów z możliwością ponownego włączenia wyłączonych serwisów.
        /// Algorytm analizuje propagację infekcji uwzględniając serwisy, które mogą być ponownie uruchamiane po określonym czasie.
        /// </summary>
        /// <param name="G">Graf reprezentujący infrastrukturę serwisów.</param>
        /// <param name="K">Liczba dni propagacji infekcji.</param>
        /// <param name="s">Tablica początkowo zainfekowanych serwisów.</param>
        /// <param name="serviceTurnoffDay">Tablica zawierająca dzień, w którym dany serwis został wyłączony (K + 1 oznacza brak wyłączenia).</param>
        /// <param name="serviceTurnonDay">Tablica zawierająca dzień, w którym dany serwis został ponownie włączony.</param>
        /// <returns>
        /// (int numberOfInfectedServices, int[] listOfInfectedServices) - 
        /// numberOfInfectedServices: liczba zainfekowanych serwisów,
        /// listOfInfectedServices: tablica zawierająca numery zainfekowanych serwisów w kolejności rosnącej.
        /// </returns>
        public (int numberOfInfectedServices, int[] listOfInfectedServices) Stage3(Graph G, int K, int[] s,
            int[] serviceTurnoffDay, int[] serviceTurnonDay)
        {
            int n = G.VertexCount;
            int m = G.EdgeCount;
            int p = s.Length;

            var infected = new bool[n];
            var active = new List<int>[K + 1]; // active[i] = wierzchołki "budzące się" w dniu i
            for (int i = 1; i <= K; i++)
                active[i] = new List<int>();

            int GetNextActiveDay(int day, int v)
            {
                if (!IsActive(day, v))
                    return serviceTurnonDay[v] + 1;
                return day;
            }

            bool IsActive(int day, int v)
            {
                if (day >= serviceTurnoffDay[v] && day <= serviceTurnonDay[v])
                    return false;
                return true;
            }

            foreach (var s0 in s)
            {
                infected[s0] = true;
                int spreadDay = GetNextActiveDay(2, s0);
                if (spreadDay <= K) active[spreadDay].Add(s0);
            }

            for (var day = 2; day <= K; day++)
            {
                foreach (var v in active[day])
                {
                    foreach (var u in G.OutNeighbors(v))
                    {
                        if (infected[v])
                        {
                            if (!IsActive(day, u))
                            {
                                var activeDay = GetNextActiveDay(day, u);
                                if (activeDay <= K) active[activeDay].Add(u);
                                continue;
                            }
                            if (infected[u]) continue;
                            infected[u] = true;
                            int spreadDay = GetNextActiveDay(day + 1, u);
                            if (spreadDay <= K) active[spreadDay].Add(u);
                        } else if (infected[u] && IsActive(day, u))
                        {
                            infected[v] = true;
                            int spreadDay = GetNextActiveDay(day + 1, v);
                            if (spreadDay <= K) active[spreadDay].Add(v);
                            break;
                        }
                    }
                }
            }

            int nInfected = 0;
            var lInfected = new List<int>();
            for (int i = 0; i < n; i++)
            {
                if (infected[i])
                {
                    nInfected++;
                    lInfected.Add(i);
                }
            }

            return (nInfected, lInfected.ToArray());
        }
    }
}