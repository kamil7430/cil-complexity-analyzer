﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ASD
{
    class SweepLine
    {
        /// <summary>
        /// Struktura pomocnicza opisująca zdarzenie
        /// </summary>
        /// <remarks>
        /// Można jej użyć, przerobić, albo w ogóle nie używać i zrobić po swojemu
        /// </remarks>
        struct SweepEvent
        {
            /// <summary>
            /// Współrzędna zdarzenia
            /// </summary>
            public double Coord;

            /// <summary>
            /// Czy zdarzenie oznacza początek odcinka/prostokąta
            /// </summary>
            public bool IsStartingPoint;

            /// <summary>
            /// Indeks odcinka/prodtokąta w odpowiedniej tablicy
            /// </summary>
            public int Idx;

            public SweepEvent(double c, bool sp, int i = -1)
            {
                Coord = c;
                IsStartingPoint = sp;
                Idx = i;
            }
        }

        /// <summary>
        /// Funkcja obliczająca długość teoriomnogościowej sumy pionowych odcinków
        /// </summary>
        /// <returns>Długość teoriomnogościowej sumy pionowych odcinków</returns>
        /// <param name="segments">Tablica z odcinkami, których teoriomnogościowej sumy długość należy policzyć</param>
        /// Każdy odcinek opisany jest przez dwa punkty: początkowy i końcowy
        public double VerticalSegmentsUnionLength(Geometry.Segment[] segments)
        {
            if (segments.Length == 0) return 0;
            
            var ends = new List<SweepEvent>(segments.Length * 2);
            for (var i = 0; i < segments.Length; ++i)
            {
                var start = segments[i].ps.y;
                var end = segments[i].pe.y;
                
                var s = start < end ? start : end;
                var e = start < end ? end : start;
                ends.Add(new SweepEvent(s, true, i));
                ends.Add(new SweepEvent(e, false, i));
            }

            ends = ends.OrderBy(e => e.Coord).ToList();

            double y;
            var open = 0;
            double y0 = -1;
            var res = 0.0;
            for (var j = 0; j < ends.Count; ++j)
            {
                y = ends[j].Coord;
                if (ends[j].IsStartingPoint)
                {
                    open++;
                    if (open == 1)
                        y0 = y;
                }
                else open--;

                if (open == 0)
                    res += y - y0;
            }

            return res;
        }

        /// <summary>
        /// Funkcja obliczająca pole teoriomnogościowej sumy prostokątów
        /// </summary>
        /// <returns>Pole teoriomnogościowej sumy prostokątów</returns>
        /// <param name="rectangles">Tablica z prostokątami, których teoriomnogościowej sumy pole należy policzyć</param>
        /// Każdy prostokąt opisany jest przez cztery wartości: minimalna współrzędna X, minimalna współrzędna Y, 
        /// maksymalna współrzędna X, maksymalna współrzędna Y.
        public double RectanglesUnionArea(Geometry.Rectangle[] rectangles)
        {
            if (rectangles.Length == 0) return 0;
            
            var sides = new List<SweepEvent>(rectangles.Length * 2);
            for (var i = 0; i < rectangles.Length; ++i)
            {
                var s = rectangles[i].MinX;
                var e = rectangles[i].MaxX;
                sides.Add(new SweepEvent(s, true, i));
                sides.Add(new SweepEvent(e, false, i));
            }

            sides = sides.OrderBy(e => e.Coord).ToList();
            
            var segments = new List<Geometry.Segment>(rectangles.Length);
            
            var res = 0.0;
            for (var i = 0; i < sides.Count; ++i)
            {
                var D = VerticalSegmentsUnionLength(segments.ToArray());
                var rect = rectangles[sides[i].Idx];
                var ps = new Geometry.Point(rect.MinX, rect.MinY);
                var pe = new Geometry.Point(rect.MinX, rect.MaxY);
                if (sides[i].IsStartingPoint)
                    segments.Add(new Geometry.Segment(ps, pe));
                else
                    segments.Remove(new Geometry.Segment(ps, pe));

                if (i > 0)
                    res += D * (sides[i].Coord - sides[i - 1].Coord);
            }
            
            return res;
        }
    }
}