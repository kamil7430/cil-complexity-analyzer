using System.Linq;
using ASD.Graphs;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

namespace ASD
{
    public class Lab06 : System.MarshalByRefObject
    {
        public List<int> WidePath(DiGraph<int> G, int start, int end)
        {
            const int inf = int.MaxValue;
            int[] width = new int[G.VertexCount];
            for (int i = 0; i < G.VertexCount; i++)
                width[i] = 0;
            width[start] = inf;
            var Q = new SafePriorityQueue<int, int>(G.VertexCount);
            for (int i = 0; i < G.VertexCount; i++)
                Q.Insert(i, -width[i]);

            var cameFrom = new int[G.VertexCount];
            for (int i = 0; i < G.VertexCount; i++) cameFrom[i] = -1;
            while (Q.Count > 0)
            {
                int u = Q.Extract();
                if (u == end) break;
                // if (width[u] != -p) continue;

                foreach (int v in G.OutNeighbors(u))
                {
                    int alt = Math.Min(width[u], G.GetEdgeWeight(u, v));
                    if (width[v] < alt)
                    {
                        width[v] = alt;
                        cameFrom[v] = u;
                        Q.UpdatePriority(v, -alt);
                    }
                }
            }

            if (width[end] == 0) return [];

            var t = end;
            List<int> result = [];
            while (t != start)
            {
                result.Add(t);
                t = cameFrom[t];
            }

            result.Add(start);

            result.Reverse();
            return result;
        }


        public List<int> WeightedWidePath(DiGraph<int> G, int start, int end, int[] weights, int maxWeight)
        {
            var uniqueWeightsHs = G.DFS().SearchAll().Select(e => e.Weight).ToHashSet();
            var uniqueWeights = uniqueWeightsHs.ToList();
            uniqueWeights.Sort();

            int bestValue = int.MinValue;
            List<int>? bestPath = null;

            var H = new DiGraph<int>(G.VertexCount, G.Representation);
            foreach (int w in uniqueWeights)
            {
                for (int i = 0; i < G.VertexCount; i++)
                    foreach (var u in G.OutEdges(i))
                        if (u.Weight >= w)
                            H.AddEdge(u.From, u.To, u.Weight);

                /* Dijkstra */
                const int inf = int.MaxValue;
                int[] dist = new int[H.VertexCount];
                for (int i = 0; i < H.VertexCount; i++)
                    dist[i] = inf;
                dist[start] = weights[start];
                var Q = new PriorityQueue<int, (int v, int p)>(H.VertexCount);
                for (int i = 0; i < H.VertexCount; i++)
                    Q.Insert((i, dist[i]), dist[i]);

                var cameFrom = new int[H.VertexCount];
                for (int i = 0; i < H.VertexCount; i++) cameFrom[i] = -1;
                while (Q.Count > 0)
                {
                    (int u, int p) = Q.Extract();
                    if (u == end) break;
                    if (dist[u] != p) continue;
                    
                    foreach (int v in H.OutNeighbors(u))
                    {
                        if (dist[v] > dist[u] + weights[v])
                        {
                            dist[v] = dist[u] + weights[v];
                            cameFrom[v] = u;
                            Q.Insert((v, dist[v]), dist[v]);
                        }
                    }
                }

                if (dist[end] == inf) continue;

                List<int>? path = [];
                bool[] visited = new bool[H.VertexCount];
                var t = end;
                while (t != start)
                {
                    if (t == -1 || visited[t])
                    {
                        path = null;
                        break;
                    }
                    visited[t] = true;
                    path.Add(t);
                    t = cameFrom[t];
                }
                if (path == null) continue;

                path.Add(start);
                /* Dijkstra end */

                int candidateValue = w - dist[end];

                if (candidateValue > bestValue)
                {
                    bestValue = candidateValue;
                    bestPath = path;
                }
            }

            if (bestPath == null) return [];
            bestPath.Reverse();
            return bestPath;
        }
    }
}