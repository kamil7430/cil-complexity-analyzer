﻿using System.Linq;

namespace ASD
{
    using ASD.Graphs;
    using System;
    using System.Collections.Generic;

    public class Lab06 : System.MarshalByRefObject
    {
        public List<int> WidePath(DiGraph<int> G, int start, int end)
        {
            PathsInfo<int> pathsInfo = Dijkstra(G, start);

            if (!pathsInfo.Reachable(start, end))
            {
                return new List<int>();
            }
            return pathsInfo.GetPath(start, end).ToList();
        }


        public List<int> WeightedWidePath(DiGraph<int> G, int start, int end, int[] weights, int maxWeight)
        {
            List<int> shortestPath = new List<int>();
            int lowestCost = int.MinValue;

            int currentMaxWeight = maxWeight;
            //int newStart = G.VertexCount;
            //DiGraph<int> graph = new DiGraph<int>(newStart + 1);
            //graph.AddEdge(newStart, start, weights[start]);

            bool noLowerWeight = true;

            do
            {
                int tempMaxWeight = 0;
                PathsInfo<int> pathsInfo = new PathsInfo<int>(G.VertexCount);
                SafePriorityQueue<int, int> safePriorityQueue = new SafePriorityQueue<int, int>(G.VertexCount);
                for (int i = 0; i < G.VertexCount; i++)
                {
                    safePriorityQueue.Insert(i);
                }


                safePriorityQueue.UpdatePriority(start, 0);
                while (safePriorityQueue.Count > 0 && pathsInfo.Reachable(start, safePriorityQueue.Peek()))
                {
                    int v = safePriorityQueue.Extract();
                    foreach (Edge<int> item in G.OutEdges(v))
                    {
                        int weight = item.Weight;
                        if (weight < currentMaxWeight)
                        {
                            if (weight > tempMaxWeight)
                            {
                                tempMaxWeight = weight;
                            }
                            continue;
                        }

                        int val = weights[item.To] + pathsInfo.GetDistance(start, item.From);
                        
                        if (!pathsInfo.Reachable(start, item.To) || val < pathsInfo.GetDistance(start, item.To))
                        {
                            safePriorityQueue.UpdatePriority(item.To, val);
                            pathsInfo.AddPathFragment(start, item.From, item.To, val);
                        }
                    }
                }

                if (pathsInfo.Reachable(start, end))
                {
                    int currentCost = currentMaxWeight - pathsInfo.GetDistance(start, end);
                    if (currentCost > lowestCost)
                    {
                        shortestPath = pathsInfo.GetPath(start, end).ToList();
                        lowestCost = currentCost;
                    }
                }
                if (tempMaxWeight == currentMaxWeight)
                {
                    noLowerWeight = false;
                }
                currentMaxWeight = tempMaxWeight;

            } while (noLowerWeight);

            return shortestPath;
        }

        public static PathsInfo<int> Dijkstra(IGraph<int> G, int source)
        {
            //if (typeof(T) == typeof(int))
            //{
            //    return Dijkstra_for_int((IGraph<int>)G, source) as PathsInfo<T>;
            //}

            PathsInfo<int> pathsInfo = new PathsInfo<int>(G.VertexCount);
            SafePriorityQueue<int, int> safePriorityQueue = new SafePriorityQueue<int, int>(G.VertexCount);
            for (int i = 0; i < G.VertexCount; i++)
            {
                safePriorityQueue.Insert(i);
            }

            _ = new int[G.VertexCount];
            _ = new int[G.VertexCount];
            safePriorityQueue.UpdatePriority(source, int.MinValue);
            while (safePriorityQueue.Count > 0 && pathsInfo.Reachable(source, safePriorityQueue.Peek()))
            {
                int v = safePriorityQueue.Extract();
                foreach (Edge<int> item in G.OutEdges(v))
                {
                    int weight = item.Weight;
                    //if (weight.CompareTo(new T()) < 0)
                    //{
                    //    throw new ArgumentException("Algorytm Dijkstry napotkał krawędź o ujemnej wadze!");
                    //}

                    //T val = (dynamic)item.Weight + (dynamic)pathsInfo.GetDistance(source, item.From);

                    if (item.To == source)
                    {
                        continue;
                    }

                    int val;
                    if ((val = Math.Min(item.Weight, pathsInfo.GetDistance(source, item.From))).CompareTo(new int()) == 0)
                    {
                        val = item.Weight;
                    }

                    if (!pathsInfo.Reachable(source, item.To) || val.CompareTo(pathsInfo.GetDistance(source, item.To)) == 1)
                    {
                        safePriorityQueue.UpdatePriority(item.To, -val);
                        pathsInfo.AddPathFragment(source, item.From, item.To, val);
                    }
                }
            }

            return pathsInfo;
        }
    }
}