﻿using ASD.Graphs;

/// <summary>
/// Klasa rozszerzająca klasę Graph o rozwiązania problemów największej kliki i izomorfizmu grafów metodą pełnego przeglądu (backtracking)
/// </summary>
public static class Lab10GraphExtender
{
    /// <summary>
    /// Wyznacza największą klikę w grafie i jej rozmiar metodą pełnego przeglądu (backtracking)
    /// </summary>
    /// <param name="g">Badany graf</param>
    /// <param name="clique">Wierzchołki znalezionej największej kliki - parametr wyjściowy</param>
    /// <returns>Rozmiar największej kliki</returns>
    /// <remarks>
    /// Nie wolno modyfikować badanego grafu.
    /// </remarks>
    public static int MaxClique(this Graph g, out int[] clique)
    {
        HashSet<int> S = new();
        HashSet<int> bestS = new();

        MaxCliqueRec(g, S, bestS, 0);
        clique = bestS.ToArray();
        return clique.Length;
    }

    private static void MaxCliqueRec(Graph g, HashSet<int> S, HashSet<int> bestS, int k)
    {
        HashSet<int> C = new();
        for (int vertex = k; vertex < g.VertexCount; vertex++)
        {
            HashSet<int> neighbors = new();
            foreach (int neighbor in g.OutNeighbors(vertex))
            {
                neighbors.Add(neighbor);
            }
            if (S.IsSubsetOf(neighbors))
            {
                C.Add(vertex);
            }
        }

        if (C.Count + S.Count <= bestS.Count)
        {
            return;
        }

        if (S.Count > bestS.Count)
        {
            bestS.Clear();
            foreach (int item in S)
            {
                bestS.Add(item);
            }
        }

        foreach (int vertex in C)
        {
            S.Add(vertex);
            MaxCliqueRec(g, S, bestS, vertex + 1);
            S.Remove(vertex);
        }
    }

    /// <summary>
    /// Bada izomorfizm grafów metodą pełnego przeglądu (backtracking)
    /// </summary>
    /// <param name="g">Pierwszy badany graf</param>
    /// <param name="h">Drugi badany graf</param>
    /// <param name="map">Mapowanie wierzchołków grafu h na wierzchołki grafu g (jeśli grafy nie są izomorficzne to null) - parametr wyjściowy</param>
    /// <returns>Informacja, czy grafy g i h są izomorficzne</returns>
    /// <remarks>
    /// 1) Uwzględniamy wagi krawędzi
    /// 3) Nie wolno modyfikować badanych grafów.
    /// </remarks>
    public static bool IsomorphismTest(this Graph<int> g, Graph<int> h, out int[] map)
    {
        if (g.VertexCount !=  h.VertexCount)
        {
            map = null;
            return false;
        }
        List<int> gDegrees = new List<int>();
        List<int> hDegrees = new List<int>();
        for (int i = 0; i < h.VertexCount; i++)
        {
            gDegrees.Add(g.Degree(i));
            hDegrees.Add(h.Degree(i));
        }
        gDegrees.Sort();
        hDegrees.Sort();
        if (!gDegrees.SequenceEqual(hDegrees))
        {
            map = null;
            return false;
        }
        bool[] usedVertexes = new bool[g.VertexCount];
        map = new int[g.VertexCount];
        for (int i = 0; i < map.Length; i++)
        {
            map[i] = -1;
        }
        map = IsomorphismRec(g, h, map, 0, usedVertexes);
        if (map != null)
        {
            return true;
        }
        return false;
    }

    private static int[]? IsomorphismRec(Graph<int> g, Graph<int> h, int[] map, int gVertexToMapTo, bool[] usedVertexes)
    {
        if (gVertexToMapTo == h.VertexCount)
        {
            return (int[]?)map.Clone();
        }

        for (int vertex = 0; vertex < h.VertexCount; vertex++)
        {
            if (!usedVertexes[vertex])
            {
                usedVertexes[vertex] = true;
                map[vertex] = gVertexToMapTo;

                if (g.Degree(map[vertex]) != h.Degree(vertex))
                {
                    map[vertex] = -1;
                    usedVertexes[vertex] = false;
                    continue;
                }
                bool mark = true;
                foreach (int neighbor in h.OutNeighbors(vertex))
                {
                    if (map[neighbor] == -1)
                    {
                        continue;
                    }
                    if (!g.HasEdge(map[vertex], map[neighbor]) || g.GetEdgeWeight(map[vertex], map[neighbor]) != h.GetEdgeWeight(vertex, neighbor))
                    {
                        map[vertex] = -1;
                        usedVertexes[vertex] = false;
                        mark = false;
                        break;
                    }
                }
                if (!mark)
                {
                    continue;
                }
                int[]? finalMap = IsomorphismRec(g, h, map, gVertexToMapTo + 1, usedVertexes);
                if (finalMap != null)
                {
                    return finalMap;
                }
                map[vertex] = -1;
                usedVertexes[vertex] = false;
            }
        }
        return null;
    }
}

