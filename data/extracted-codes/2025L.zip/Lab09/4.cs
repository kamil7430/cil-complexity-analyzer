﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ExceptionServices;
using ASD;
using ASD.Graphs;

/// <summary>
/// Klasa rozszerzająca klasę Graph o rozwiązania problemów największej kliki i izomorfizmu grafów metodą pełnego przeglądu (backtracking)
/// </summary>
public static class Lab10GraphExtender
{
    /// <summary>
    /// Wyznacza największą klikę w grafie i jej rozmiar metodą pełnego przeglądu (backtracking)
    /// </summary>
    /// <param name="g">Badany graf</param>
    /// <param name="clique">Wierzchołki znalezionej największej kliki - parametr wyjściowy</param>
    /// <returns>Rozmiar największej kliki</returns>
    /// <remarks>
    /// Nie wolno modyfikować badanego grafu.
    /// </remarks>
    public static int MaxClique(this Graph g, out int[] clique)
    {
        int n = g.VertexCount;
        List<int> currentClique = new List<int>();
        List<int> bestClique = new List<int>();

        MaxCliqueRec(0);

        void MaxCliqueRec(int k)
        {
            List<int> C = new List<int>();
            for (int i = (currentClique.Count != 0) ? currentClique[currentClique.Count - 1] : 0; i < n; i++)
            {
                bool flag = true;
                foreach (var vertex in currentClique)
                {
                    if (!g.HasEdge(i, vertex))
                    {
                        flag = false;
                        break;
                    }
                }
                if (flag) C.Add(i);
            }

            if (C.Count + currentClique.Count <= bestClique.Count)
                return;

            if (currentClique.Count > bestClique.Count)
                bestClique = new List<int>(currentClique);

            foreach (int vertex in C)
            {
                currentClique.Add(vertex);
                MaxCliqueRec(k + 1);
                currentClique.Remove(vertex);
            }
        }

        clique = bestClique.ToArray();
        return bestClique.Count;
    }

    /// <summary>
    /// Bada izomorfizm grafów metodą pełnego przeglądu (backtracking)
    /// </summary>
    /// <param name="g">Pierwszy badany graf</param>
    /// <param name="h">Drugi badany graf</param>
    /// <param name="map">Mapowanie wierzchołków grafu h na wierzchołki grafu g (jeśli grafy nie są izomorficzne to null) - parametr wyjściowy</param>
    /// <returns>Informacja, czy grafy g i h są izomorficzne</returns>
    /// <remarks>
    /// 1) Uwzględniamy wagi krawędzi
    /// 3) Nie wolno modyfikować badanych grafów.
    /// </remarks>
    public static bool IsomorphismTest(this Graph<int> g, Graph<int> h, out int[] map)
    {       
        int n = g.VertexCount;
        
        if (h.VertexCount != g.VertexCount || h.EdgeCount != g.EdgeCount)
        {
            map = null;
            return false;
        }

        bool[] usedVerteces = new bool[n];
        for (int i = 0; i < n; i++)
        {
            usedVerteces[i] = false;
        }
        int[] currentMap = new int[n];
        int[] finalMap = new int[n];

        bool IsomorphismTestRec(int k)
        {
            if (k == n)
            {
                if (IsMapValid(h, g, currentMap))
                {
                    finalMap = (int[])currentMap.Clone();
                    return true;
                }
                else return false;
            }
            
            else
            {
                for (int i = 0; i < n; i++)
                {
                    if (usedVerteces[i] || g.Degree(i) != h.Degree(k))
                        continue;

                    bool ok = true;
                    for (int j = 0; j < k && ok; j++)         // sprawdzamy, czy nowy wierzchołek i w g przypadkiem nie będzie miał jakichś 
                    {                                         // krawędzi nie zgadzających się z h.         
                        bool hHasEdge = h.HasEdge(k, j);
                        bool gHasEdge = g.HasEdge(i, currentMap[j]);

                        if (hHasEdge != gHasEdge)                    
                            ok = false;
                        else if (hHasEdge && h.GetEdgeWeight(k, j) != g.GetEdgeWeight(i, currentMap[j]))
                            ok = false;
                    }
                    if (!ok)                                   
                        continue;

                    usedVerteces[i] = true;
                    currentMap[k] = i;
                    if (g.Degree(i) == h.Degree(k) && IsomorphismTestRec(k + 1) == true)
                        return true;
                        
                    usedVerteces[i] = false;
                }

                return false;
            }
        }

        bool ans = IsomorphismTestRec(0);
        map = (ans) ? finalMap : null;
        return ans;
        
    }

    
    private static bool IsMapValid(Graph<int> g, Graph<int> h, int[] map)
    {
        for (int i = 0; i < g.VertexCount; i++)
        {
            for (int j = i + 1; j < h.VertexCount; j++)
            {
                bool gHasEdge = g.HasEdge(i, j);
                bool hHasEdge = h.HasEdge(map[i], map[j]);

                if (gHasEdge != hHasEdge) return false;

                int gWeight = (gHasEdge) ? g.GetEdgeWeight(i, j) : -1;
                int hWeight = (hHasEdge) ? h.GetEdgeWeight(map[i], map[j]): -1;

                if (gWeight != hWeight) return false;
            }
        }

        return true;
    }
    

    public static (Edge[], int) TSP(DiGraph<int> g)
    {
        int n = g.VertexCount;
        DiGraph<int> originalGraph = (DiGraph<int>)g.Clone();

        PriorityQueue<int, (int[,], List<Edge>)> priorityQueue = new PriorityQueue<int, (int[,], List<Edge>)>();

        int[,] adjacencyMatrix = new int[n,n];
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                adjacencyMatrix[i, j] = int.MaxValue;
            }
        }
        for (int i = 0; i < n; i++)
        {
            foreach (Edge<int> e in g.OutEdges(i))
            {
                adjacencyMatrix[e.From, e.To] = e.Weight;
            }
        }

        int lowerEstimate = 0;

        for (int i = 0; i < n; i++)
        {
            int least = int.MaxValue;
            for (int j = 0; j < n; j++)
            {    
                if (adjacencyMatrix[i, j] < least)
                    least = adjacencyMatrix[i, j];
            }

            if (least == 0 || least == int.MaxValue) continue;
            else
            {
                for (int j = 0; j < n; j++)
                {
                    if (adjacencyMatrix[i, j] != int.MaxValue)
                    {
                        adjacencyMatrix[i, j] -= least;
                    }
                }

                lowerEstimate += least;
            }
        }

        for (int j = 0; j < n; j++)
        {
            int least = int.MaxValue;
            for (int i = 0; i < n; i++)
            {
                if (adjacencyMatrix[i, j] < least)
                    least = adjacencyMatrix[i, j];
            }

            if (least == 0 || least == int.MaxValue) continue;
            else
            {
                for (int i = 0; i < n; i++)
                {
                    if (adjacencyMatrix[i, j] != int.MaxValue)
                    {
                        adjacencyMatrix[i, j] -= least;
                    }
                }
                lowerEstimate += least;
            }
        }

        priorityQueue.Insert((adjacencyMatrix, new List<Edge>()), lowerEstimate);

        while (true)
        {
            break; 
        }
        

        return (new Edge[0], int.MaxValue);
    }
    /*
    private static (int from, int to, int lowerEstimateIncrease) ChooseEdge(int[,] adjacencyMatrix)
    {
        int n = adjacencyMatrix.GetLength(0);
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                if (adjacencyMatrix[i, j] == 0)
                {

                }
            }
        }
    }
    private static (int[,], List<Edge>) CreateLState(int[,] adjacencyMatrix, List<Edge> edges, int lowerEstimate)
    {

    }
    */
}

