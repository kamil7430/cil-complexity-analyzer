﻿
using System.Collections.Generic;
using System.Linq;
using ASD.Graphs;

/// <summary>
/// Klasa rozszerzająca klasę Graph o rozwiązania problemów największej kliki i izomorfizmu grafów metodą pełnego przeglądu (backtracking)
/// </summary>
public static class Lab10GraphExtender
{
    /// <summary>
    /// Wyznacza największą klikę w grafie i jej rozmiar metodą pełnego przeglądu (backtracking)
    /// </summary>
    /// <param name="g">Badany graf</param>
    /// <param name="clique">Wierzchołki znalezionej największej kliki - parametr wyjściowy</param>
    /// <returns>Rozmiar największej kliki</returns>
    /// <remarks>
    /// Nie wolno modyfikować badanego grafu.
    /// </remarks>
    public static int MaxClique(this Graph g, out int[] clique)
    {
        int n = g.VertexCount;
        clique = null;

        var S = new HashSet<int>();
        var bestS = new List<int>();

        void MaxCliqueRec(int k)
        {
            var C = new HashSet<int>();
            for (int i = k; i < n; i++)
            {
                var ok = true;
                foreach (var v in S)
                    if (!g.HasEdge(i, v))
                    {
                        ok = false;
                        break;
                    }
                if (ok) C.Add(i);
            }

            if (C.Count + S.Count <= bestS.Count) return;

            if (S.Count > bestS.Count) bestS = S.ToList();

            foreach (var m in C)
            {
                S.Add(m);
                MaxCliqueRec(m + 1);
                S.Remove(m);
            }
        }

        MaxCliqueRec(0);
        clique = bestS.ToArray();

        return clique.Length;
    }

    /// <summary>
    /// Bada izomorfizm grafów metodą pełnego przeglądu (backtracking)
    /// </summary>
    /// <param name="g">Pierwszy badany graf</param>
    /// <param name="h">Drugi badany graf</param>
    /// <param name="map">Mapowanie wierzchołków grafu h na wierzchołki grafu g (jeśli grafy nie są izomorficzne to null) - parametr wyjściowy</param>
    /// <returns>Informacja, czy grafy g i h są izomorficzne</returns>
    /// <remarks>
    /// 1) Uwzględniamy wagi krawędzi
    /// 3) Nie wolno modyfikować badanych grafów.
    /// </remarks>
    public static bool IsomorphismTest(this Graph<int> g, Graph<int> h, out int[] res_map)
    {
        int n = g.VertexCount;
        int[]? map = null;
        res_map = null;
        if (h.VertexCount != n) return false;

        var used = new bool[n];
        var per = new int[n];

        bool Check(int k)
        {
            for (int i = 0; i < k; i++)
            {
                var (hi, hj) = (i, k);
                var (gi, gj) = (per[i], per[k]);
                if (g.HasEdge(gi, gj))
                {
                    if (!h.HasEdge(hi, hj)) return false;
                    if (g.GetEdgeWeight(gi, gj) != h.GetEdgeWeight(hi, hj)) return false;
                }
                else if (h.HasEdge(hi, hj)) return false;
            }
            return true;
        }

        void GenPer(int k)
        {
            if (map != null) return;
            if (k == n) {
                map = (int[])per.Clone();
                return;
            }

            for (int m = 0; m < n; m++)
            {
                if (used[m]) continue;
                used[m] = true;
                per[k] = m;
                if (Check(k))
                    GenPer(k + 1);
                used[m] = false;
            }
        }

        GenPer(0);
        res_map = map;

        return map != null;
    }
}

