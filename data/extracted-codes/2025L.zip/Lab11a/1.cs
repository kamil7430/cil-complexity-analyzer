﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ASD
{
    public class Lab11 : System.MarshalByRefObject
    {
        // iloczyn wektorowy
        private int Cross((double, double) o, (double, double) a, (double, double) b)
        {
            double value = (a.Item1 - o.Item1) * (b.Item2 - o.Item2) - (a.Item2 - o.Item2) * (b.Item1 - o.Item1);
            return Math.Abs(value) < 1e-10 ? 0 : value < 0 ? -1 : 1;
        }

        private double DistSq((double x, double y) a, (double x, double y) b) =>
            (a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y);

        private (double x, double y)[] GrahamSort((double x, double y)[] points)
        {
            if (points.Length == 1)
                return new (double x, double y)[1] { points[0] };

            var p0 = points.OrderBy(p => p.y).ThenBy(p => p.x).First();
            var sorted = points.Where(p => p != p0).ToList();
            sorted.Sort((a, b) =>
            {
                if (Cross(p0, a, b) == 0)
                    // dalsze punkty ustawiamy wcześniej
                    return DistSq(p0, a) > DistSq(p0, b) ? -1 : 1;
                return Cross(p0, a, b);
            });

            var P = new List<(double, double)>();
            P.Add(p0);
            P.Add(sorted[0]);
            for (var i = 1; i < sorted.Count; i++)
                if (Cross(p0, sorted[i - 1], sorted[i]) != 0)
                    P.Add(sorted[i]);

            return P.ToArray();
        }

        // Etap 1
        // po prostu otoczka wypukła
        public (double, double)[] ConvexHull((double x, double y)[] points)
        {
            if (points.Length == 0) return new (double, double)[0];
            if (points.Length == 1) return new (double, double)[1] { points[0] };

            var P = GrahamSort(points);

            var S = new Stack<(double, double)>();
            S.Push(P[0]);
            S.Push(P[1]);
            for (var k = 2; k < P.Length; k++)
            {
                while (S.Count >= 2 && Cross(S.Skip(1).First(), S.First(), P[k]) >= 0)
                    S.Pop();
                S.Push(P[k]);
            }

            return S.ToArray();
        }

        private (int, int) GetFurthest((double x, double y)[] poly)
        {
            var p0 = 0;
            var pn = 0;
            for (int i = 0; i < poly.Length; i++)
            {
                if (poly[i].x < poly[p0].x || (poly[i].x == poly[p0].x && poly[i].y > poly[p0].y))
                    p0 = i;

                if (poly[i].x > poly[pn].x || (poly[i].x == poly[pn].x && poly[i].y > poly[pn].y))
                    pn = i;
            }

            return (p0, pn);
        }

        private (double x, double y)[] ConvexHullFromSorted((double x, double y)[] poly)
        {
            if (poly.Length == 0) return new (double, double)[0];
            if (poly.Length == 1) return new (double x, double y)[1] { poly[0] };

            var S = new Stack<(double, double)>();
            S.Push(poly[0]);
            S.Push(poly[1]);

            for (var k = 2; k < poly.Length; k++)
            {
                while (S.Count >= 2 && Cross(S.Skip(1).First(), S.First(), poly[k]) >= 0)
                    S.Pop();
                S.Push(poly[k]);
            }

            return S.ToArray();
        }

        // Etap 2
        // oblicza otoczkę dwóch wielokątów wypukłych
        public (double, double)[] ConvexHullOfTwo((double x, double y)[] poly1, (double x, double y)[] poly2)
        {
            if (poly1.Length == 0) return ConvexHullFromSorted(poly2);
            if (poly2.Length == 0) return ConvexHullFromSorted(poly1);

            var (p01, pn1) = GetFurthest(poly1);
            var (p02, pn2) = GetFurthest(poly2);

            var low = new List<(double, double)>();
            int i = p01, j = p02;
            while (i != pn1 && j != pn2)
            {
                if (poly1[i].x < poly2[j].x)
                {
                    low.Add(poly1[i]);
                    i = (i + 1) % poly1.Length;
                }
                else
                {
                    low.Add(poly2[j]);
                    j = (j + 1) % poly2.Length;
                }
            }

            while (i != pn1)
            {
                low.Add(poly1[i]);
                i = (i + 1) % poly1.Length;
            }

            while (j != pn2)
            {
                low.Add(poly2[j]);
                j = (j + 1) % poly2.Length;
            }

            low.Add(poly1[pn1].x < poly2[pn2].x ? poly1[pn1] : poly2[pn2]);

            var high = new List<(double, double)>();
            int a = pn1, b = pn2;
            while (a != p01 && b != p02)
            {
                if (poly1[a].x > poly2[b].x)
                {
                    high.Add(poly1[a]);
                    a = (a - 1 + poly1.Length) % poly1.Length;
                }
                else
                {
                    high.Add(poly2[b]);
                    b = (b - 1 + poly2.Length) % poly2.Length;
                }
            }

            while (a != p01)
            {
                high.Add(poly1[a]);
                a = (a - 1 + poly1.Length) % poly1.Length;
            }

            while (b != p02)
            {
                high.Add(poly2[b]);
                b = (b - 1 + poly2.Length) % poly2.Length;
            }

            high.Add(poly1[p01].x > poly2[p02].x ? poly1[p01] : poly2[p02]);

            var lowHull = ConvexHullFromSorted(low.ToArray());
            high.Reverse();
            var highHull = ConvexHullFromSorted(high.ToArray());

            var result = new List<(double, double)>(lowHull);
            for (int k = highHull.Length - 2; k > 0; k--)
                result.Add(highHull[k]);

            return result.ToArray();
        }
    }
}