﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ASD;

public class Lab11 : System.MarshalByRefObject
{

    // iloczyn wektorowy
    private int Cross((double, double) o, (double, double) a, (double, double) b)
    {
        double value = (a.Item1 - o.Item1) * (b.Item2 - o.Item2) - (a.Item2 - o.Item2) * (b.Item1 - o.Item1);
        return Math.Abs(value) < 1e-10 ? 0 : value < 0 ? -1 : 1;
    }

    // Etap 1
    // po prostu otoczka wypukła
    public (double, double)[] ConvexHull((double, double)[] points)
    {
        if (points.Length < 3)
        {
            return points;
        }

        // znalezienie wierzcholka o najmniejszej wspolrzednej y
        (double, double) minY = points.MinBy(p => (p.Item2, p.Item1));

        var otherPoints = points.Where(p => p != minY).Distinct().ToList();

        // posortowanie punktow
        otherPoints
            .Sort((a, b) =>
            {
                int cmp = Cross(minY, a, b);
                if (cmp == 0)
                {
                    return a.Item1*a.Item1 + a.Item2 * a.Item2 < b.Item1 * b.Item1 + b.Item2 * b.Item2 ? -1 : 1;
                }
                return -cmp;
            });

        // usuwanie duplikatow i ponktow leżących na tej samej prostej razem z minY
        var pointsToRemove = new List<(double, double)>();
        bool isFirst = true;
        for (int i = 0; i < otherPoints.Count - 1; i++)
        {
            // sprawdzamy czy jest duplikatem
            if (otherPoints[i].Item1 == otherPoints[i + 1].Item1 && otherPoints[i].Item2 == otherPoints[i + 1].Item2)
            {
                pointsToRemove.Add(otherPoints[i]);
                continue;
            }

            // sprawdzamy czy punkty i i i+1 leżą na tej samej prostej
            if (Cross(minY, otherPoints[i], otherPoints[i + 1]) == 0)
            {
                if (isFirst)
                {
                    isFirst = false;
                    continue;
                }
                pointsToRemove.Add(otherPoints[i]);
            }
            else
            {
                isFirst = true;
            }
        }

        // usuwamy punkty
        foreach (var point in pointsToRemove)
        {
            otherPoints.Remove(point);
        }

        // zaczynamy Grahama
        var stack = new Stack<(double, double)>();
        stack.Push(minY);
        stack.Push(otherPoints[0]);
        for (int i = 1; i < otherPoints.Count; i++)
        {
            // sprawdzamy czy jest to lewy skręt
            while (stack.Count > 1 && Cross(stack.ElementAt(1), stack.Peek(), otherPoints[i]) != 1)
            {
                stack.Pop();
            }
            stack.Push(otherPoints[i]);
        }
        return stack.Reverse().ToArray();
    }

    // Etap 2
    // oblicza otoczkę dwóch wielokątów wypukłych
    public (double, double)[] ConvexHullOfTwo((double, double)[] poly1, (double, double)[] poly2)
    {
        Console.WriteLine();
        Console.WriteLine("poly1: ");
        foreach (var point in poly1)
        {
            Console.WriteLine(point);
        }
        Console.WriteLine("poly2: ");
        foreach (var point in poly2)
        {
            Console.WriteLine(point);
        }
        Console.WriteLine();

        SplitToTopBottom(poly1, out var bottom1, out var top1);
        SplitToTopBottom(poly2, out var bottom2, out var top2);

        Console.WriteLine("top1: ");
        foreach (var point in top1)
        {
            Console.WriteLine(point);
        }
        Console.WriteLine("bottom1: ");
        foreach (var point in bottom1)
        {
            Console.WriteLine(point);
        }
        Console.WriteLine("top2: ");
        foreach (var point in top2)
        {
            Console.WriteLine(point);
        }
        Console.WriteLine("bottom2: ");
        foreach (var point in bottom2)
        {
            Console.WriteLine(point);
        }

        var bigTop = MergeByX(top1, top2);
        var bigBottom = MergeByX(bottom1, bottom2);

        Console.WriteLine();
        Console.WriteLine("bigTop: ");
        foreach (var point in bigTop)
        {
            Console.WriteLine(point);
        }
        Console.WriteLine("bigBottom: ");
        foreach (var point in bigBottom)
        {
            Console.WriteLine(point);
        }

        return null;
    }


    private void SplitToTopBottom((double, double)[] poly, out List<(double, double)> bottom, out List<(double, double)> top)
    {
        int minXIndex = 0;
        int maxXIndex = 0;
        for (int j = 0; j < poly.Length; j++)
        {
            if (poly[j].Item1 < poly[minXIndex].Item1)
            {
                minXIndex = j;
            }
            else if (poly[j].Item1 > poly[maxXIndex].Item1)
            {
                maxXIndex = j;
            }
        }

        bottom = new List<(double, double)>();
        top = new List<(double, double)>();

        int i = minXIndex;
        while (true)
        {
            bottom.Add(poly[i]);
            
            if (i == maxXIndex)
            {
                break;
            }
            i++;
            if (i == poly.Length)
            {
                i = 0;
            }
        }

        i = (maxXIndex + 1) % poly.Length;
        while (true)
        {
            if (i == minXIndex)
            {
                break;
            }
            top.Add(poly[i]);
            i++;
            if (i == poly.Length)
            {
                i = 0;
            }
        }
    }

    private List<(double, double)> MergeByX(List<(double, double)> poly1, List<(double, double)> poly2)
    {
        var result = new List<(double, double)>();
        int i = 0;
        int j = 0;
        while (i < poly1.Count && j < poly2.Count)
        {
            if (poly1[i].Item1 < poly2[j].Item1)
            {
                result.Add(poly1[i]);
                i++;
            }
            else
            {
                result.Add(poly2[j]);
                j++;
            }
        }
        while (i < poly1.Count)
        {
            result.Add(poly1[i]);
            i++;
        }
        while (j < poly2.Count)
        {
            result.Add(poly2[j]);
            j++;
        }
        return result;
    }
}
