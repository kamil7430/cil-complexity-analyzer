﻿using System;
using System.Linq;
using ASD.Graphs;

namespace ASD
{
    public class ProductionPlanner : MarshalByRefObject
    {
        /// <summary>
        /// Flaga pozwalająca na włączenie wypisywania szczegółów skonstruowanego planu na konsolę.
        /// Wartość <code>true</code> spoeoduje wypisanie planu.
        /// </summary>
        public bool ShowDebug { get; } = false;

        /// <summary>
        /// Część 1. zadania - zaplanowanie produkcji telewizorów dla pojedynczego kontrahenta.
        /// </summary>
        /// <remarks>
        /// Do przeprowadzenia testów wyznaczających maksymalną produkcję i zysk wymagane jest jedynie zwrócenie obiektu <see cref="PlanData"/>.
        /// Testy weryfikujące plan wymagają przypisania tablicy z planem do parametru wyjściowego <see cref="weeklyPlan"/>.
        /// </remarks>
        /// <param name="production">
        /// Tablica obiektów zawierających informacje o produkcji fabryki w kolejnych tygodniach.
        /// Wartości pola <see cref="PlanData.Quantity"/> oznaczają limit produkcji w danym tygodniu,
        /// a pola <see cref="PlanData.Value"/> - koszt produkcji jednej sztuki.
        /// </param>
        /// <param name="sales">
        /// Tablica obiektów zawierających informacje o sprzedaży w kolejnych tygodniach.
        /// Wartości pola <see cref="PlanData.Quantity"/> oznaczają maksymalną sprzedaż w danym tygodniu,
        /// a pola <see cref="PlanData.Value"/> - cenę sprzedaży jednej sztuki.
        /// </param>
        /// <param name="storageInfo">
        /// Obiekt zawierający informacje o magazynie.
        /// Wartość pola <see cref="PlanData.Quantity"/> oznacza pojemność magazynu,
        /// a pola <see cref="PlanData.Value"/> - koszt przechowania jednego telewizora w magazynie przez jeden tydzień.
        /// </param>
        /// <param name="weeklyPlan">
        /// Parametr wyjściowy, przez który powinien zostać zwrócony szczegółowy plan sprzedaży.
        /// </param>
        /// <returns>
        /// Obiekt <see cref="PlanData"/> opisujący wyznaczony plan.
        /// W polu <see cref="PlanData.Quantity"/> powinna znaleźć się maksymalna liczba wyprodukowanych telewizorów,
        /// a w polu <see cref="PlanData.Value"/> - wyznaczony maksymalny zysk fabryki.
        /// </returns>
        public PlanData CreateSimplePlan(PlanData[] production, PlanData[] sales, PlanData storageInfo,
            out SimpleWeeklyPlan[] weeklyPlan)
        {
            int s = production.Length;
            int t = production.Length + 1;


            NetworkWithCosts<int, double> G = new NetworkWithCosts<int, double>(production.Length + 2);
            for (int i = 0; i < production.Length; i++)
            {
                // produkcja
                G.AddEdge(s, i, production[i].Quantity, production[i].Value);

                // sprzedaż
                G.AddEdge(i, t, sales[i].Quantity, -sales[i].Value);

                // magazyn
                if (i < production.Length - 1)
                {
                    G.AddEdge(i, i + 1, storageInfo.Quantity, storageInfo.Value);
                }
            }

            var (flowValue, flowCost, f) = Flows.MinCostMaxFlow(G, s, t);



            weeklyPlan = new SimpleWeeklyPlan[production.Length];
            for (int i = 0; i < production.Length; i++)
            {
                weeklyPlan[i] = new SimpleWeeklyPlan
                {
                    UnitsProduced = f.HasEdge(s, i) ? f.GetEdgeWeight(s, i) : 0,
                    UnitsSold = f.HasEdge(i, t) ? f.GetEdgeWeight(i, t) : 0,
                    UnitsStored = i == production.Length - 1 ? 0 : f.HasEdge(i, i + 1) ? f.GetEdgeWeight(i, i + 1) : 0,
                };
            }
            return new PlanData { Quantity = flowValue, Value = -flowCost };
        }

        /// <summary>
        /// Część 2. zadania - zaplanowanie produkcji telewizorów dla wielu kontrahentów.
        /// </summary>
        /// <remarks>
        /// Do przeprowadzenia testów wyznaczających produkcję dającą maksymalny zysk wymagane jest jedynie zwrócenie obiektu <see cref="PlanData"/>.
        /// Testy weryfikujące plan wymagają przypisania tablicy z planem do parametru wyjściowego <see cref="weeklyPlan"/>.
        /// </remarks>
        /// <param name="production">
        /// Tablica obiektów zawierających informacje o produkcji fabryki w kolejnych tygodniach.
        /// Wartość pola <see cref="PlanData.Quantity"/> oznacza limit produkcji w danym tygodniu,
        /// a pola <see cref="PlanData.Value"/> - koszt produkcji jednej sztuki.
        /// </param>
        /// <param name="sales">
        /// Dwuwymiarowa tablica obiektów zawierających informacje o sprzedaży w kolejnych tygodniach.
        /// Pierwszy wymiar tablicy jest równy liczbie kontrahentów, zaś drugi - liczbie tygodni w planie.
        /// Wartości pola <see cref="PlanData.Quantity"/> oznaczają maksymalną sprzedaż w danym tygodniu,
        /// a pola <see cref="PlanData.Value"/> - cenę sprzedaży jednej sztuki.
        /// Każdy wiersz tablicy odpowiada jednemu kontrachentowi.
        /// </param>
        /// <param name="storageInfo">
        /// Obiekt zawierający informacje o magazynie.
        /// Wartość pola <see cref="PlanData.Quantity"/> oznacza pojemność magazynu,
        /// a pola <see cref="PlanData.Value"/> - koszt przechowania jednego telewizora w magazynie przez jeden tydzień.
        /// </param>
        /// <param name="weeklyPlan">
        /// Parametr wyjściowy, przez który powinien zostać zwrócony szczegółowy plan sprzedaży.
        /// </param>
        /// <returns>
        /// Obiekt <see cref="PlanData"/> opisujący wyznaczony plan.
        /// W polu <see cref="PlanData.Quantity"/> powinna znaleźć się optymalna liczba wyprodukowanych telewizorów,
        /// a w polu <see cref="PlanData.Value"/> - wyznaczony maksymalny zysk fabryki.
        /// </returns>
        public PlanData CreateComplexPlan(PlanData[] production, PlanData[,] sales, PlanData storageInfo,
            out WeeklyPlan[] weeklyPlan)
        {
            int s = 2 * production.Length + sales.GetLength(0);
            int t = 2 * production.Length + sales.GetLength(0) + 1;


            NetworkWithCosts<int, double> G = new NetworkWithCosts<int, double>(2 * production.Length + sales.GetLength(0) + 2);
            for (int i = 0; i < production.Length; i++)
            {
                // produkcja
                G.AddEdge(i, production.Length + i, production[i].Quantity, production[i].Value);

                // krawedzie pomocnicze zapewniające stałą wartość przepływu
                G.AddEdge(s, i, production[i].Quantity, 0);
                G.AddEdge(i, t, production[i].Quantity, 0);

                // sprzedaż
                for (int j = 0; j < sales.GetLength(0); j++)
                {
                    G.AddEdge(production.Length + i, 2 * production.Length + j, sales[j, i].Quantity, -sales[j, i].Value);
                }

                // magazyn
                if (i < production.Length - 1)
                {
                    G.AddEdge(production.Length + i, production.Length + i + 1, storageInfo.Quantity, storageInfo.Value);
                }
            }

            for (int i = 0; i < sales.GetLength(0); i++)
            {
                G.AddEdge(i + 2 * production.Length, t, int.MaxValue, 0);
            }

            var (flowValue, flowCost, f) = Flows.MinCostMaxFlow(G, s, t);
            weeklyPlan = new WeeklyPlan[production.Length];
            int sumProduced = 0;
            for (int i = 0; i < production.Length; i++)
            {
                int[] UnitsSold = new int[sales.GetLength(0)];


                for (int j = 0; j < sales.GetLength(0); j++)
                {
                    UnitsSold[j] = f.HasEdge(production.Length + i, 2 * production.Length + j) ?
                        f.GetEdgeWeight(production.Length + i, 2 * production.Length + j) : 0;
                    sumProduced += UnitsSold[j];
                }

                weeklyPlan[i] = new WeeklyPlan
                {
                    UnitsProduced = f.HasEdge(i, production.Length + i) ? f.GetEdgeWeight(i, production.Length + i) : 0,
                    UnitsStored = i == production.Length - 1 ? 0
                        : f.HasEdge(production.Length + i, production.Length + i + 1)
                        ? f.GetEdgeWeight(production.Length + i, production.Length + i + 1) : 0,
                    UnitsSold = UnitsSold,

                };


            }
            return new PlanData
            {
                Quantity = sumProduced,
                Value = -flowCost,
            };
        }
    }
}