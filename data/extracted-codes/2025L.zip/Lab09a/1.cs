﻿using System;
using System.Collections.Generic;
using System.Linq;
using ASD.Graphs;

namespace ASD
{
    public class Lab08 : MarshalByRefObject
    {
        /// <summary>
        /// Znajduje cykl rozpoczynający się w stolicy, który dla wybranych miast,
        /// przez które przechodzi ma największą sumę liczby ludności w tych wybranych
        /// miastach oraz minimalny koszt.
        /// </summary>
        /// <param name="cities">
        /// Graf miast i połączeń między nimi.
        /// Waga krawędzi jest kosztem przejechania między dwoma miastami.
        /// Koszty transportu między miastami są nieujemne.
        /// </param>
        /// <param name="citiesPopulation">Liczba ludności miast</param>
        /// <param name="meetingCosts">
        /// Koszt spotkania w każdym z miast.
        /// Dla części pierwszej koszt spotkania dla każdego miasta wynosi 0.
        /// Dla części drugiej koszty są nieujemne.
        /// </param>
        /// <param name="budget">Budżet do wykorzystania przez kandydata.</param>
        /// <param name="capitalCity">Numer miasta będącego stolicą, z której startuje kandydat.</param>
        /// <param name="path">
        /// Tablica dwuelementowych krotek opisująca ciąg miast, które powinen odwiedzić kandydat.
        /// Pierwszy element krotki to numer miasta do odwiedzenia, a drugi element decyduje czy
        /// w danym mieście będzie organizowane spotkanie wyborcze.
        /// 
        /// Pierwszym miastem na tej liście zawsze będzie stolica (w której można, ale nie trzeba
        /// organizować spotkania).
        /// 
        /// Zakładamy, że po odwiedzeniu ostatniego miasta na liście kandydat wraca do stolicy
        /// (na co musi mu starczyć budżetu i połączenie między tymi miastami musi istnieć).
        /// 
        /// Jeżeli kandydat nie wyjeżdża ze stolicy (stolica jest jedynym miastem, które odwiedzi),
        /// to lista `path` powinna zawierać jedynie jeden element: stolicę (wraz z informacją
        /// czy będzie tam spotkanie czy nie). Nie są wtedy ponoszone żadne koszty podróży.
        /// 
        /// W pierwszym etapie drugi element krotki powinien być zawsze równy `true`.
        /// </param>
        /// <returns>
        /// Liczba mieszkańców, z którymi spotka się kandydat.
        /// </returns>
        public int ComputeElectionCampaignPath(Graph<int> g, int[] citiesPopulation,
            double[] meetingCosts, double budget, int capitalCity, out (int, bool)[] path)
        {
            int n = g.VertexCount;

            var best = (
                citizens: citiesPopulation[capitalCity],
                cost: 0.0,
                res: new List<int> { capitalCity }
            );

            var used = new bool[n];
            var curPath = new List<int> { capitalCity };
            used[capitalCity] = true;

            // 3) Rekurencja z parametrami: k = liczba odwiedzonych (wliczając stolicę),
            //    cost = koszt dotychczasowej trasy (bez kosztu powrotu),
            //    citizens = suma populacji odwiedzonych
            void PerRec(int k, double cost, int citizens)
            {
                int last = curPath[k - 1];

                for (int m = 0; m < n; m++)
                {
                    if (used[m]) continue;
                    if (!g.HasEdge(last, m)) continue;

                    double costToM = cost + g.GetEdgeWeight(last, m);
                    if (costToM > budget) continue;

                    int newCitizens = citizens + citiesPopulation[m];
                    if (g.HasEdge(m, capitalCity))
                    {
                        double fullCycleCost = costToM + g.GetEdgeWeight(m, capitalCity);
                        if (fullCycleCost <= budget)
                        {
                            if (newCitizens > best.citizens
                                || (newCitizens == best.citizens && fullCycleCost < best.cost))
                            {
                                best = (newCitizens, fullCycleCost, new List<int>(curPath));
                                best.res.Add(m);
                            }
                        }
                    }

                    used[m] = true;
                    curPath.Add(m);
                    PerRec(k + 1, costToM, newCitizens);
                    curPath.RemoveAt(curPath.Count - 1);
                    used[m] = false;
                }
            }

            PerRec(1, 0.0, citiesPopulation[capitalCity]);

            path = best.res.Select(v => (v, true)).ToArray();
            return best.citizens;
        }
    }
}