﻿using System;
using System.Collections.Generic;
using System.Linq;
using ASD.Graphs;

namespace ASD
{
    public class Lab08 : MarshalByRefObject
    {
        /// <summary>
        /// Znajduje cykl rozpoczynający się w stolicy, który dla wybranych miast,
        /// przez które przechodzi ma największą sumę liczby ludności w tych wybranych
        /// miastach oraz minimalny koszt.
        /// </summary>
        /// <param name="cities">
        /// Graf miast i połączeń między nimi.
        /// Waga krawędzi jest kosztem przejechania między dwoma miastami.
        /// Koszty transportu między miastami są nieujemne.
        /// </param>
        /// <param name="citiesPopulation">Liczba ludności miast</param>
        /// <param name="meetingCosts">
        /// Koszt spotkania w każdym z miast.
        /// Dla części pierwszej koszt spotkania dla każdego miasta wynosi 0.
        /// Dla części drugiej koszty są nieujemne.
        /// </param>
        /// <param name="budget">Budżet do wykorzystania przez kandydata.</param>
        /// <param name="capitalCity">Numer miasta będącego stolicą, z której startuje kandydat.</param>
        /// <param name="path">
        /// Tablica dwuelementowych krotek opisująca ciąg miast, które powinen odwiedzić kandydat.
        /// Pierwszy element krotki to numer miasta do odwiedzenia, a drugi element decyduje czy
        /// w danym mieście będzie organizowane spotkanie wyborcze.
        /// 
        /// Pierwszym miastem na tej liście zawsze będzie stolica (w której można, ale nie trzeba
        /// organizować spotkania).
        /// 
        /// Zakładamy, że po odwiedzeniu ostatniego miasta na liście kandydat wraca do stolicy
        /// (na co musi mu starczyć budżetu i połączenie między tymi miastami musi istnieć).
        /// 
        /// Jeżeli kandydat nie wyjeżdża ze stolicy (stolica jest jedynym miastem, które odwiedzi),
        /// to lista `path` powinna zawierać jedynie jeden element: stolicę (wraz z informacją
        /// czy będzie tam spotkanie czy nie). Nie są wtedy ponoszone żadne koszty podróży.
        /// 
        /// W pierwszym etapie drugi element krotki powinien być zawsze równy `true`.
        /// </param>
        /// <returns>
        /// Liczba mieszkańców, z którymi spotka się kandydat.
        /// </returns>
        public int ComputeElectionCampaignPath(Graph<int> cities, int[] citiesPopulation,
            double[] meetingCosts, double budget, int capitalCity, out (int, bool)[] path)
        {
            HashSet<int> visitedCities = [];
            visitedCities.Add(0);
            var currentPath = new (int, bool)[cities.VertexCount];
            for (int i = 0; i < cities.VertexCount; i++)
            {
                currentPath[i].Item1 = -1;
                currentPath[i].Item2 = false;
            }
            currentPath[capitalCity].Item1 = 0;
            currentPath[capitalCity].Item2 = true;
            var (voters, _) = CountryTour(cities, citiesPopulation, meetingCosts, budget, capitalCity, visitedCities, 0, currentPath, citiesPopulation[capitalCity], capitalCity, out path);
            return voters;
        }

        private (int voters, int cost) CountryTour(Graph<int> cities, int[] citiesPopulation,
            double[] meetingCosts, double budget, int capitalCity, HashSet<int> visitedCities, int currentCost, (int, bool)[] currentPath, int currentVoters, int currentCity, out (int, bool)[] path)
        {
            path = null;
            if (visitedCities.Count == cities.VertexCount)
            {
                if (cities.HasEdge(currentCity, capitalCity) && currentCost + cities.GetEdgeWeight(currentCity, capitalCity) <= budget)
                {
                    path = ((int, bool)[])currentPath.Clone();
                    return (currentVoters, currentCost + cities.GetEdgeWeight(currentCity, capitalCity));
                }
                path = new (int, bool)[0];
                return (-1, -1);
            }

            int maxVoters = 0;
            int minCost = int.MaxValue;
            foreach (int neighbor in cities.OutNeighbors(currentCity))
            {
                if (visitedCities.Contains(neighbor))
                {
                    continue;
                }

                int expectedCost = currentCost + cities.GetEdgeWeight(currentCity, neighbor);
                if (expectedCost > budget)
                {
                    continue;
                }

                visitedCities.Add(neighbor);
                currentCost += expectedCost;
                currentVoters += citiesPopulation[neighbor];
                (int voters, int cost) = CountryTour(cities, citiesPopulation, meetingCosts, budget, capitalCity, visitedCities, currentCost, currentPath, currentVoters, currentCity, out (int, bool)[] tempPath);
                if (voters >= maxVoters)
                {
                    if (voters > maxVoters || (voters == maxVoters && cost < minCost))
                    {
                        path = ((int, bool)[])tempPath.Clone();
                        minCost = cost;
                        maxVoters = voters;
                    }
                }
                visitedCities.Remove(neighbor);
                currentCost -= expectedCost;
                currentVoters -= citiesPopulation[neighbor];
            }

            if (cities.HasEdge(currentCity, capitalCity) && currentVoters >= maxVoters)
            {
                int expectedCost = currentCost + cities.GetEdgeWeight(currentCity, capitalCity);
                if (expectedCost <= budget && (currentVoters > maxVoters || (currentVoters == maxVoters && expectedCost < minCost)))
                {
                    path = ((int, bool)[])currentPath.Clone();
                    minCost = expectedCost;
                    maxVoters = currentVoters;
                }
            }

            if (maxVoters > 0)
            {
                return (maxVoters, minCost);
            }
            return (-1, -1);
        }
    }
}
