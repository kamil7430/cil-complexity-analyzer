using ASD.Graphs;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ASD
{
    public class Lab06 : MarshalByRefObject
    {
        /// <summary>Etap I</summary>
        /// <param name="G">Graf opisujący połączenia szlakami turystycznymi z podanym czasem przejścia krawędzi w wadze.</param>
        /// <param name="waitTime">Czas oczekiwania Studenta-Podróżnika w danym wierzchołku.</param>
        /// <param name="s">Wierzchołek startowy (początek trasy).</param>
        /// <returns>Pierwszy element krotki to wierzchołek końcowy szukanej trasy. Drugi element to długość trasy w minutach. Trzeci element to droga będąca rozwiązaniem: sekwencja odwiedzanych wierzchołków (zawierająca zarówno wierzchołek początkowy, jak i końcowy).</returns>
        public (int t, int l, int[] path) Stage1(DiGraph<int> G, int[] waitTime, int s)
        {
            int n = G.VertexCount;

            DiGraph<int> H = new DiGraph<int>(n, G.Representation);
            foreach (var e in G.DFS().SearchFrom(s))
            {
                H.AddEdge(e.From, e.To, e.Weight + waitTime[e.To]);
            }

            var pi = Paths.Dijkstra(H, s);
            int bestDist = 0;
            int bestEnd = s;
            for (int v = 0; v < n; v++)
            {
                if (pi.Reachable(s, v))
                {
                    int dist = pi.GetDistance(s, v) - waitTime[v];
                    if (dist > bestDist)
                    {
                        bestDist = dist;
                        bestEnd = v;
                    }
                }
            }

            return (bestEnd, bestDist, pi.GetPath(s, bestEnd));
        }

        /// <summary>Etap II</summary>
        /// <param name="G">Graf opisujący połączenia szlakami turystycznymi z podanym czasem przejścia krawędzi w wadze.</param>
        /// <param name="C">Graf opisujący koszty przejścia krawędziami w grafie G.</param>
        /// <param name="waitTime">Czas oczekiwania Studenta-Podróżnika w danym wierzchołku.</param>
        /// <param name="s">Wierzchołek startowy (początek trasy).</param>
        /// <param name="t">Wierzchołek końcowy (koniec trasy).</param>
        /// <returns>Pierwszy element krotki to długość trasy w minutach. Drugi element to koszt przebycia trasy w złotych. Trzeci element to droga będąca rozwiązaniem: sekwencja odwiedzanych wierzchołków (zawierająca zarówno wierzchołek początkowy, jak i końcowy). Jeśli szukana trasa nie istnieje, funkcja zwraca `null`.</returns>
        public (int l, int c, int[] path)? Stage2(DiGraph<int> G, Graph<int> C, int[] waitTime, int s, int t)
        {
            int n = G.VertexCount;

            DiGraph<ulong> H = new DiGraph<ulong>(n, G.Representation);
            foreach (var e in G.DFS().SearchFrom(s))
            {
                H.AddEdge(e.From, e.To, (ulong)(e.Weight + waitTime[e.To]) + ((ulong)C.GetEdgeWeight(e.From, e.To) << 32));
            }

            var pi = Paths.Dijkstra(H, s);
            if (!pi.Reachable(s, t))
                return null;

            if (t == s)
            {
                int[] path = new int[1];
                path[0] = s;
                return (0, 0, path);
            }

            ulong bestDist = pi.GetDistance(s, t) - (ulong)waitTime[t];
            int bestCost = (int)(bestDist >> 32);
            int bestTime = (int)(bestDist - ((ulong)bestCost << 32));

            return (bestTime, bestCost, pi.GetPath(s, t));
        }
    }
}