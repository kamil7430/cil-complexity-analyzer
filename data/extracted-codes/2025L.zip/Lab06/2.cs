using ASD.Graphs;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ASD
{
    public class Lab06 : MarshalByRefObject
    {
        /// <summary>Etap I</summary>
        /// <param name="G">Graf opisujący połączenia szlakami turystycznymi z podanym czasem przejścia krawędzi w wadze.</param>
        /// <param name="waitTime">Czas oczekiwania Studenta-Podróżnika w danym wierzchołku.</param>
        /// <param name="s">Wierzchołek startowy (początek trasy).</param>
        /// <returns>Pierwszy element krotki to wierzchołek końcowy szukanej trasy. Drugi element to długość trasy w minutach. Trzeci element to droga będąca rozwiązaniem: sekwencja odwiedzanych wierzchołków (zawierająca zarówno wierzchołek początkowy, jak i końcowy).</returns>
        public (int t, int l, int[] path) Stage1(DiGraph<int> G, int[] waitTime, int s)
        {
            PathsInfo<int> paths = BieszczadzkaDijkstra(G, s, waitTime);

            int highestDistance = -1;
            int furthestVertex = -1;
            int[] furthestPath = new int[0];

            for (int i = 0; i < G.VertexCount; i++)
            {
                if (paths.Reachable(s, i))
                {
                    int pathLength = paths.GetDistance(s, i);
                    if (pathLength > highestDistance)
                    {
                        highestDistance = pathLength;
                        furthestVertex = i;
                    }
                }
            }

            furthestPath = paths.GetPath(s, furthestVertex);

            if (furthestVertex == s)
            {
                highestDistance = waitTime[s];
            }

            return (furthestVertex, highestDistance - waitTime[s], furthestPath);
        }

        public static PathsInfo<int> BieszczadzkaDijkstra(IGraph<int> G, int source, int[] waitTime)
        {
            PathsInfo<int> pathsInfo = new PathsInfo<int>(G.VertexCount);
            SafePriorityQueue<int, int> safePriorityQueue = new SafePriorityQueue<int, int>(G.VertexCount);

            for (int i = 0; i < G.VertexCount; i++)
            {
                safePriorityQueue.Insert(i);
            }

            //_ = new int[G.VertexCount];
            //_ = new int[G.VertexCount];
            safePriorityQueue.UpdatePriority(source, 0);
            while (safePriorityQueue.Count > 0 && pathsInfo.Reachable(source, safePriorityQueue.Peek()))
            {
                int v = safePriorityQueue.Extract();
                foreach (Edge<int> item in G.OutEdges(v))
                {
                    if (item.Weight < 0)
                    {
                        throw new ArgumentException("Algorytm Dijkstry napotkał krawędź o ujemnej wadze!");
                    }

                    int num = item.Weight + pathsInfo.GetDistance(source, item.From) + waitTime[item.From];
                    if (!pathsInfo.Reachable(source, item.To) || num < pathsInfo.GetDistance(source, item.To))
                    {
                        safePriorityQueue.UpdatePriority(item.To, num);
                        pathsInfo.AddPathFragment(source, item.From, item.To, num);
                    }
                }
            }

            return pathsInfo;
        }

        /// <summary>Etap II</summary>
        /// <param name="G">Graf opisujący połączenia szlakami turystycznymi z podanym czasem przejścia krawędzi w wadze.</param>
        /// <param name="C">Graf opisujący koszty przejścia krawędziami w grafie G.</param>
        /// <param name="waitTime">Czas oczekiwania Studenta-Podróżnika w danym wierzchołku.</param>
        /// <param name="s">Wierzchołek startowy (początek trasy).</param>
        /// <param name="t">Wierzchołek końcowy (koniec trasy).</param>
        /// <returns>Pierwszy element krotki to długość trasy w minutach. Drugi element to koszt przebycia trasy w złotych. Trzeci element to droga będąca rozwiązaniem: sekwencja odwiedzanych wierzchołków (zawierająca zarówno wierzchołek początkowy, jak i końcowy). Jeśli szukana trasa nie istnieje, funkcja zwraca `null`.</returns>
        public (int l, int c, int[] path)? Stage2(DiGraph<int> G, Graph<int> C, int[] waitTime, int s, int t)
        {
            if (t == s)
            {
                int[] rpath = new int[1];
                rpath[0] = s;
                return (0, 0, rpath);
            }
            
            PathsInfo<int> finalPaths;
            int cost;

            (finalPaths, cost) = ChytraBieszczadzkaDijkstra(G, s, waitTime, t, C);
            int[] path;
            int pathLength;
            if (finalPaths.Reachable(s, t))
            {
                path = finalPaths.GetPath(s, t);
                pathLength = finalPaths.GetDistance(s, t);
            }
            else
            {
                return null;
            }

            return (pathLength - waitTime[s], cost, path);
        }

        public static (PathsInfo<int>, int) ChytraBieszczadzkaDijkstra(IGraph<int> G, int source, int[] waitTime, int target, IGraph<int> CostGraph)
        {
            PathsInfo<int> pathsInfo = new PathsInfo<int>(G.VertexCount);

            // ValueTuple sa porywnywane pozycyjnie, wiec waga jest brana pod uwage tylko gdy koszt jest identyczny
            SafePriorityQueue<(int cost, int weight), int> safePriorityQueue = new SafePriorityQueue<(int, int), int>(G.VertexCount);
            int[] totalCosts = new int[G.VertexCount];
            for (int i = 0; i < G.VertexCount; i++)
            {
                safePriorityQueue.Insert(i);
                totalCosts[i] = 0; // chyba mozna ususnac
            }

            //_ = new int[G.VertexCount];
            //_ = new int[G.VertexCount];
            safePriorityQueue.UpdatePriority(source, (cost: 0, weight: 0));
            while (safePriorityQueue.Count > 0 && pathsInfo.Reachable(source, safePriorityQueue.Peek()))
            {
                int v = safePriorityQueue.Extract();
                foreach (Edge<int> item in G.OutEdges(v))
                {
                    if (item.Weight < 0)
                    {
                        throw new ArgumentException("Algorytm Dijkstry napotkał krawędź o ujemnej wadze!");
                    }

                    int newWeight = item.Weight + pathsInfo.GetDistance(source, item.From) + waitTime[item.From];
                    int newCost = totalCosts[item.From] + CostGraph.GetEdgeWeight(item.From, item.To);
                    if (!pathsInfo.Reachable(source, item.To) || newCost < totalCosts[item.To])
                    {
                        totalCosts[item.To] = newCost;
                        safePriorityQueue.UpdatePriority(item.To, (cost: totalCosts[item.To], weight: newWeight));
                        pathsInfo.AddPathFragment(source, item.From, item.To, newWeight);
                    }
                    else if (newCost == totalCosts[item.To] && newWeight < pathsInfo.GetDistance(source, item.To))
                    {
                        totalCosts[item.To] = newCost;
                        safePriorityQueue.UpdatePriority(item.To, (cost: totalCosts[item.To], weight: newWeight));
                        pathsInfo.AddPathFragment(source, item.From, item.To, newWeight);
                    }
                }
            }

            return (pathsInfo, totalCosts[target]);
        }
    }
}