using ASD.Graphs;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ASD
{
    public class Lab06 : MarshalByRefObject
    {
        /// <summary>Etap I</summary>
        /// <param name="G">Graf opisujący połączenia szlakami turystycznymi z podanym czasem przejścia krawędzi w wadze.</param>
        /// <param name="waitTime">Czas oczekiwania Studenta-Podróżnika w danym wierzchołku.</param>
        /// <param name="s">Wierzchołek startowy (początek trasy).</param>
        /// <returns>Pierwszy element krotki to wierzchołek końcowy szukanej trasy. Drugi element to długość trasy w minutach. Trzeci element to droga będąca rozwiązaniem: sekwencja odwiedzanych wierzchołków (zawierająca zarówno wierzchołek początkowy, jak i końcowy).</returns>
        public (int t, int l, int[] path) Stage1(DiGraph<int> G, int[] waitTime, int s)
        {
            int[] lengths = new int[G.VertexCount];
            int[] previous = new int[G.VertexCount];
            for (int i = 0; i < G.VertexCount; i++)
            {
                lengths[i] = int.MaxValue;
                previous[i] = -1;
            }

            lengths[s] = 0;

            PriorityQueue<int, int> priorityQueue = new PriorityQueue<int, int>();
            priorityQueue.Insert(s, 0);

            while (priorityQueue.Count > 0)
            {
                int vertex = priorityQueue.Extract();

                foreach (int neighbour in G.OutNeighbors(vertex))
                {
                    int edgeWeight = G.GetEdgeWeight(vertex, neighbour);
                    int waittime = (vertex == s) ? 0 : waitTime[vertex];

                    if (lengths[neighbour] == int.MaxValue || lengths[neighbour] > lengths[vertex] + edgeWeight + waittime)
                    {
                        lengths[neighbour] = lengths[vertex] + edgeWeight + waittime;
                        previous[neighbour] = vertex;
                        priorityQueue.Insert(neighbour, lengths[vertex] + edgeWeight + waittime);
                    }
                    else continue;
                    
                }
            }

            int t = s;
            int l = lengths[s];
            for (int i = 0; i < G.VertexCount; i++)
            {
                if (lengths[i] != int.MaxValue && lengths[i] > l)
                {
                    l = lengths[i];
                    t = i;
                }
            }

            List<int> pathList = new List<int>();
            int cur = t;
            while (cur != -1)
            {
                pathList.Add(cur);
                cur = previous[cur];
            }

            pathList.Reverse();

            return (t, l, pathList.ToArray());
        }

        /// <summary>Etap II</summary>
        /// <param name="G">Graf opisujący połączenia szlakami turystycznymi z podanym czasem przejścia krawędzi w wadze.</param>
        /// <param name="C">Graf opisujący koszty przejścia krawędziami w grafie G.</param>
        /// <param name="waitTime">Czas oczekiwania Studenta-Podróżnika w danym wierzchołku.</param>
        /// <param name="s">Wierzchołek startowy (początek trasy).</param>
        /// <param name="t">Wierzchołek końcowy (koniec trasy).</param>
        /// <returns>Pierwszy element krotki to długość trasy w minutach. Drugi element to koszt przebycia trasy w złotych. Trzeci element to droga będąca rozwiązaniem: sekwencja odwiedzanych wierzchołków (zawierająca zarówno wierzchołek początkowy, jak i końcowy). Jeśli szukana trasa nie istnieje, funkcja zwraca `null`.</returns>
        public (int l, int c, int[] path)? Stage2(DiGraph<int> G, Graph<int> C, int[] waitTime, int s, int t)
        {
            // Idea rozwiązania jest bardzo podobna do rozwiązania 1 etapu. Drobna modyfikacja tkwi w tym, że 
            // do etapu drugiego będę wykorzystywał kolejkę priorytetową z priorytetem w postaci tupli z dwoma 
            // wartościami - koszt i czas. Robię tak, bo etap 2 wymaga znalezenia najtańszej ścieżki, jednak w 
            // przypadku dwóch czy więcej ścieżek o tej samej wartości nie można zwrócić dowolną - trzeba zwrócić
            // wtedy najszybszą z tych najtańszych. 
            //
            // Główna pętla ma następującą logikę: odbieram element z najmniejszym priorytetem (czyli z najtańszym
            // przejściem). Rozpatruję wszystkich sąsiadów odebranego wierzchołka. Jak widzę, że można dojść do 
            // któregoś z nich kosztem mniejszym, niż znaleziony na ten moment, to zamieniam ten koszt na ten mniejszy.
            // Zmieniam i czas, nawet jeżeli jest dłuższy (bo priorytetem jest koszt). Potem dodaję zaktualizowany 
            // wierzchołek do kolejki, żeby potem ewentualnie zmienić jego sąsiadów itd.
            // Jeśli widzę, że potencjalne inne przejście ma ten sam koszt, jednak ma mniejszy czas, to też aktualizuje
            // moje dane. Jeśli żaden z tych dwóch przypadków nie zaszedł, to nic nie robię, czyli liczba elementów
            // w kolejce priorytetowej zmniejsza się o 1. Tym gwarantuję, że algorytm kiedyś skończy swoje działanie.
            //
            // Na wyjściu z pętli otrzymuję tablicy kosztów i czasów dojścia od wierzchołka startowego 's' do każdego z 
            // pozostałych wierzchołków. Interesuje mi tylko wartość costs[t] i times[t]. Odbieram te wartości i potem
            // odbieram ścieżkę od s do t, którą konstruowałem za pomocą tablicy pomocniczej previous, która przechowywała
            // ostatniego sąsiada na ścieżce od 's' do 'x', gdzie 'x' - dowolny wierzchołek w grafie.
            // Jeśli jednak na wyjściu wartość previous[t] jest równa -1, to oznacza, że albo ścieżka jest jednowierzchołkowa
            // (w sensie od s do t, gdzie s = t), albo ścieżki nie istnieje (graf nie jest spójny). Jeśli s != t i
            // previous[t] = -1, to znaczy, że ścieżki nie istnieje, wtedy zwracam null.
            
            int[] costs = new int[G.VertexCount];
            int[] times = new int[G.VertexCount];
            int[] previous = new int[G.VertexCount];

            for (int i = 0; i < G.VertexCount; i++)
            {
                costs[i] = int.MaxValue;
                times[i] = int.MaxValue;
                previous[i] = -1;
            }

            costs[s] = 0;
            times[s] = 0;

            PriorityQueue<(int cost, int time), (int vertex, int time, int cost)> priorityQueue =
                new PriorityQueue<(int cost, int time), (int vertex, int time, int cost)>();

            priorityQueue.Insert((s, 0, 0), (0, 0));

            while (priorityQueue.Count > 0)
            {
                var new_element = priorityQueue.Extract();
                int vertex = new_element.vertex;

                foreach (int neighbour in G.OutNeighbors(vertex))
                {
                    int vertex_neighbour_Time = G.GetEdgeWeight(vertex, neighbour);
                    int vertex_neighbour_Cost = C.GetEdgeWeight(vertex, neighbour);
                    int waittime = (vertex == s) ? 0 : waitTime[vertex];

                    if (costs[neighbour] > costs[vertex] + vertex_neighbour_Cost)
                    {
                        costs[neighbour] = costs[vertex] + vertex_neighbour_Cost;
                        times[neighbour] = times[vertex] + vertex_neighbour_Time + waittime;
                        previous[neighbour] = vertex;
                        priorityQueue.Insert((neighbour, times[neighbour], costs[neighbour]), (costs[neighbour], times[neighbour]));
                        continue;
                    }
                    else if (costs[neighbour] == costs[vertex] + vertex_neighbour_Cost &&
                        times[neighbour] > times[vertex] + vertex_neighbour_Time + waittime)
                    {
                        times[neighbour] = times[vertex] + vertex_neighbour_Time + waittime;
                        previous[neighbour] = vertex;
                        priorityQueue.Insert((neighbour, times[neighbour], costs[neighbour]), (costs[neighbour], times[neighbour]));
                        continue;
                    }
                    else continue;  
                }
            }
          
            if (previous[t] == -1 && s != t)
            {
                return null;
            }
            
            List<int> pathList = new List<int>();
            int cur = t;
            while (cur != -1)
            {
                pathList.Add(cur);
                cur = previous[cur];
            }

            pathList.Reverse();

            return (times[t], costs[t], pathList.ToArray());
        }
    }
}
