using ASD.Graphs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Reflection;
using System.Reflection.PortableExecutable;

namespace ASD
{
    public class Lab08 : MarshalByRefObject
    {
        /// <summary>Etap I</summary>
        /// <param name="P">Tablica która dla każdego pola zawiera informacje, ile maszyn moze lacznie wyjechac z tego pola</param>
        /// <param name="MachinePos">Tablica zawierajaca informacje o poczatkowym polozeniu maszyn</param>
        /// <returns>Pierwszy element kroki to liczba uratowanych maszyn, drugi to tablica indeksów tych maszyn</returns>
        public (int savedNum, int[] Saved) Stage1(int[,] P, (int row, int col)[] MachinePos)
        {
			int height = P.GetLength(0);
            int width = P.GetLength(1);

            DiGraph<int> fieldGraph = new DiGraph<int>(2 * height * width + 2);
            int source = height * width;
            int sink = height * width + 1;

            // krwaedzie z s do pozycji maszyn
            foreach (var machine in MachinePos)
            {
                int index = machine.row * width + machine.col;
                fieldGraph.AddEdge(source, index, 1);
            }

            for (int column = 0; column < width; column++)
            {
                for (int row = 0; row < height; row++)
                {
                    int index = ToIndex(column, row, width);
                    int cost = P[row, column];
                    int offset = height * width + 2;

                    if (cost == 0)
                    {
                        continue;
                    }

                    fieldGraph.AddEdge(index, offset + index, cost); // krawedz do t

                    // lewo
                    if (IsPositionValid(column - 1, row, width, height))
                    {
                        fieldGraph.AddEdge(offset + index, ToIndex(column - 1, row, width), int.MaxValue);
                    }
                    // prawo
                    if (IsPositionValid(column + 1, row, width, height))
                    {
                        fieldGraph.AddEdge(offset + index, ToIndex(column + 1, row, width), int.MaxValue);
                    }
                    // gora
                    if (IsPositionValid(column, row - 1, width, height))
                    {
                        fieldGraph.AddEdge(offset + index, ToIndex(column, row - 1, width), int.MaxValue);
                    }
                    // dol
                    if (IsPositionValid(column, row + 1, width, height))
                    {
                        fieldGraph.AddEdge(offset + index, ToIndex(column, row + 1, width), int.MaxValue);
                    }
                    // krawedzie do t
                    if (row == 0)
                    {
                        fieldGraph.AddEdge(offset + index, sink, int.MaxValue);
                    }
                }
            }

            var(totalCost, flow) = Flows.FordFulkerson<int>(fieldGraph, source, sink);

            // znajdowanie maszyn
            var savedMachines = new List<int>();
            int[] neighbors = new int[height * width];
            foreach (int neighbor in flow.OutNeighbors(source))
            {
                if (neighbor != source)
                {
                    neighbors[neighbor] = 1;
                }
            }

            for (int i = 0; i < MachinePos.Length; i++)
            {
                var machine = MachinePos[i];
                int index = machine.row * width + machine.col;
                if (neighbors[index] == 1)
                {
                    savedMachines.Add(i);
                }
            }

            return (totalCost, savedMachines.ToArray());
        }

        bool IsPositionValid(int x, int y, int width, int height)
        {
            return x >= 0 && x < width && y >= 0 && y < height;
        }

        int ToIndex(int x, int y, int w)
        {
            return w * y + x;
        }


        /// <summary>Etap II</summary>
        /// <param name="P">Tablica która dla każdego pola zawiera informacje, ile maszyn moze lacznie wyjechac z tego pola</param>
        /// <param name="MachinePos">Tablica zawierajaca informacje o poczatkowym polozeniu maszyn</param>
        /// <param name="MachineValue">Tablica zawierajaca informacje o wartosci maszyn</param>
        /// <param name="moveCost">Koszt jednego ruchu</param>
        /// <returns>Pierwszy element kroki to najwiekszy mozliwy zysk, drugi to tablica indeksow maszyn, ktorych wyprowadzenie maksymalizuje zysk</returns>
        public (int bestProfit, int[] Saved) Stage2(int[,] P, (int row, int col)[] MachinePos, int[] MachineValue, int moveCost)
        {
			int height = P.GetLength(0);
            int width = P.GetLength(1);

            NetworkWithCosts<int, int> fieldGraph = new NetworkWithCosts<int, int>(2 * height * width + 3);
            int superSource = 2 * height * width + 0;
            int source = 2 * height * width + 1;
            int sink = 2 * height * width + 2;
            int offset = height * width;
            int machineCount = MachinePos.Length;

            // splyw (zapewnia ze kazda output ma ten sam flow)
            fieldGraph.AddEdge(source, sink, machineCount, 0);
            fieldGraph.AddEdge(superSource, source, machineCount, 0);

            // krwaedzie z source do pozycji maszyn
            for (int machineIndex = 0; machineIndex < machineCount; machineIndex++)
            {
                (int row, int col) machineCoords = MachinePos[machineIndex];
                if (P[machineCoords.row, machineCoords.col] == 0)
                {
                    continue;
                }
                int machineCost = MachineValue[machineIndex];
                int graphIndex = machineCoords.row * width + machineCoords.col;
                fieldGraph.AddEdge(source, graphIndex, 1, -machineCost);
            }

            for (int column = 0; column < width; column++)
            {
                for (int row = 0; row < height; row++)
                {
                    int index = width * row + column;
                    int throughput = P[row, column];
                    int aboveVertex = index + offset;

                    if (throughput == 0)
                    {
                        continue;
                    }

                    // lewo
                    if (column != 0 && P[row, column - 1] != 0)
                    {
                        fieldGraph.AddEdge(aboveVertex, index - 1, throughput, moveCost);
                    }
                    // prawo
                    if (column != width - 1 && P[row, column + 1] != 0)
                    {
                        fieldGraph.AddEdge(aboveVertex, index + 1, throughput, moveCost);
                    }
                    // gora
                    if (row != 0 && P[row - 1, column] != 0)
                    {
                        fieldGraph.AddEdge(aboveVertex, index - width, throughput, moveCost);
                    }
                    // dol
                    if (row != height - 1 && P[row + 1, column] != 0)
                    {
                        fieldGraph.AddEdge(aboveVertex, index + width, throughput, moveCost);
                    }
                    // krawedzie do t
                    if (row == 0)
                    {
                        fieldGraph.AddEdge(aboveVertex, sink, throughput, moveCost);
                    }
                    // krawedz do t
                    fieldGraph.AddEdge(index, aboveVertex, throughput, 0);
                }
            }
            

            var (_, minCost, flowGraph) = Flows.MinCostMaxFlow(fieldGraph, superSource, sink);

            if (minCost == 0)
            {
                return (0, Array.Empty<int>());
            }

            // znajdowanie maszyn
            var savedMachines = new List<int>();
            int[] neighbors = new int[height * width];
            foreach (int neighbor in flowGraph.OutNeighbors(source))
            {
                if (neighbor != sink)
                {
                    neighbors[neighbor] = 1;
                }
            }

            for (int i = 0; i < machineCount; i++)
            {
                var machine = MachinePos[i];
                int index = machine.row * width + machine.col;
                if (neighbors[index] == 1)
                {
                    savedMachines.Add(i);
                }
            }
            return (-minCost, savedMachines.ToArray());
        }
    }
}