using ASD.Graphs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;

namespace ASD
{
    public class Lab08 : MarshalByRefObject
    {
        /// <summary>Etap I</summary>
        /// <param name="P">Tablica która dla każdego pola zawiera informacje, ile maszyn moze lacznie wyjechac z tego pola</param>
        /// <param name="MachinePos">Tablica zawierajaca informacje o poczatkowym polozeniu maszyn</param>
        /// <returns>Pierwszy element kroki to liczba uratowanych maszyn, drugi to tablica indeksów tych maszyn</returns>
        public (int savedNum, int[] Saved) Stage1(int[,] P, (int row, int col)[] MachinePos)
        {
            int h = P.GetLength(0);
            int w = P.GetLength(1);

            // W pierwszym etapie głównym celem było poprawne skonfigurowanie sieci, na której potem wywołano algorytm biblioteczny 
            // FordFurkerson. Z treści zadania wynikało, że nie możemy po prostu traktować pola powierzchni jako wierzchołki sieci.
            // Niewiadomo wtedy jak trzeba by było poprawnie traktować liczbę maszyn, które mogły wyjechać z konkretnego pola.
            // Dlatego postanowiłem traktować każde pole jako 2 wierzchołki 'in' oraz 'out'. Jeśli maszyna ruszy się z jednego pola x
            // na inne pole y, to przechodzi z wierzchołka x-out do wierzchołka y-in. Zatem wartość P[i, j] będzie użyta jako przepustowość
            // z wierzchołka ij_in do ij_out. Krawędzie pomiędzy x-out a y-in będą miały "nieskończoną" przepustowość, bo do każdego pola
            // może wjechać dowolna liczba maszyn, a wyjechać już może tylko P[i,j] maszyn (co jest uwzględnione w in->out krawędziach).
            // Stworzyłem super-źrodło i super-ujście. Wierzchołki 'in', na których na początku stała maszyna mają połączenie ze źródłem
            // (o przepustowości 1). Wierzchołki 'out' z pierwszego wierszu - stąd już można wyjść "na zewnątrz" - mają połączenie z ujściem
            // o nieskończonej przepustowości.
            //
            // Zatem potrzebowałem 2hw + 2 wierzchołki - źrodło (0), ujście (2hw+1), wierzchołki 'in' [1, hw] i wierzchołki 'out' [hw+1, 2hw]

            const int INF = 1000000000;
            DiGraph<int> G = new DiGraph<int>(2 * h * w + 2);

            // Tworzę słownik do przechowywania krawędzi ze źródła do wierzchołków 'in', na których stały maszyny na początku.
            // Potem będę w stanie sprawdzić, czy przez te krawędzie idzie przepływ, a to z kolei będzie oznaczało, że ta maszyna 
            // została uratowana.
            Dictionary<int, (int from, int to)> s_machinesEdges = new Dictionary<int, (int from, int to)>();
            int id = 0;

            // Dodaję krawędzie ze źrodła do wierzchołków 'in', na których stały maszyny na początku.
            foreach (var coordinates in MachinePos)
            {
                int row = coordinates.row;
                int col = coordinates.col;
                int numberOfVertex = row * w + col + 1;
                G.AddEdge(0, numberOfVertex, 1);
                s_machinesEdges.Add(id, (0, numberOfVertex));
                id++;
            }

            // Dodaję krawędzie z wierzchołków 'out' 0-go wierszu do ujścia.
            for (int j = 0; j < w; j++)
            {
                int numberOfVertex = j + 1;
                G.AddEdge(numberOfVertex + h * w, 2 * h * w + 1, INF);
            }

            // Dodaje krawędzie pomiędzy 'in' a 'out' tego samego pola (z przepustowością P[i,j])
            // Dodaje krawędzie pomiędzy sąsiadującymi polami ('out'->'in' krawędzie). Do tego stosuje funkcję pomocniczą getNumbersOfNeighbors,
            // która zwraca numery sąsiadów, jeżeli one są (pola na brzegach nie mają wszystkich 4 sąsiadów)
            for (int row = 0; row < h; row++)
            {
                for (int col = 0; col < w; col++)
                {
                    int numberOfVertex = row * w + col + 1;
                    G.AddEdge(numberOfVertex, numberOfVertex + h * w, P[row, col]);
                    (int? LeftNeighbor, int? RightNeighbor, int? UpNeighbor, int? DownNeighbor) = getNumbersOfNeighbors(row, col, h, w);
                    if (LeftNeighbor != null)
                        G.AddEdge(numberOfVertex + h * w, (int)LeftNeighbor, INF);
                    if (RightNeighbor != null)
                        G.AddEdge(numberOfVertex + h * w, (int)RightNeighbor, INF);
                    if (UpNeighbor != null)
                        G.AddEdge(numberOfVertex + h * w, (int)UpNeighbor, INF);
                    if (DownNeighbor != null)
                        G.AddEdge(numberOfVertex + h * w, (int)DownNeighbor, INF);
                }
            }

            // Wywołuję metodę biblioteczną FordFulkerson. Zwraca ona wartość maksymalnego przepływu - liczbę uratowanych maszyn,
            // oraz sam przepływ.
            (int maxFlow, DiGraph<int> FlowG) = Flows.FordFulkerson(G, 0, 2 * h * w + 1);

            // Jak już pisałem na początku, jeśli krawędź ze źrodła ma w zwróconym przepływie wagę 1, to oznacza, że przez tą 
            // krawędź rzeczywiście płynie przepływ, a to z kolei oznacza, że odpowiednia maszyna została uratowana.
            // Odczytuję klucz uratowanej maszyny i dodaję ją do listy, którą potem zwracam na końcu jako tablicę kończąc rozwiązanie zadania.
            List<int> savedMachines = new List<int>();
            for (int i = 0; i < s_machinesEdges.Count; i++)
            {
                if (FlowG.HasEdge(s_machinesEdges[i].from, s_machinesEdges[i].to) && 
                    FlowG.GetEdgeWeight(s_machinesEdges[i].from, s_machinesEdges[i].to) == 1)
                    savedMachines.Add(i);
            }
            
            return (maxFlow, savedMachines.ToArray());
        }

        private (int? LeftCoordIn, int? RightCoordIn, int? UpCoordIn, int? DownCoordIn) getNumbersOfNeighbors(int row, int col, int h, int w)
        {
            int? LeftCoordIn = null;
            int? RightCoordIn = null;
            int? UpCoordIn = null;
            int? DownCoordIn = null;

            if (row != 0) UpCoordIn = (row - 1) * w + col + 1;
            if (row != h - 1) DownCoordIn = (row + 1) * w + col + 1;
            if (col != 0) LeftCoordIn = row * w + col;
            if (col != w - 1) RightCoordIn = row * w + col + 2;

            return (LeftCoordIn, RightCoordIn, UpCoordIn, DownCoordIn);
        }

        /// <summary>Etap II</summary>
        /// <param name="P">Tablica która dla każdego pola zawiera informacje, ile maszyn moze lacznie wyjechac z tego pola</param>
        /// <param name="MachinePos">Tablica zawierajaca informacje o poczatkowym polozeniu maszyn</param>
        /// <param name="MachineValue">Tablica zawierajaca informacje o wartosci maszyn</param>
        /// <param name="moveCost">Koszt jednego ruchu</param>
        /// <returns>Pierwszy element kroki to najwiekszy mozliwy zysk, drugi to tablica indeksow maszyn, ktorych wyprowadzenie maksymalizuje zysk</returns>
        public (int bestProfit, int[] Saved) Stage2(int[,] P, (int row, int col)[] MachinePos, int[] MachineValue, int moveCost)
        {
			int h = P.GetLength(0);
            int w = P.GetLength(1);

            // Skoro drugi etap polegał już na znajdowaniu maksymalnego zysku, to musiałem poprawnie przygotować sieć, żeby
            // na niej wywołać wbudowaną procedurę MinCostMaxFlow. Ogólnie graf nie mocno się zmienił. Większość logiki pozostała taka sama.
            // Dodałem ujście finałowe (ujście z poprzedniego etapu zostało, jednak już wykonywało rolę ujścia pośredniego), jego sens opiszę
            // później. Poza tym dodałem M wierzchołków, gdzie M - liczba maszyn na powierzchni. 
            // Konstruowana sieć już miała typ NetworkWithCosts, bo zależało nie tylko na przepustowości krawędzi, a jeszcze i na ich koszcie. 
            // Ujście finałowe miało dokładnie wymusić każdy przepływ przejść przez jedną krawędź, żeby z góry ograniczyć maksymalny przepływ.
            // Krawędź dodana pomiędzy źródłem a ujściem pośrednim miała obsłużyć przypadki, gdy nie warto ratować żadnej maszyny (gdy zysk będzie
            // ujemnym, czyli koszt dodatnim).
            // Pozostała logika jest bardzo podobna do etapu pierwszego z tą różnicą, że trzeba było dostosować poprawne koszty do wszystkich krawędzi.
            // Te dostosowania opiszę poniżej.


            int M = MachinePos.Length;

            const int INF = 1000000000;
            NetworkWithCosts<int, int> G = new NetworkWithCosts<int, int>(M + 2 * h * w + 3);

            Dictionary<int, (int from, int to)> s_machinesEdges = new Dictionary<int, (int from, int to)>();
            int id = 0;

            // Od razu dodaję krawędzie ze źródła do ujścia pośredniego oraz z ujścia pośredniego do ujscia finałowego
            // (bo wtedy magicznym sposobem algorytm działa znacznie szybciej xdd)
            G.AddEdge(0, M + 2 * h * w + 1, MachineValue.Length, 0);
            G.AddEdge(M + 2 * h * w + 1, M + 2 * h * w + 2, MachineValue.Length, 0);

            // Tutaj dodaję krawędzie od źrodła do wierzchołków reprezentujących maszyny. Te M wierzchołków oraz odpowiadające im 
            // M krawędzi zostały dodane, żeby wrzucić do przepływu koszty konkretnych maszyn. Ujemna wartość jest wykorzystana, 
            // bo MinCostMaxFlow minimalizuje koszt. Czyli im większy jest koszt maszyny, tym mniejsza jest jej wartość odwrotna i
            // tym bardziej będzie się opłacać jej ratowanie, bo będzie więcej minimalizować koszt przepływu.
            for (int i = 0; i < M; i++)
            {
                G.AddEdge(0, i + 1, 1, -MachineValue[i]);
                s_machinesEdges.Add(id, (0, i + 1));
                id++;
            }

            // Dodaję krawędzie z tych M wierzchołków do odpowiadających im pól 'in'. Koszt 0, bo te krawędzie nie symbolizują krok.
            // Przepustowość 1, bo odpowiada jednej konkretnej maszynie.
            for (int i = 0; i < M; i++)
            {
                (int row, int col) = MachinePos[i];
                int numberOfVertex = M + 1 + row * w + col;
                G.AddEdge(i + 1, numberOfVertex, 1, 0);
            }

            // Dodaję krawędzie wewnątrz pola (pomiędzy 'in' a 'out') z zerowym kosztem, bo nie symbolizują ruch. 
            // Dodaję krawędzie pomiędzy sąsiadującymi polami z podanym kosztem moveCost (bo rzeczywiście one symbolizują ruch).
            for (int row = 0; row < h; row++)
            {
                for (int col = 0; col < w; col++)
                {
                    int numberOfVertex = M + row * w + col + 1;
                    if (P[row, col] != 0)
                        G.AddEdge(numberOfVertex, numberOfVertex + h * w, P[row, col], 0);
                    (int? LeftNeighbor, int? RightNeighbor, int? UpNeighbor, int? DownNeighbor) = getNumbersOfNeighbors(row, col, h, w);
                    if (LeftNeighbor != null)
                        G.AddEdge(numberOfVertex + h * w, (int)LeftNeighbor + M, INF, moveCost);
                    if (RightNeighbor != null)
                        G.AddEdge(numberOfVertex + h * w, (int)RightNeighbor + M, INF, moveCost);
                    if (UpNeighbor != null)
                        G.AddEdge(numberOfVertex + h * w, (int)UpNeighbor + M, INF, moveCost);
                    if (DownNeighbor != null)
                        G.AddEdge(numberOfVertex + h * w, (int)DownNeighbor + M, INF, moveCost);
                }
            }

            // Dodaję krawędzie z pol zerowego wierszu do ujścia pośredniego z kosztem moveCost, bo też symbolizują ruch.
            for (int col = 0; col < w; col++)
            {
                int numberOfVertex = col + 1 + M + h * w;
                G.AddEdge(numberOfVertex, M + 2 * h * w + 1, INF, moveCost);
            }

            // Przepustowość wszędzie ustawiam dokładnie tak samo, jak i w etapie pierwszym, bo nic się nie zmieniło.

            // Odbieram zminimalizowany koszt (czyli zysk * (-1)) oraz otrzymany przepływ z tym kosztem
            // za pomocą metodę bibliotecznej MinCostMaxFlow.
            (int flow, int totalCost, DiGraph<int> Flow) = Flows.MinCostMaxFlow(G, 0, M + 2 * h * w + 2);

            int bestProfit = -totalCost;

            // Tak samo, jak i w etapie 1, odbieram indeksy uratowanych maszyn i zwracam je w postaci tablicy, kończąc rozwiązanie.
            List<int> savedMachines = new List<int>();
            for (int i = 0; i < s_machinesEdges.Count; i++)
            {
                if (Flow.HasEdge(s_machinesEdges[i].from, s_machinesEdges[i].to) &&
                    Flow.GetEdgeWeight(s_machinesEdges[i].from, s_machinesEdges[i].to) == 1)
                    savedMachines.Add(i);
            }

            return (bestProfit, savedMachines.ToArray());
        }
    }
}