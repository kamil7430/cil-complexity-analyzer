using ASD.Graphs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;

namespace ASD
{
    public class Lab08 : MarshalByRefObject
    {
        /// <summary>Etap I</summary>
        /// <param name="P">Tablica która dla każdego pola zawiera informacje, ile maszyn moze lacznie wyjechac z tego pola</param>
        /// <param name="MachinePos">Tablica zawierajaca informacje o poczatkowym polozeniu maszyn</param>
        /// <returns>Pierwszy element kroki to liczba uratowanych maszyn, drugi to tablica indeksów tych maszyn</returns>
        public (int savedNum, int[] Saved) Stage1(int[,] P, (int row, int col)[] MachinePos)
        {
            int inf = int.MaxValue;
            int h = P.GetLength(0);
            int w = P.GetLength(1);
            int n = w * h;
            int s = 2 * n;
            int t = 2 * n + 1;

            // dim = 0 -- wierzchołki 'in', dim = 1 -- wierzchołki 'out'
            int xy2i(int row, int col, int dim) => row * w + col + dim * n;

            var G = new DiGraph<int>(2 * n + 2);
            for (int col = 0; col < w; col++)
            {
                G.AddEdge(xy2i(0, col, 1), t, inf);
                G.AddEdge(xy2i(0, col, 0), xy2i(0, col, 1), P[0, col]);
            }

            foreach (var (row, col) in MachinePos)
                G.AddEdge(s, xy2i(row, col, 0), 1);


            for (int row = 1; row < h; row++)
            {
                for (int col = 0; col < w; col++)
                {
                    if (P[row, col] != 0)
                        G.AddEdge(xy2i(row, col, 0), xy2i(row, col, 1), P[row, col]);
                    
                    G.AddEdge(xy2i(row, col, 1), xy2i(row - 1, col, 0), inf);
                    if (row + 1 < h)
                        G.AddEdge(xy2i(row, col, 1), xy2i(row + 1, col, 0), inf);
                    if (col - 1 >= 0)
                        G.AddEdge(xy2i(row, col, 1), xy2i(row, col - 1, 0), inf);
                    if (col + 1 < w)
                        G.AddEdge(xy2i(row, col, 1), xy2i(row, col + 1, 0), inf);
                }
            }

            var (val, f) = Flows.FordFulkerson(G, s, t);

            var saved = new List<int>();
            int i = 0;
            foreach (var (row, col) in MachinePos)
            {
                if (f.HasEdge(s, xy2i(row, col, 0)) && f.GetEdgeWeight(s, xy2i(row, col, 0)) == 1)
                    saved.Add(i);
                i++;
            }

            return (val, saved.ToArray());
        }

        /// <summary>Etap II</summary>
        /// <param name="P">Tablica która dla każdego pola zawiera informacje, ile maszyn moze lacznie wyjechac z tego pola</param>
        /// <param name="MachinePos">Tablica zawierajaca informacje o poczatkowym polozeniu maszyn</param>
        /// <param name="MachineValue">Tablica zawierajaca informacje o wartosci maszyn</param>
        /// <param name="moveCost">Koszt jednego ruchu</param>
        /// <returns>Pierwszy element kroki to najwiekszy mozliwy zysk, drugi to tablica indeksow maszyn, ktorych wyprowadzenie maksymalizuje zysk</returns>
        public (int bestProfit, int[] Saved) Stage2(int[,] P, (int row, int col)[] MachinePos, int[] MachineValue,
            int moveCost)
        {
            int inf = int.MaxValue;
            int h = P.GetLength(0);
            int w = P.GetLength(1);
            int n = w * h;
            int s = 3 * n;
            int t = 3 * n + 1;
            int k = moveCost;

            // dim = 0 -- wierzchołki 'in1', dim = 1 -- wierzchołki 'in2', dim = 2 -- wierzchołki 'out
            // między in1 a in2 mamy wartość maszyny (ujemny koszt)
            // między in2 a out mamy P[i, j], koszt 0
            int xy2i(int row, int col, int dim) => row * w + col + dim * n;

            var G = new NetworkWithCosts<int, int>(3 * n + 2);
            for (int col = 0; col < w; col++)
            {
                G.AddEdge(xy2i(0, col, 2), t, inf, k);
                if (P[0, col] != 0)
                    G.AddEdge(xy2i(0, col, 1), xy2i(0, col, 2), P[0, col], 0);
            }

            int j = 0;
            foreach (var (row, col) in MachinePos)
            {
                // optymalizacja aby zmieścić się w limitach czasowych
                if (MachineValue[j] > (row + 1) * k)
                {
                    G.AddEdge(s, xy2i(row, col, 0), 1, 0);
                    G.AddEdge(xy2i(row, col, 0), xy2i(row, col, 1), 1, -MachineValue[j]);
                    // opcja żeby nie ratować tej maszyny
                    G.AddEdge(xy2i(row, col, 0), t, 1, 0);
                }

                j++;
            }

            for (int row = 1; row < h; row++)
            {
                for (int col = 0; col < w; col++)
                {
                    if (P[row, col] != 0)
                        G.AddEdge(xy2i(row, col, 1), xy2i(row, col, 2), P[row, col], 0);
                    
                    G.AddEdge(xy2i(row, col, 2), xy2i(row - 1, col, 1), inf, k);
                    if (row + 1 < h)
                        G.AddEdge(xy2i(row, col, 2), xy2i(row + 1, col, 1), inf, k);
                    if (col - 1 >= 0)
                        G.AddEdge(xy2i(row, col, 2), xy2i(row, col - 1, 1), inf, k);
                    if (col + 1 < w)
                        G.AddEdge(xy2i(row, col, 2), xy2i(row, col + 1, 1), inf, k);
                }
            }

            var (val, cost, f) = Flows.MinCostMaxFlow(G, s, t);

            var saved = new List<int>();
            int i = 0;
            foreach (var (row, col) in MachinePos)
            {
                if (f.HasEdge(xy2i(row, col, 0), xy2i(row, col, 1)) &&
                    f.GetEdgeWeight(xy2i(row, col, 0), xy2i(row, col, 1)) == 1)
                    saved.Add(i);
                i++;
            }

            return (-cost, saved.ToArray());
        }
    }
}
